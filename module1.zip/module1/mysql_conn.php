<?php
 $conn = mysqli_connect("localhost",'id10993191_major','major','id10993191_major');
    if($conn == null)
    {
        die('error connecting database');
        return;
    }
    // mysql_select_db('online_quiz', $conn);

?>
