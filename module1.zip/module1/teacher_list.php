<?php
session_start();
	if (!isset($_SESSION["admin"])) {
		header('Location: index.php');
		exit;
		}
	include "mysql_conn.php";

?>

<html>
<head>
	<title>Admin Panel || Online Quiz Test</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>
<body>
<center>
	<h1> Teacher List </h1>
	<hr/>
	<table border='1' class="table table-hover">
		
		<?php

			$sql = "SELECT t2.* FROM `users` as t1 INNER JOIN `user_info` as t2 on t1.user_id = t2.user_id WHERE `role`= 'Teacher' and `active`=1";
			$result = mysqli_query($conn,$sql);
			echo "<tr> <th>". "user id"."</th> <th>" . "full name"."</th> <th>". "email". "</th> <th>" . "phn"."</th> </tr>";
			if ($result) {
				while($row = mysqli_fetch_assoc($result)) {
					echo "<tr> <td>". $row["user_id"]."</td> <td>" . $row["full_name"]."</td> <td>". $row["email"]. "</td> <td>" . $row["phn"]."</td> </tr>";
				}
			}else {
				echo "Teacher not found..!!";
			}
		?>
	</table>
</center>
<hr/><br>
<a href="admin.php">Go To Your Dashboard</a>
<br>
<a href="logout.php">Logout</a>
</body>
</html>
