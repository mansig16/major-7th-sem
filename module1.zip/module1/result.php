<?php

	include "mysql_conn.php";
	session_start();
	$user_id = $_SESSION["student"];

// 	print_r($_POST);
	$Result = 0;

// 	$myarray = array( $_POST);
// // 	echo $myarray;
// 	foreach ($myarray as $key => $value) {
// 	    print_r( $value);
//         // $ss="Select * from mcq_question where ques_id='$key'";
//         // $r=mysqli_query($conn,$ss);
//         // $row=mysqli_fetch_array($r);
//         // echo $row['ans'];
//         // if($row['ans']==$value)
//         // {
//         //     $Result++;
//         // }
// 	  echo "<hr />";
// 	}


 	$paper_id = $_POST["paper_id"];
 	$qus_id = $_POST["qus_id"];

	$i = 0;
	foreach ($qus_id as $k => $v) {
		$index = $v;

		$ans = $_POST[$index];
		if ($ans[0] == $_POST["answer"][$i]) {
			$Result++;
		}
		//echo $ans[0];
		$i++;
	}

// 	//echo $paper_id;

//  	$qus_id =isset( $_POST["qus_id"]);
//  	$answer=isset($_POST["answer"]);
//  	echo $answer;

// 	$i = 0;
// 	foreach ($qus_id as $k => $v) {
// 		$index = "ans".$v;
// // 		$anss = $_POST[$index];
// // 		echo $anss;
// 		if ($index[0] == $_POST["answer"][$i]) {
// 			$Result++;
// 		}
// 		//echo $ans[0];
// 		$i=$i+1;
// 	}
// $array_keys=array_keys($_POST);
// 	foreach($qus_id as $q_id)
// 	{
// 		if(in_array($q_id, $array_keys))
// 		{
// 			$user_value=$_POST[$q_id];
// 			echo $user_value;
// 		}
// 		else
// 		{
			
// 		}
// 	}
	
// 	echo $Result;

	$sql = "INSERT INTO `test_ans`(`user_id`, `paper_id`, `result`) VALUES ('$user_id','$paper_id','$Result')";
	mysqli_query($conn,$sql);
	
?>
<!DOCTYPE html>
<html>
<head>
	<title> Student Result </title>
	<script type="text/javascript">
        function preventBack() { window.history.forward(); }
        setTimeout("preventBack()", 0);
        window.onunload = function () { null };
    </script>
</head>
<body>
<?php 
	$sql1 = "SELECT * FROM `mcq_paper` WHERE `id`='$paper_id'";
	$result_1 = mysqli_query($conn,$sql1);
	$name = mysqli_fetch_array($result_1);

?>
<center>
	<h2><b>Paper Name: <?php echo $name['paper_name'];?></b></h2><br>
	<h3><b>Result: </b><i><?php echo $Result;?></i></h3>	
	<?php
echo '<a href="downloads.php?id='.$paper_id.'">'."Click here to download correct answers!!".'</a>';
?>
</center>
<hr/>
<br>
<a href="s_dashboard.php">Go To Your Dashboard</a>
<br>
<a href="logout.php">Logout</a>
</body>
</html>




