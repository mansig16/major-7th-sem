<?php
	
	include "mysql_conn.php";
	session_start();
	$userid = $_SESSION["student"];

	$sql = "SELECT * FROM `user_info` WHERE `user_id`='$userid'";
	$result = mysqli_query($conn,$sql);
	$data = mysqli_fetch_array($result);
	$user_name = $data["full_name"];

?>
<!DOCTYPE html>
<html>
<head>
	<title>Student Dashboard || Show Question Paper</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
<style>
    .form-control
    {
        width:60%;
    }
</style>
	
	<script src="jquery-1.12.3.min.js"></script>
</head>
<body>
<h3><b>Student Name: </b><i><?php echo $user_name; ?></i></h3>
<hr/>
<center>
	Select Subject:
	<select onchange="load_subject();" id="subject" name ="subject" class="form-control">
		<option value="all">All Subject</option>
        <option value="oops">oops</option>
        <option value="c">c</option>
        <option value="python">python</option>
        <option value="information security">information security</option>
        <option value="modelling and simulation">modelling and simulation</option>
    </select> 
    <br>
    <?php 
    	$sql = "SELECT * FROM `mcq_paper` ORDER BY `subject` ASC";
    	$result = mysqli_query($conn,$sql);
    ?>
    <table class="table table-hover">
    	<thead>
    		<tr>
	    		<td><b>Subject</b></td>
	    		<td><b>Question Paper Name</b></td>
	    		<td><b>Test Time</b></td>
    		</tr>
    	</thead>
    	<tbody id='list'>
    	<?php 
	    	while ($ques = mysqli_fetch_array($result)) {
	    		echo "<tr>".
	    		"<td>".$ques['subject']."</td>".
	    		"<td><a href='question_paper.php?paper_id=".$ques['id']."'>".$ques['paper_name']."</a></td>".
	    		"<td>".$ques['paper_time']."</td>".
	    		"</tr>";
		 	}
    	?>
    	</tbody>
    	<tbody id="list_1">
    	</tbody>
    	
    </table>
</center>
<hr/>
<br>
<a href="s_dashboard.php">Go To Your Dashboard</a>
<br>
<a href="logout.php">Logout</a>
</body>
<script type="text/javascript">

	$(document).ready(function(){
		$("#list_1").hide();
	});

	function load_subject() {
		$("#list").hide();
		var subject = $('#subject').val();
		if (subject === "all") {
			$("#list").show();
		}
		else{
			//alert("selected Subject: "+subject);
			$("#list_1").show();
			
			$.ajax({
				type: "POST",
				url: "ajax_loaded_table.php",
				data: { subject : subject },
				dataType: "html",
				success: function (data) {
					//alert(data);
					//$("#list").hide();
					$("#list_1").html(data);
				}
			});

		}
		//alert("selected Subject: "+subject);

	}

</script>
</html>