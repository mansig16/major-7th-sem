<?php 

	include "mysql_conn.php";
	session_start();
	$userid = $_SESSION["teacher"];
	$paper_id = $_SESSION["paper_id"];
	//echo "Paper id:".$paper_id."<br>";
	$sql = "SELECT * FROM `mcq_paper` WHERE `id`='$paper_id'";
	$result = mysqli_query($conn,$sql);
	$row = mysqli_fetch_array($result);

?>
<!DOCTYPE html>
<html>
<head>
	<title>Make Question</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>
<body>
<h3><b>Paper Name: </b><i><?php echo $row["paper_name"]; ?></i></h3>
<center>
	<h1> Make Question </h1>
	<hr/>

	<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="POST">
		Question: <br><textarea rows='3' cols='30' name="question" class="form-control"></textarea><br>
		Answer: <input type="text" name="ans" /><br>
		Option1: <input type="text" name="opt[1]" /><br>
		Option2: <input type="text" name="opt[2]" /><br>
		Option3: <input type="text" name="opt[3]" /><br>
		Option4: <input type="text" name="opt[4]" /><br>
		<input type="submit" name="submit" value="submit" class="btn btn-primary">
	</form>
</center>
<hr/><br>
<a href="t_dashboard.php">Go To Your Dashboard</a>
<br>
<a href="logout.php">Logout</a>
<?php
// echo htmlspecialchars($_SERVER["PHP_SELF"]) 
	if(isset($_POST['submit'])){
	$question = $_POST["question"];
	$ans = $_POST["ans"];

	//echo $question. " " . $ans  ;
	//print_r($data);
	//die();

	$sql = "INSERT INTO `mcq_question`(`paper_id`, `question`, `ans`) VALUES ('$paper_id','$question','$ans')";
	$result = mysqli_query($conn,$sql);

	$sql = "SELECT * FROM `mcq_question` WHERE `paper_id`='$paper_id' AND `question`='$question'";

	$result = mysqli_query($conn,$sql);
	//echo $result;
	$data = mysqli_fetch_array($result);
	$qus_id = $data['ques_id'];
	
	/*echo $qus_id;

	echo "<pre>";
	print_r($option);
	echo "</pre>";

	?id='.$mselcted_memberI
	$option = $_POST['opt'];*/


	for($i = 1; $i <=4; $i++) {
		//echo $_POST['id'][$i] . "<br>";

		$sql = "INSERT INTO `mcq_option`(`ques_id`, `opt`,`paper_id`) VALUES ('$qus_id','".$_POST['opt'][ $i ]."','$paper_id')";
	    $result = mysqli_query($conn,$sql);
	}

}
?>
</body>


</html>