<?php
	include "mysql_conn.php";

	$paper_id = $_GET['paper_id'];
	//echo $paper_id;
	//die();
	$sql = "SELECT * FROM `mcq_paper` WHERE `id`='$paper_id'";
	$result = mysqli_query($conn,$sql);
	$row = mysqli_fetch_array($result);
	$t = $row['paper_time'];
	$t = $t * 60;
?>
<!DOCTYPE html>
<html>
<head>
	<noscript>
      <meta http-equiv="refresh" content="<?php echo $t;?>;url=http://localhost/Work/online_quiz/s_dashboard.php" />
    </noscript>
	<title>Test || Question Paper</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
<script type="text/javascript">
        function preventBack() { window.history.forward(); }
        setTimeout("preventBack()", 0);
        window.onunload = function () { null };
    </script>
</head>
<body>
 Time: <span id="seconds"><?php echo $t; ?></span>.
 <script>
      var seconds = document.getElementById('seconds').innerHTML;
      setInterval(
        function(){
          if (seconds <= 1) {
            window.location = 'https://major7sem.000webhostapp.com/s_dashboard.php';
          }
          else {
            document.getElementById('seconds').innerHTML = --seconds;
          }
        },
        1000
      );
    </script>
<h3><b>Paper Name: </b><i><?php echo $row["paper_name"]; ?></i></h3>
<br><br>
<form action="result.php" method="POST">
	<input type="hidden" name="paper_id" value="<?php echo $paper_id;?>"></input>
<?php
	
	$sql = "SELECT * FROM `mcq_question` WHERE `paper_id`='$paper_id'";
	$result = mysqli_query($conn,$sql) ;

	while ($qus = mysqli_fetch_array($result)) {
		echo "<label >".$qus['question']."</label><br>";
		$qus_id = $qus['ques_id'];
		$answer = $qus['ans'];
        echo "<input type='hidden' name='qus_id[]' value='".$qus_id."'/>";
        echo "<input type='hidden' name='answer[]' value='".$answer."' />";
		$sql1 = "SELECT * FROM `mcq_option` where `ques_id`='$qus_id' and `paper_id`='$paper_id'";
		$result1 = mysqli_query($conn,$sql1);
		while ($opt = mysqli_fetch_array($result1)) {
			echo "<input type='radio' id='' value='".$opt['opt']."' name='".$qus_id."[]'/>".$opt['opt']."  ";
			
		}
		echo "<br>";
	}

?>
	<input type="submit" name="submit" value="submit"></input>
</form>
</center>
<hr/>
<br>
<a href="s_dashboard.php">Go To Your Dashboard</a>
<br>
<a href="logout.php">Logout</a>
</body>
</html>