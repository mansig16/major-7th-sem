<?php 
	include "mysql_conn.php";
	session_start();
	$userid = $_SESSION["teacher"];
	
	if(isset($_POST['submit'])){
	$subject = $_POST["subject"];
	$paper_name = $_POST["paper_name"];
	$paper_time = $_POST["paper_time"];


	$sql = "INSERT INTO `mcq_paper`(`user_id`, `subject`, `paper_name`, `paper_time`) VALUES ('$userid','$subject','$paper_name','$paper_time')";
	mysqli_query($conn,$sql);

	$sql = "SELECT * FROM `mcq_paper`where `user_id`='$userid' and `paper_name`='$paper_name'";

	$result = mysqli_query($conn,$sql);

	$data = mysqli_fetch_array($result);
	$paper_id = $data['id'];
	$_SESSION["paper_id"] = $paper_id;
	header('Location: make_question.php');}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Make Question Paper</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
<style>
    .form-control
    {
        width:80%;
    }
</style>
</head>
<body>
<h3><b>User Name: </b><i><?php echo $userid; ?></i></h3>
<center>
	<h1> Make Question Paper</h1>
	<hr/>

	<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="POST">
		Subject Name: <select  id= "subject" name = "subject" class="form-control">
                        <option value="oops">oops</option>
                        <option value="c">c</option>
                        <option value="python">python</option>
                        <option value="information security">information security</option>
                        <option value="modelling and simulation">modelling and simulation</option>
                    </select>
                    <?php
                          /*  
                            $sql = "SELECT id FROM department";
                            $result = mysql_query($sql);

                            if ($result) {
                                while($row = mysql_fetch_assoc($result)) {
                                    echo "<option>".$row['id']."</option>";
                                }
                            }*/
                    	?>
		<br>Paper Name: <br><textarea rows='1' cols='10' name="paper_name" class="form-control"></textarea><br>

		Paper Time: <input type="text" name="paper_time" class="form-control" /><br>
		<input type="submit" name="submit" value="submit" class=" btn btn-primary">
	</form>
</center>
<hr/><br>
<a href="t_dashboard.php">Go To Your Dashboard</a>
<br>
<a href="logout.php">Logout</a>

</body>
</html>