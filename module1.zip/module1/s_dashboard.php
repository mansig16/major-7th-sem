<?php
session_start();
	if (!isset($_SESSION["student"])) {
		header('Location: index.php');
		exit;
	} 

	require_once('mysql_conn.php');

	$sql1 = "SELECT * FROM user_info";
	$result1 = mysqli_query($conn,$sql1);
	while($row = mysqli_fetch_array($result1))
	{
		$user_id= $row['user_id'];
		if($_SESSION["student"] == $user_id)
		{
			$getUid = $row['user_id'];
			$getName = $row['full_name'];
			$getEmail = $row['email'];
			$getEdu = $row['edu'];
// 			$getDOB = $row['dob'];
			$getGen = $row['gender'];
			$getPhn = $row['phn'];
			$getAdrs = $row['address'];
		}
		
	}
?>

<html>
<head>
	<title>Student Dashboard || Online Quiz Test</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
<style>
/*    body*/
/*{*/
/*    background:url("https://us.123rf.com/450wm/sergfear/sergfear1712/sergfear171200144/91603672-vector-abstract-purple-geometric-gradient-background-vector-from-polygons-triangle-vector-illustrati.jpg?ver=6");*/
/*    background-repeat:no-repeat;*/
/*    background-size:cover;*/
/*}*/
</style>
	
</head>
<body>
<center>
<h1>Student Dashboard</h1>
<h3><i><?php echo $getName;?></i></h3>
<hr>
<!--<a href="update_sinfo.php">Edit Profile</a> &nbsp-->
<!--<a href="show_question.php">Show Questions</a> &nbsp-->
<!--<a href="logout.php">Logout</a>-->

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">Dashboard</a>
    </div>
    <ul class="nav navbar-nav">
      <li><a href="update_sinfo.php">Edit Profile</a> &nbsp</li>
      <li><a href="show_question.php" >Show Questions</a> &nbsp</li>
<!--<li><a href="paper_name.php" >Submit New Q&A</a> &nbsp</li>-->

<li><a href="logout.php" >Logout</a></li>
    </ul>
  </div>
</nav>
<hr>
<table border="1" class="table table-hover">
   <tr>
      <th>Your ID: </th>
	  <td>
	     <?php
		   echo $getUid;
		 ?>
	  </td>
   </tr>
   <tr>
      <th>Your Name: </th>
	  <td>
	     <?php
		   echo $getName;
		 ?>
	  </td>
   </tr>
   <tr>
      <th>Email: </th>
	  <td>
	     <?php
		   echo $getEmail;
		 ?>
	  </td>
   </tr>
    <tr>
      <th>Education(Level): </th>
	  <td>
	     <?php
		   echo $getEdu;
		 ?>
	  </td>
   </tr>
    
   <tr>
      <th>Gender: </th>
	  <td>
	     <?php
		   echo $getGen;
		 ?>
	  </td>
   </tr>
     <tr>
      <th>Phone: </th>
	  <td>
	     <?php
		   echo $getPhn;
		 ?>
	  </td>
   </tr>
   <tr>
      <th>Address: </th>
	  <td>
	     <?php
		   echo $getAdrs;
		 ?>
	  </td>
   </tr>
   
</table>
<hr>
</center>
</body>
</html>