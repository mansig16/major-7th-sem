-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Dec 06, 2019 at 08:52 AM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `id10993191_major`
--

-- --------------------------------------------------------

--
-- Table structure for table `mcq_option`
--

CREATE TABLE `mcq_option` (
  `ques_id` int(11) NOT NULL,
  `opt` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `paper_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `mcq_option`
--

INSERT INTO `mcq_option` (`ques_id`, `opt`, `paper_id`) VALUES
(8, 'mid', 3),
(8, 'low', 3),
(8, 'high', 3),
(8, 'both', 3);

-- --------------------------------------------------------

--
-- Table structure for table `mcq_paper`
--

CREATE TABLE `mcq_paper` (
  `id` int(11) NOT NULL,
  `user_id` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `subject` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `paper_name` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `paper_time` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `mcq_paper`
--

INSERT INTO `mcq_paper` (`id`, `user_id`, `subject`, `paper_name`, `paper_time`) VALUES
(3, 'T01', 'python', 'class test 1 ', '10');

-- --------------------------------------------------------

--
-- Table structure for table `mcq_question`
--

CREATE TABLE `mcq_question` (
  `ques_id` int(11) NOT NULL,
  `paper_id` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `question` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ans` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `mcq_question`
--

INSERT INTO `mcq_question` (`ques_id`, `paper_id`, `question`, `ans`) VALUES
(8, '3', 'hi or low?', 'low');

-- --------------------------------------------------------

--
-- Table structure for table `test_ans`
--

CREATE TABLE `test_ans` (
  `user_id` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `paper_id` int(11) NOT NULL,
  `result` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `test_ans`
--

INSERT INTO `test_ans` (`user_id`, `paper_id`, `result`) VALUES
('16501', 3, 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `pass` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `role` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `pass`, `role`) VALUES
('16501', '16501', 'Student'),
('A01', 'A01', 'Admin'),
('T01', 'T01', 'Teacher'),
('T02', 'T02', 'Teacher');

-- --------------------------------------------------------

--
-- Table structure for table `user_info`
--

CREATE TABLE `user_info` (
  `user_id` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `full_name` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `edu` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gender` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phn` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `active` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user_info`
--

INSERT INTO `user_info` (`user_id`, `full_name`, `email`, `edu`, `gender`, `phn`, `address`, `active`) VALUES
('16501', 'Ankush Sharma', 'ankush1@gmail.com', 'Under Graduate', 'M', '8988789556', 'Hamirpur', 0),
('A01', 'Nishita', 'nishita@gmail.com', 'graduate', 'F', '8988784551', 'Hamirpur', 0),
('T01', 'Rajeev Kumar', 'rajeev1@gmail.com', 'Phd', 'M', '8988789551', 'Hamirpur', 1),
('T02', 'MANSI', 'MANSI@GMAIL.COM', 'Graduate', 'F', '8988142823', 'HAMIPRUR', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `mcq_paper`
--
ALTER TABLE `mcq_paper`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mcq_question`
--
ALTER TABLE `mcq_question`
  ADD PRIMARY KEY (`ques_id`);

--
-- Indexes for table `test_ans`
--
ALTER TABLE `test_ans`
  ADD PRIMARY KEY (`user_id`,`paper_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `user_info`
--
ALTER TABLE `user_info`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `mcq_paper`
--
ALTER TABLE `mcq_paper`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `mcq_question`
--
ALTER TABLE `mcq_question`
  MODIFY `ques_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
