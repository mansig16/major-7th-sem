<?php
session_start();
	if (!isset($_SESSION["admin"])) {
		header('Location: index.php');
		exit;
		}
	include "mysql_conn.php";
	

?>

<html>
<head>
	<title>Admin Panel || Online Quiz Test</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
	
</head>
<body>
<center>
	<h1> Question Remove </h1>
	<hr/>
	<table border='1' class="table table-hover">
	<tr><th>Subject</th><th>Question Paper Name</th><th>Test Time</th><th>Action</th></tr>	
		
		<?php

			$sql = "SELECT * FROM `mcq_paper`";
			$result = mysqli_query($conn,$sql);
			if ($result) {
				while($row = mysqli_fetch_assoc($result)) {
					$uid=$row["id"];
					echo "<tr> <td>". $row["subject"]."</td> <td>" . $row["paper_name"]. "</td> <td>" . $row["paper_time"]."</td>".
						"<td><a href='question_remove.php?user_id_de=".$uid."'>Remove</a></td>".
						"</tr><br>";
				}
			}else {
				echo "not found..!!";
			}
		?>
	</table>
</center>
<hr/><br>
<a href="admin.php">Go To Your Dashboard</a>
<br>
<a href="logout.php">Logout</a>
</body>
</html>

<?php
	if(isset($_GET["user_id_de"]))
	{
		$uid = $_GET["user_id_de"];
		$sql5= "select * from `mcq_question` where `paper_id`= '$uid'";
		$reaut = mysqli_query($conn,$sql5);
		
		while($row = mysqli_fetch_array($reaut)){
			$qes = $row['ques_id'];
			$sql2 = "select * from `mcq_option` where `ques_id`= '$qes'";
			$reaut1 = mysqli_query($conn,$sql2);
			while($row1 = mysqli_fetch_array($reaut1)){
				$opte = $row1['opt_id'];
				$sql3 = "DELETE FROM `mcq_option` WHERE opt_id=$opte";
				mysqli_query($conn,$sql3);
			}
			$sql1 = "DELETE FROM `mcq_question` WHERE qus_id=$qes";
			mysqli_query($conn,$sql1);
		}
		$sql4 = "DELETE FROM `mcq_paper` WHERE id=$uid";
		if(!mysqli_query($conn,$sql4))
		{
			echo "Error in user_info: " . $sql . "<br>" . mysqli_error($conn);
		}

		else
			echo $msg= 'Declined';

		
// 		header("Location: question_remove.php");
	}
	
	?>