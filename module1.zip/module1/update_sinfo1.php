<?php
session_start();
    if (!isset($_SESSION["student"])) {
        header('Location: index.php');
        exit;
    } 

    require_once('mysql_conn.php');
    $sql = "SELECT * FROM user_info";
    $result = mysqli_query($conn,$sql);
    while($row = mysqli_fetch_array($result))
    {
        $user_id= $row['user_id'];
        if($_SESSION["student"] == $user_id)
        {
        $msg="";
        $name = $_REQUEST['fname'];
        $email = $_REQUEST['email'];
        // $dob = $_REQUEST['dob'];
        $edu = $_REQUEST['edu'];
        $phone = $_REQUEST['phone'];
        $address = $_REQUEST['address'];        
        $password = $_REQUEST['pass'];

        $sql1 = "UPDATE `user_info` SET `full_name`='$name',`email`='$email',`edu`='$edu',`phn`='$phone',`address`='$address' WHERE user_id='$user_id'";
                if(!mysqli_query($conn,$sql1))
                    {
                        echo "Error in user_info: " . $sql. "<br>" . mysqli_error($conn);
                    }


        $sql2 ="UPDATE `users` SET `pass`='$password' WHERE user_id='$user_id'";
                if(!mysqli_query($conn,$sql2))
                    {
                        echo "Error in users: " . $sql1 . "<br>" . mysqli_error($conn);
                    }
                else
                {
                    $msg= 'Data Successfully Updated';
                }
        }
        
    }
            
?>
<html>
<head><title>Student Dashboard || Online Quiz Test</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script></head>
<body>
<center>
<h1>Student Dashboard</h1>
<hr>
<h2>Update Your Profile Info.</h2>
<hr>
    <p style="color:green"><?php echo $msg; ?></p>
<br>
<a href="s_dashboard.php">Go To Your Dashboard</a>
<br>
<a href="logout.php">Logout</a>
</center>
</body>
</html>