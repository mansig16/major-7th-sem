<?php
session_start();
	if (!isset($_SESSION["admin"])) {
		header('Location: index.php');
		exit;
		}
	include "mysql_conn.php";
	

?>

<html>
<head>
	<title>Admin Panel || Online Quiz Test</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>
<body>
<center>
	<h1> Teacher Approve </h1>
	<hr/>
	<table border='1' class="table table-hover">
		
		<?php

			$sql = "SELECT t2.* FROM `users` as t1 INNER JOIN `user_info` as t2 on t1.user_id = t2.user_id WHERE `role`= 'Teacher' and `active`=0";
			$result = mysqli_query($conn,$sql);
				echo "<tr> <th>"."full name"."</th> <th>" . "education". "</th> <th>"."email". "</th> <th>" ."phone"."</th> <th>" ."address"."</th> <th>" ."User Id"."</th> <th>"."Approve"."</th><th>"."Declined"."</th>".
						"</th><br>";
			if ($result) {
				while($row = mysqli_fetch_assoc($result)) {
					$uid=$row["user_id"];
					echo "<tr> <td>". $row["full_name"]."</td> <td>" . $row["edu"]. "</td> <td>". $row["email"]. "</td> <td>" . $row["phn"]."</td> <td>" . $row["address"]."</td> <td>" . $uid."</td> <td>".
						"<a href='teacher_approve.php?user_id_ap=".$uid."'>Approve</a>".
						"</td><td><a href='teacher_approve.php?user_id_de=".$uid."'>Declined</a></td>".
						"</tr><br>";
				}
			}else {
				echo "Teacher not found..!!";
			}
		?>
	</table>
</center>
<hr/><br>
<a href="admin.php">Go To Your Dashboard</a>
<br>
<a href="logout.php">Logout</a>
</body>
</html>

<?php
	if(isset($_GET["user_id_ap"]))
	{		
			$uid = $_GET["user_id_ap"];
			$sql1 = "UPDATE `user_info` SET `active`=1 WHERE user_id='$uid'";
			if(!mysqli_query($conn,$sql1))
			{
				echo "Error in user_info: " . $sql . "<br>" . mysqli_error($conn);
			}
			else
				echo $msg= 'Approved';

// 			header("Location: teacher_approve.php");
	}
	else if(isset($_GET["user_id_de"]))
	{
		$uid = $_GET["user_id_de"];
		$sql2 = "DELETE FROM `user_info` WHERE user_id='$uid'";
		if(!mysqli_query($conn,$sql2))
		{
			echo "Error in user_info: " . $sql . "<br>" . mysqli_error($conn);
		}
		$sql3 = "DELETE FROM `users` WHERE user_id='$uid'";
		if(!mysqli_query($conn,$sql3))
		{
			echo "Error in user_info: " . $sql . "<br>" . mysqli_error($conn);
		}

		else
			echo $msg= 'Declined';
		
// 		header("Location: teacher_approve.php");
	}
	
	?>