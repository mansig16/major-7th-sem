<?php
session_start();
	
require_once('mysql_conn.php');
$err = "";
	if($_SERVER["REQUEST_METHOD"] == "POST")
		{
	 $username = $_POST['uid'];
	 $password = $_POST['pass'];

	$sql = "SELECT * FROM users";
	$result = mysqli_query($conn,$sql);
		 
		while($row = mysqli_fetch_array($result))
		{
		   $un= $row['user_id'];
		   $up= $row['pass'];
		   $acctype = $row['role'];
		   
		   
		   if($un == $username && $up == $password && $acctype=="Admin")
			{
				//echo 'success in admin';
				$_SESSION["admin"] = $username;
				header('Location: admin.php');
				exit;
			}
			else if($un == $username && $up == $password && $acctype=="Teacher")
			{
				$_SESSION["teacher"] = $username;
					header('Location: t_dashboard.php');
					exit;
				/*$sql1 = "SELECT * FROM `user_info`";
				$result1 = mysql_query($sql1);
				$row1 = mysql_fetch_array($result1);
				$active = $row1['active'];
				if ($active ==1) {
					
				}*/
			}
			else if($un == $username && $up == $password && $acctype=="Student")
			{
				$_SESSION["student"] = $username;
				header('Location: s_dashboard.php');
				exit;
				
			}
		   else
			{
				$err = 'Invalid ID or Pass';
			}
		}
	}
?>


<html>
<head><title>Home Page || Online Quiz Test</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<link href="https://fonts.googleapis.com/css?family=Libre+Baskerville&display=swap" rel="stylesheet"> 
<style>
img{
    float:left;
    height:150px;
    width:150px;
    margin-left:70px;
}
input
{
    padding:30px;
    margin:5px;
}
h1
{
   font-family: 'Libre Baskerville', serif;
}
/*body*/
/*{*/
/*    background:url("https://us.123rf.com/450wm/sergfear/sergfear1712/sergfear171200144/91603672-vector-abstract-purple-geometric-gradient-background-vector-from-polygons-triangle-vector-illustrati.jpg?ver=6");*/
/*    background-repeat:no-repeat;*/
/*    background-size:cover;*/
/*}*/
    </style>
</style>
<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script></head>
<center>
    <img src="https://media.9curry.com/uploads/organization/image/506/nit-hamirpur.png">
    <h1>NATIONAL INSTITUTE OF TECHNOLOGY,HAMIRPUR</h1>
    <h1>CSE DEPARTMENT</h1>
<h1>Login Page</h1>
<hr>
<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]) ?>" method="POST">
<table>
<tr>
<th>User ID: </th> 
<td><input type="text" id="uid" name="uid" class="form-control"></td>
</tr>
<tr>
<th>Password: </th>
<td><input type="password" id="pass" name="pass" class="form-control"></td>
</tr>
<tr>
<th> </th>
<td>		<p style="color:red"><?php echo $err; ?></p>
			<input type="submit" name="submit" value="Login" class="btn btn-primary">
</td>
</table
</form>
Are you want to be a Teacher or Student?<br>
<a href="signup.php" class="btn">Sign Up Here</a>
</center>

</html>