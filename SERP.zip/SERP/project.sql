-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 08, 2019 at 05:09 PM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project`
--

-- --------------------------------------------------------

--
-- Table structure for table `cseb_1`
--

CREATE TABLE `cseb_1` (
  `code` varchar(10) NOT NULL,
  `name` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cseb_1`
--

INSERT INTO `cseb_1` (`code`, `name`) VALUES
('CSD-113', 'Computer Fundamentals & Programming'),
('CSD-114', 'Computer Workshop'),
('CSD-115', 'Basic Electronics Engineering'),
('CSD-117', 'Physics Lab'),
('CSD-118', 'Computer Fundamentals & Programming Lab'),
('CSD-119', 'Basic Electronics Engineering Lab'),
('CSH-116', 'Engineering Economics & Management'),
('CSS-111', 'Engineering Mathematics-1'),
('CSS-112', 'Physics for Computer Engineers');

-- --------------------------------------------------------

--
-- Table structure for table `cseb_2`
--

CREATE TABLE `cseb_2` (
  `code` varchar(10) NOT NULL,
  `name` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cseb_2`
--

INSERT INTO `cseb_2` (`code`, `name`) VALUES
('CSD-124', 'Basic Electrical Engineering'),
('CSD-127', 'Engineering Graphics'),
('CSH-123', 'Communication Skills'),
('CSH-126', 'Communication Skills Lab'),
('CSS-121', 'Engineering Mathematics-2'),
('CSS-122', 'Chemistry for Computer Engineers'),
('CSS-125', 'Chemistry Lab');

-- --------------------------------------------------------

--
-- Table structure for table `cseb_3`
--

CREATE TABLE `cseb_3` (
  `code` varchar(10) NOT NULL,
  `name` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cseb_3`
--

INSERT INTO `cseb_3` (`code`, `name`) VALUES
('CSD-211', 'Discrete Structure'),
('CSD-212', 'Object Oriented Paradigm'),
('CSD-213', 'Computer Graphics'),
('CSD-214', 'Microprocessor & Interfacing'),
('CSD-215', 'Digital Electronics & Logic Design'),
('CSD-216', 'Object Oriented Paradigm Lab'),
('CSD-217', 'Computer Graphics Lab'),
('CSD-218', 'Microprocessor & Interfacing Lab'),
('CSD-219', 'Digital Electronics & Logic Design Lab'),
('CSS-210', 'Probability & Queuing Models');

-- --------------------------------------------------------

--
-- Table structure for table `cseb_4`
--

CREATE TABLE `cseb_4` (
  `code` varchar(10) NOT NULL,
  `name` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cseb_4`
--

INSERT INTO `cseb_4` (`code`, `name`) VALUES
('CSD-221', 'Computer Organization'),
('CSD-222', 'Operating System'),
('CSD-223', 'Data Structure'),
('CSD-224', 'System Software'),
('CSD-225', 'Theory of Computation'),
('CSD-226', 'Basic Environmental Science &Engineering'),
('CSD-227', 'Computer Organization Lab'),
('CSD-228', 'Operating System Lab'),
('CSD-229', 'Data Structure Lab');

-- --------------------------------------------------------

--
-- Table structure for table `cseb_5`
--

CREATE TABLE `cseb_5` (
  `code` varchar(10) NOT NULL,
  `name` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cseb_5`
--

INSERT INTO `cseb_5` (`code`, `name`) VALUES
('CSD-311', 'Modelling & Simulation'),
('CSD-312', 'Analysis & Design of Algorithms'),
('CSD-313', 'Data Base Management Systems'),
('CSD-314', 'Compiler Design'),
('CSD-315', 'Communication Engineering'),
('CSD-317', 'Modelling & Simulation Lab'),
('CSD-318', 'Data Base Management Systems Lab'),
('CSD-319', 'Compiler Design Lab'),
('CSO-316', 'Open Elective-1');

-- --------------------------------------------------------

--
-- Table structure for table `cseb_6`
--

CREATE TABLE `cseb_6` (
  `code` varchar(10) NOT NULL,
  `name` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cseb_6`
--

INSERT INTO `cseb_6` (`code`, `name`) VALUES
('CSD-320', 'Computer Networks'),
('CSD-321', 'Software Engineering'),
('CSD-322', 'Advanced Database Management Systems'),
('CSD-323', 'Digital Image Processing'),
('CSD-325', 'Computational Tools & Techniques'),
('CSD-326', 'Computer Networks Lab'),
('CSD-327', 'Software Engineering Lab'),
('CSD-328', 'Digital Image Processing Lab'),
('CSD-329', 'Seminar'),
('CSO-324', 'Open Elective-2');

-- --------------------------------------------------------

--
-- Table structure for table `cseb_7`
--

CREATE TABLE `cseb_7` (
  `code` varchar(10) NOT NULL,
  `name` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cseb_7`
--

INSERT INTO `cseb_7` (`code`, `name`) VALUES
('CSD-410', 'Information Security'),
('CSD-411', 'Advanced Computer Architecture'),
('CSD-412', 'Advanced Operating System'),
('CSD-415', 'Information Security Lab'),
('CSD-416', 'Advanced Operating System Lab'),
('CSD-417', 'Industrial Training Viva'),
('CSD-418', 'Term Paper-V'),
('CSD-419', 'Major Project-1'),
('CSE-413', 'Departmental Elective-1'),
('CSE-414', 'Departmental Elective-2');

-- --------------------------------------------------------

--
-- Table structure for table `cseb_8`
--

CREATE TABLE `cseb_8` (
  `code` varchar(10) NOT NULL,
  `name` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cseb_8`
--

INSERT INTO `cseb_8` (`code`, `name`) VALUES
('CSD-421', 'Data Ware Housing & Data Mining'),
('CSD-422', 'Mobile Computing'),
('CSD-423', 'Software Project Planning'),
('CSD-426', 'Data Ware Housing & Data Mining Lab'),
('CSD-427', 'Mobile Computing Lab'),
('CSD-428', 'Major Project-2'),
('CSD-429', 'General Proficiency'),
('CSE-424', 'Departmental Elective-3'),
('CSE-425', 'Departmental Elective-4');

-- --------------------------------------------------------

--
-- Table structure for table `registered`
--

CREATE TABLE `registered` (
  `roll` varchar(10) NOT NULL,
  `name` varchar(40) NOT NULL,
  `course` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `requested`
--

CREATE TABLE `requested` (
  `name` varchar(40) NOT NULL,
  `roll` varchar(10) NOT NULL,
  `courses` varchar(50) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `email` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `requested`
--

INSERT INTO `requested` (`name`, `roll`, `courses`, `phone`, `email`) VALUES
('Ankush Sharma', '16501', 'CSD-115', '8988789556', 'ankush1@gmail.com'),
('Ankush Sharma', '16501', 'CSH-123', '8988789556', 'ankush1@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `pass` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `role` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `pass`, `role`) VALUES
('16501', '16501', 'Student'),
('A01', 'A01', 'Admin');

-- --------------------------------------------------------

--
-- Table structure for table `user_info`
--

CREATE TABLE `user_info` (
  `user_id` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `full_name` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `edu` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gender` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phn` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `active` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user_info`
--

INSERT INTO `user_info` (`user_id`, `full_name`, `email`, `edu`, `gender`, `phn`, `address`, `active`) VALUES
('16501', 'Ankush Sharma', 'ankush1@gmail.com', 'Under Graduate', 'M', '8988789556', 'Hamirpur', 0),
('A01', 'Nishita', 'nishita@gmail.com', 'graduate', 'F', '8988784551', 'Hamirpur', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cseb_1`
--
ALTER TABLE `cseb_1`
  ADD PRIMARY KEY (`code`);

--
-- Indexes for table `cseb_2`
--
ALTER TABLE `cseb_2`
  ADD PRIMARY KEY (`code`);

--
-- Indexes for table `cseb_3`
--
ALTER TABLE `cseb_3`
  ADD PRIMARY KEY (`code`);

--
-- Indexes for table `cseb_4`
--
ALTER TABLE `cseb_4`
  ADD PRIMARY KEY (`code`);

--
-- Indexes for table `cseb_5`
--
ALTER TABLE `cseb_5`
  ADD PRIMARY KEY (`code`);

--
-- Indexes for table `cseb_6`
--
ALTER TABLE `cseb_6`
  ADD PRIMARY KEY (`code`);

--
-- Indexes for table `cseb_7`
--
ALTER TABLE `cseb_7`
  ADD PRIMARY KEY (`code`);

--
-- Indexes for table `cseb_8`
--
ALTER TABLE `cseb_8`
  ADD PRIMARY KEY (`code`);

--
-- Indexes for table `registered`
--
ALTER TABLE `registered`
  ADD PRIMARY KEY (`roll`,`course`);

--
-- Indexes for table `requested`
--
ALTER TABLE `requested`
  ADD PRIMARY KEY (`roll`,`courses`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `user_info`
--
ALTER TABLE `user_info`
  ADD PRIMARY KEY (`user_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
