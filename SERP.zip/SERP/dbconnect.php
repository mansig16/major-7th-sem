<?php
 $connection = mysqli_connect("localhost","root","");//,'root','openelectivems');
    if($connection == null)
    {
        die('error connecting database');
        return;
    }
    mysqli_select_db($connection,"mysql");

?>