<?php
$con=mysqli_connect("localhost","root","root");
mysqli_select_db($con,"project");

mysqli_query($con,"CREATE TABLE CSEB_1(code VARCHAR(10) NOT NULL, name VARCHAR(40), PRIMARY KEY(code))");
mysqli_query($con,"INSERT INTO CSEB_1 VALUES('CSS-111','Engineering Mathematics-1')");
mysqli_query($con,"INSERT INTO CSEB_1 VALUES('CSS-112','Physics for Computer Engineers')");
mysqli_query($con,"INSERT INTO CSEB_1 VALUES('CSD-113','Computer Fundamentals & Programming')");
mysqli_query($con,"INSERT INTO CSEB_1 VALUES('CSD-114','Computer Workshop')");
mysqli_query($con,"INSERT INTO CSEB_1 VALUES('CSD-115','Basic Electronics Engineering')");
mysqli_query($con,"INSERT INTO CSEB_1 VALUES('CSH-116','Engineering Economics & Management')");
mysqli_query($con,"INSERT INTO CSEB_1 VALUES('CSD-117','Physics Lab')");
mysqli_query($con,"INSERT INTO CSEB_1 VALUES('CSD-118','Computer Fundamentals & Programming Lab')");
mysqli_query($con,"INSERT INTO CSEB_1 VALUES('CSD-119','Basic Electronics Engineering Lab')");

mysqli_query($con,"CREATE TABLE CSEB_2(code VARCHAR(10) NOT NULL, name VARCHAR(40), PRIMARY KEY(code))");
mysqli_query($con,"INSERT INTO CSEB_2 VALUES('CSS-121','Engineering Mathematics-2')");
mysqli_query($con,"INSERT INTO CSEB_2 VALUES('CSS-122','Chemistry for Computer Engineers')");
mysqli_query($con,"INSERT INTO CSEB_2 VALUES('CSH-123','Communication Skills')");
mysqli_query($con,"INSERT INTO CSEB_2 VALUES('CSD-124','Basic Electrical Engineering')");
mysqli_query($con,"INSERT INTO CSEB_2 VALUES('CSS-125','Chemistry Lab')");
mysqli_query($con,"INSERT INTO CSEB_2 VALUES('CSH-126','Communication Skills Lab')");
mysqli_query($con,"INSERT INTO CSEB_2 VALUES('CSD-127','Engineering Graphics')");

mysqli_query($con,"CREATE TABLE CSEB_3(code VARCHAR(10) NOT NULL, name VARCHAR(40), PRIMARY KEY(code))");
mysqli_query($con,"INSERT INTO CSEB_3 VALUES('CSS-210','Probability & Queuing Models')");
mysqli_query($con,"INSERT INTO CSEB_3 VALUES('CSD-211','Discrete Structure')");
mysqli_query($con,"INSERT INTO CSEB_3 VALUES('CSD-212','Object Oriented Paradigm')");
mysqli_query($con,"INSERT INTO CSEB_3 VALUES('CSD-213','Computer Graphics')");
mysqli_query($con,"INSERT INTO CSEB_3 VALUES('CSD-214','Microprocessor & Interfacing')");
mysqli_query($con,"INSERT INTO CSEB_3 VALUES('CSD-215','Digital Electronics & Logic Design')");
mysqli_query($con,"INSERT INTO CSEB_3 VALUES('CSD-216','Object Oriented Paradigm Lab')");
mysqli_query($con,"INSERT INTO CSEB_3 VALUES('CSD-217','Computer Graphics Lab')");
mysqli_query($con,"INSERT INTO CSEB_3 VALUES('CSD-218','Microprocessor & Interfacing Lab')");
mysqli_query($con,"INSERT INTO CSEB_3 VALUES('CSD-219','Digital Electronics & Logic Design Lab')");

mysqli_query($con,"CREATE TABLE CSEB_4(code VARCHAR(10) NOT NULL, name VARCHAR(40), PRIMARY KEY(code))");
mysqli_query($con,"INSERT INTO CSEB_4 VALUES('CSD-221','Computer Organization')");
mysqli_query($con,"INSERT INTO CSEB_4 VALUES('CSD-222','Operating System')");
mysqli_query($con,"INSERT INTO CSEB_4 VALUES('CSD-223','Data Structure')");
mysqli_query($con,"INSERT INTO CSEB_4 VALUES('CSD-224','System Software')");
mysqli_query($con,"INSERT INTO CSEB_4 VALUES('CSD-225','Theory of Computation')");
mysqli_query($con,"INSERT INTO CSEB_4 VALUES('CSD-226','Basic Environmental Science &Engineering')");
mysqli_query($con,"INSERT INTO CSEB_4 VALUES('CSD-227','Computer Organization Lab')");
mysqli_query($con,"INSERT INTO CSEB_4 VALUES('CSD-228','Operating System Lab')");
mysqli_query($con,"INSERT INTO CSEB_4 VALUES('CSD-229','Data Structure Lab')");

mysqli_query($con,"CREATE TABLE CSEB_5(code VARCHAR(10) NOT NULL, name VARCHAR(40), PRIMARY KEY(code))");
mysqli_query($con,"INSERT INTO CSEB_5 VALUES('CSD-311','Modelling & Simulation')");
mysqli_query($con,"INSERT INTO CSEB_5 VALUES('CSD-312','Analysis & Design of Algorithms')");
mysqli_query($con,"INSERT INTO CSEB_5 VALUES('CSD-313','Data Base Management Systems')");
mysqli_query($con,"INSERT INTO CSEB_5 VALUES('CSD-314','Compiler Design')");
mysqli_query($con,"INSERT INTO CSEB_5 VALUES('CSD-315','Communication Engineering')");
mysqli_query($con,"INSERT INTO CSEB_5 VALUES('CSO-316','Open Elective-1')");
mysqli_query($con,"INSERT INTO CSEB_5 VALUES('CSD-317','Modelling & Simulation Lab')");
mysqli_query($con,"INSERT INTO CSEB_5 VALUES('CSD-318','Data Base Management Systems Lab')");
mysqli_query($con,"INSERT INTO CSEB_5 VALUES('CSD-319','Compiler Design Lab')");

mysqli_query($con,"CREATE TABLE CSEB_6(code VARCHAR(10) NOT NULL, name VARCHAR(40), PRIMARY KEY(code))");
mysqli_query($con,"INSERT INTO CSEB_6 VALUES('CSD-320','Computer Networks')");
mysqli_query($con,"INSERT INTO CSEB_6 VALUES('CSD-321','Software Engineering')");
mysqli_query($con,"INSERT INTO CSEB_6 VALUES('CSD-322','Advanced Database Management Systems')");
mysqli_query($con,"INSERT INTO CSEB_6 VALUES('CSD-323','Digital Image Processing')");
mysqli_query($con,"INSERT INTO CSEB_6 VALUES('CSO-324','Open Elective-2')");
mysqli_query($con,"INSERT INTO CSEB_6 VALUES('CSD-325','Computational Tools & Techniques')");
mysqli_query($con,"INSERT INTO CSEB_6 VALUES('CSD-326','Computer Networks Lab')");
mysqli_query($con,"INSERT INTO CSEB_6 VALUES('CSD-327','Software Engineering Lab')");
mysqli_query($con,"INSERT INTO CSEB_6 VALUES('CSD-328','Digital Image Processing Lab')");
mysqli_query($con,"INSERT INTO CSEB_6 VALUES('CSD-329','Seminar')");

mysqli_query($con,"CREATE TABLE CSEB_7(code VARCHAR(10) NOT NULL, name VARCHAR(40), PRIMARY KEY(code))");
mysqli_query($con,"INSERT INTO CSEB_7 VALUES('CSD-410','Information Security')");
mysqli_query($con,"INSERT INTO CSEB_7 VALUES('CSD-411','Advanced Computer Architecture')");
mysqli_query($con,"INSERT INTO CSEB_7 VALUES('CSD-412','Advanced Operating System')");
mysqli_query($con,"INSERT INTO CSEB_7 VALUES('CSE-413','Departmental Elective-1')");
mysqli_query($con,"INSERT INTO CSEB_7 VALUES('CSE-414','Departmental Elective-2')");
mysqli_query($con,"INSERT INTO CSEB_7 VALUES('CSD-415','Information Security Lab')");
mysqli_query($con,"INSERT INTO CSEB_7 VALUES('CSD-416','Advanced Operating System Lab')");
mysqli_query($con,"INSERT INTO CSEB_7 VALUES('CSD-417','Industrial Training Viva')");
mysqli_query($con,"INSERT INTO CSEB_7 VALUES('CSD-418','Term Paper-V')");
mysqli_query($con,"INSERT INTO CSEB_7 VALUES('CSD-419','Major Project-1')");

mysqli_query($con,"CREATE TABLE CSEB_8(code VARCHAR(10) NOT NULL, name VARCHAR(40), PRIMARY KEY(code))");
mysqli_query($con,"INSERT INTO CSEB_8 VALUES('CSD-421','Data Ware Housing & Data Mining')");
mysqli_query($con,"INSERT INTO CSEB_8 VALUES('CSD-422','Mobile Computing')");
mysqli_query($con,"INSERT INTO CSEB_8 VALUES('CSD-423','Software Project Planning')");
mysqli_query($con,"INSERT INTO CSEB_8 VALUES('CSE-424','Departmental Elective-3')");
mysqli_query($con,"INSERT INTO CSEB_8 VALUES('CSE-425','Departmental Elective-4')");
mysqli_query($con,"INSERT INTO CSEB_8 VALUES('CSD-426','Data Ware Housing & Data Mining Lab')");
mysqli_query($con,"INSERT INTO CSEB_8 VALUES('CSD-427','Mobile Computing Lab')");
mysqli_query($con,"INSERT INTO CSEB_8 VALUES('CSD-428','Major Project-2')");
mysqli_query($con,"INSERT INTO CSEB_8 VALUES('CSD-429','General Proficiency')");
?>