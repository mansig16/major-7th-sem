<?php
 $connection = mysqli_connect("localhost",'root','root','openelectivems');
    if($connection == null)
    {
        die('error connecting database');
        return;
    }
    // mysql_select_db('online_quiz', $conn);

?>