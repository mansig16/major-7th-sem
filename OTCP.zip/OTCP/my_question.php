<?php
	include "mysql_conn.php";
	session_start();
	$userid = $_SESSION["teacher"];
?>

<!DOCTYPE html>
<html class="csstransforms csstransforms3d csstransitions ua-gecko ua-gecko-70 ua-gecko-70-0 ua-firefox ua-firefox-70 ua-firefox-70-0 ua-desktop ua-desktop-linux js js flexbox canvas canvastext webgl no-touch geolocation postmessage no-websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients no-cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers applicationcache svg inlinesvg smil svgclippaths" prefix="og: http://ogp.me/ns# fb: http://ogp.me/ns/fb#" data-useragent="Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:70.0) Gecko/20100101 Firefox/70.0" style="overflow-y: auto;" lang="en-US">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="dns-prefetch" href="//s.w.org">
<link rel="alternate" type="application/rss+xml" title="National Institute of Technology Hamirpur » Feed" href="https://nith.ac.in/?feed=rss2">
<link rel="alternate" type="application/rss+xml" title="National Institute of Technology Hamirpur » Comments Feed" href="https://nith.ac.in/?feed=comments-rss2">
<meta property="og:title" content="Alumni Association">
<meta property="og:type" content="article">
<meta property="og:url" content="https://nith.ac.in/?page_id=12049">
<meta property="og:site_name" content="National Institute of Technology Hamirpur">
<meta property="og:description" content="Alumni">
<meta property="og:image" content="http://nith.ac.in/wp-content/uploads/2018/07/newlogo.png">

<script type="text/javascript">
	window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/2\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/2\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/nith.ac.in\/wp-includes\/js\/wp-emoji-release.min.js?ver=4.6.1"}};
	!function(a,b,c){function d(a){var c,d,e,f,g,h=b.createElement("canvas"),i=h.getContext&&h.getContext("2d"),j=String.fromCharCode;if(!i||!i.fillText)return!1;switch(i.textBaseline="top",i.font="600 32px Arial",a){case"flag":return i.fillText(j(55356,56806,55356,56826),0,0),!(h.toDataURL().length<3e3)&&(i.clearRect(0,0,h.width,h.height),i.fillText(j(55356,57331,65039,8205,55356,57096),0,0),c=h.toDataURL(),i.clearRect(0,0,h.width,h.height),i.fillText(j(55356,57331,55356,57096),0,0),d=h.toDataURL(),c!==d);case"diversity":return i.fillText(j(55356,57221),0,0),e=i.getImageData(16,16,1,1).data,f=e[0]+","+e[1]+","+e[2]+","+e[3],i.fillText(j(55356,57221,55356,57343),0,0),e=i.getImageData(16,16,1,1).data,g=e[0]+","+e[1]+","+e[2]+","+e[3],f!==g;case"simple":return i.fillText(j(55357,56835),0,0),0!==i.getImageData(16,16,1,1).data[0];case"unicode8":return i.fillText(j(55356,57135),0,0),0!==i.getImageData(16,16,1,1).data[0];case"unicode9":return i.fillText(j(55358,56631),0,0),0!==i.getImageData(16,16,1,1).data[0]}return!1}function e(a){var c=b.createElement("script");c.src=a,c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var f,g,h,i;for(i=Array("simple","flag","unicode8","diversity","unicode9"),c.supports={everything:!0,everythingExceptFlag:!0},h=0;h<i.length;h++)c.supports[i[h]]=d(i[h]),c.supports.everything=c.supports.everything&&c.supports[i[h]],"flag"!==i[h]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[i[h]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(g=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",g,!1),a.addEventListener("load",g,!1)):(a.attachEvent("onload",g),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),f=c.source||{},f.concatemoji?e(f.concatemoji):f.wpemoji&&f.twemoji&&(e(f.twemoji),e(f.wpemoji)))}(window,document,window._wpemojiSettings);
</script>
<script src="https://nith.ac.in/wp-includes/js/wp-emoji-release.min.js?ver=4.6.1" type="text/javascript"></script>
<script type="text/javascript">
    var doc = document.documentElement;
    doc.setAttribute('data-useragent', navigator.userAgent);
</script>
        
<link rel="stylesheet" href="https://nith.ac.in/wp-content/themes/avada/css/bootstrap.min.css">
<link rel="stylesheet" href="https://nith.ac.in/wp-content/themes/avada/css/responsive.css">
<link rel="stylesheet" href="https://nith.ac.in/wp-content/themes/avada/css/style.css">

<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>

<link rel="stylesheet" id="style2-os-css-css" href="https://nith.ac.in/wp-content/plugins/gallery-images/style/style2-os.css?ver=4.6.1" type="text/css" media="all">
<link rel="stylesheet" id="lightbox-css-css" href="https://nith.ac.in/wp-content/plugins/gallery-images/style/lightbox.css?ver=4.6.1" type="text/css" media="all">
<link rel="stylesheet" id="fontawesome-css-css" href="https://nith.ac.in/wp-content/plugins/gallery-images/style/css/font-awesome.css?ver=4.6.1" type="text/css" media="all">
<link rel="stylesheet" id="cssnews-css" href="https://nith.ac.in/wp-content/plugins/sp-news-and-widget/css/stylenews.css?ver=3.2.7" type="text/css" media="all">
<link rel="stylesheet" id="vsel_style-css" href="https://nith.ac.in/wp-content/plugins/very-simple-event-list/css/vsel-style.css?ver=4.6.1" type="text/css" media="all">
<link rel="stylesheet" id="font-awesome-css" href="https://nith.ac.in/wp-content/plugins/wonderplugin-tabs/font-awesome/css/font-awesome.min.css?ver=4.6.1" type="text/css" media="all">
<link rel="stylesheet" id="wonderplugin-tabs-engine-css-css" href="https://nith.ac.in/wp-content/plugins/wonderplugin-tabs/engine/wonderplugin-tabs-engine.css?ver=4.6.1" type="text/css" media="all">
<link rel="stylesheet" id="avada-stylesheet-css" href="https://nith.ac.in/wp-content/themes/avada/style.css?ver=3.9.3" type="text/css" media="all">
<link rel="stylesheet" id="fontawesome-css" href="https://nith.ac.in/wp-content/themes/avada/assets/fonts/fontawesome/font-awesome.css?ver=3.9.3" type="text/css" media="all">
<link rel="stylesheet" id="avada-iLightbox-css" href="https://nith.ac.in/wp-content/themes/avada/ilightbox.css?ver=3.9.3" type="text/css" media="all">
<link rel="stylesheet" id="avada-animations-css" href="https://nith.ac.in/wp-content/themes/avada/animations.css?ver=3.9.3" type="text/css" media="all">

<script type="text/javascript" src="https://nith.ac.in/wp-includes/js/jquery/jquery.js?ver=1.12.4"></script>
<script type="text/javascript" src="https://nith.ac.in/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1"></script>
<script type="text/javascript" src="https://nith.ac.in/wp-content/plugins/sp-news-and-widget/js/jquery.newstape.js?ver=3.2.7"></script>
<script type="text/javascript" src="https://nith.ac.in/wp-content/plugins/wonderplugin-carousel/engine/wonderplugincarouselskins.js?ver=8.3"></script>
<script type="text/javascript" src="https://nith.ac.in/wp-content/plugins/wonderplugin-carousel/engine/wonderplugincarousel.js?ver=8.3"></script>
<script type="text/javascript" src="https://nith.ac.in/wp-content/plugins/wonderplugin-gallery/engine/wonderplugingallery.js?ver=8.4"></script>
<script type="text/javascript" src="https://nith.ac.in/wp-content/plugins/wonderplugin-tabs/engine/wonderplugin-tabs-engine.js?ver=3.0"></script>

<link rel="https://api.w.org/" href="https://nith.ac.in/?rest_route=/">
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://nith.ac.in/xmlrpc.php?rsd">
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://nith.ac.in/wp-includes/wlwmanifest.xml"> 
<meta name="generator" content="WordPress 4.6.1">
<link rel="canonical" href="https://nith.ac.in/?page_id=12049">
<link rel="shortlink" href="https://nith.ac.in/?p=12049">
<link rel="alternate" type="application/json+oembed" href="https://nith.ac.in/?rest_route=%2Foembed%2F1.0%2Fembed&amp;url=https%3A%2F%2Fnith.ac.in%2F%3Fpage_id%3D12049">
<link rel="alternate" type="text/xml+oembed" href="https://nith.ac.in/?rest_route=%2Foembed%2F1.0%2Fembed&amp;url=https%3A%2F%2Fnith.ac.in%2F%3Fpage_id%3D12049&amp;format=xml">

<style id="avada-stylesheet-inline-css" type="text/css">
	.Avada_393{color:green;}
	body,html,html 
	body.custom-background{background-color:#d8d8d8;}
	.fusion-mobile-menu-design-modern 
	.fusion-mobile-nav-holder li a
	{padding-left:30px;padding-right:30px;}
	.fusion-mobile-menu-design-modern 
	.fusion-mobile-nav-holder 
	.fusion-mobile-nav-item 
	.fusion-open-submenu{
		padding-right:35px;
	}
	.fusion-mobile-menu-design-modern 
	.fusion-mobile-nav-holder 
	.fusion-mobile-nav-item 
	a{
		padding-left:30px;
		padding-right:30px;
	}
	.fusion-mobile-menu-design-modern 
	.fusion-mobile-nav-holder
	.fusion-mobile-nav-item li a{
		padding-left:39px;
	}
	.fusion-mobile-menu-design-modern 
	.fusion-mobile-nav-holder 
	.fusion-mobile-nav-item li li a{
		padding-left:48px;
	}
	.fusion-mobile-menu-design-modern 
	.fusion-mobile-nav-holder 
	.fusion-mobile-nav-item li li li a{
		padding-left:57px;
	}
	.fusion-mobile-menu-design-modern 
	.fusion-mobile-nav-holder 
	.fusion-mobile-nav-item li li li li a{
		padding-left:66px;
	}
	.event-is-recurring:hover,.tooltip-shortcode,a:hover{
		color:#640f12;
	}
	#main 
	.about-author 
	.title 
	a:hover,#main 
	.post 
	h2 a:hover,#slidingbar-area 
	.fusion-accordian 
	.panel-title a:hover,#slidingbar-area ul li a:hover,#wrapper 
	.fusion-widget-area 
	.current-menu-item > a,#wrapper 
	.fusion-widget-area 
	.current-menu-item > a:before,#wrapper .fusion-widget-area .current_page_item > a,#wrapper .fusion-widget-area .current_page_item > a:before,#wrapper .jtwt .jtwt_tweet a:hover,.content-box-percentage,.fusion-accordian .panel-title a:hover,.fusion-content-widget-area .widget .recentcomments:hover:before,.fusion-content-widget-area .widget li a:hover,.fusion-content-widget-area .widget li a:hover:before,.fusion-content-widget-area .widget_archive li a:hover:before,.fusion-content-widget-area .widget_categories li a:hover,.fusion-content-widget-area .widget_categories li a:hover:before,.fusion-content-widget-area .widget_links li a:hover:before,.fusion-content-widget-area .widget_nav_menu li a:hover:before,.fusion-content-widget-area .widget_pages li a:hover:before,.fusion-content-widget-area .widget_recent_entries li a:hover:before,.fusion-copyright-notice a:hover,.fusion-date-and-formats .fusion-format-box i,.fusion-filters .fusion-filter.fusion-active a,.fusion-footer-widget-area .fusion-accordian .panel-title a:hover,.fusion-footer-widget-area .fusion-tabs-widget .tab-holder .news-list li .post-holder a:hover,.fusion-footer-widget-area .widget li a:hover:before,.fusion-footer-widget-area a:hover,.fusion-footer-widget-area ul li a:hover,.fusion-login-box a:hover,.fusion-popover,.fusion-read-more:hover:after,.more a:hover:after,.pagination-next:hover:after,.pagination-prev:hover:before,.price > .amount,.price ins .amount,.project-content .project-info .project-info-box a:hover,.side-nav .arrow:hover:after,.side-nav li.current_page_ancestor > a,.side-nav ul > li.current_page_item > a,.single-navigation a[rel=next]:hover:after,.single-navigation a[rel=prev]:hover:before,.slidingbar-area .widget li a:hover:before,.slidingbar-area a:hover,.star-rating span:before,.star-rating:before,.tooltip-shortcode,h5.toggle:hover a,span.dropcap{
		color:#640f12;
	}
	.fusion-accordian .panel-title a:hover .fa-fusion-box{
		background-color:#640f12 !important;border-color:#640f12 !important;
	}
	.fusion-content-widget-area .fusion-image-wrapper .fusion-rollover .fusion-rollover-content a:hover{
		color:#333333;
	}
	.star-rating span:before,.star-rating:before{
		color:#640f12;
	}
	#slidingbar-area .tagcloud a:hover,.fusion-footer-widget-area .tagcloud a:hover,.tagcloud a:hover{
		color:#FFFFFF;text-shadow:none;-webkit-text-shadow:none;-moz-text-shadow:none;
	}
	#nav ul li > a:hover,#sticky-nav ul li > a:hover,#wrapper .fusion-tabs-widget .tab-holder .tabs li.active a,#wrapper .fusion-tabs.classic .nav-tabs > li.active .tab-link,#wrapper .fusion-tabs.classic .nav-tabs > li.active .tab-link:focus,#wrapper .fusion-tabs.classic .nav-tabs > li.active .tab-link:hover,#wrapper .fusion-tabs.vertical-tabs.classic .nav-tabs > li.active .tab-link,#wrapper .post-content blockquote,.fusion-filters .fusion-filter.fusion-active a,.fusion-hide-pagination-text .pagination-next:hover,.fusion-hide-pagination-text .pagination-prev:hover,.pagination .current,.pagination a.inactive:hover,.progress-bar-content,.reading-box,.tagcloud a:hover{
		border-color:#640f12;
	}
		#wrapper .side-nav li.current_page_item a{
			border-right-color:#640f12;border-left-color:#640f12;
		}
		#toTop:hover,#wrapper .search-table .search-button input[type="submit"]:hover,.circle-yes ul li:before,.fusion-accordian .panel-title .active .fa-fusion-box,.fusion-date-and-formats .fusion-date-box,.pagination .current,.progress-bar-content,.table-2 table thead,.tagcloud a:hover,ul.arrow li:before,ul.circle-yes li:before
		background-color:#640f12;
		}
		#slidingbar{
			background-color:#363839;background-color:rgba(54,56,57,1);
		}
		.sb-toggle-wrapper{
			border-top-color:#363839;border-top-color:rgba( 54,56,57,1);
		}
		#wrapper #slidingbar-area .fusion-tabs-widget .tab-holder .tabs li
		border-color:#363839;border-color:rgba( 54,56,57,1);
		}
		#fusion-gmap-container,#main,#sliders-container,#wrapper,.fusion-separator .icon-wrapper,body,html
{
	background-color:#f2f2f2;
}
.fusion-footer-widget-area
{
	background-color:#02263c;border-color:#e9eaee;padding-top:40px;padding-bottom:13px;
}
#wrapper .fusion-footer-widget-area .fusion-tabs-widget .tab-holder .tabs li
{
	border-color:#02263c;
}
.fusion-footer-copyright-area
{
	background-color:#336699;border-color:#4b4c4d;padding-top:18px;padding-bottom:16px;
}
.sep-boxed-pricing .panel-heading
{
	background-color:#a0ce4e;border-color:#a0ce4e;
}
.full-boxed-pricing.fusion-pricing-table .standout .panel-heading h3,.fusion-pricing-table .panel-body .price .decimal-part,.fusion-pricing-table .panel-body .price .integer-part
{
	color:#a0ce4e;
}
.fusion-image-wrapper .fusion-rollover
{
	background-image:linear-gradient(top, rgba(160,206,78,0.8) 0%, rgba(160,206,78,0.8) 100%);background-image:-webkit-gradient(linear, left top, left bottom, color-stop(0, rgba(160,206,78,0.8)), color-stop(1, rgba(160,206,78,0.8)));background-image:filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=#a0ce4e, endColorstr=#a0ce4e), progid: DXImageTransform.Microsoft.Alpha(Opacity=0);background-image:-webkit-linear-gradient(top, rgba(160,206,78,0.8) 0%, rgba(160,206,78,0.8) 100%);background-image:-moz-linear-gradient(top, rgba(160,206,78,0.8) 0%, rgba(160,206,78,0.8) 100%);background-image:-ms-linear-gradient(top, rgba(160,206,78,0.8) 0%, rgba(160,206,78,0.8) 100%);background-image:-o-linear-gradient(top, rgba(160,206,78,0.8) 0%, rgba(160,206,78,0.8) 100%);
}
.no-cssgradients .fusion-image-wrapper .fusion-rollover
{
	background:#a0ce4e;
}
.fusion-image-wrapper:hover .fusion-rollover
{
	filter:progid:DXImageTransform.Microsoft.gradient(startColorstr=#a0ce4e, endColorstr=#a0ce4e), progid: DXImageTransform.Microsoft.Alpha(Opacity=100);
}
#main .comment-submit,#reviews input#submit,.button-default,.button.default,.comment-form input[type="submit"],.fusion-button-default,.fusion-portfolio-one .fusion-button,.post-password-form input[type="submit"],.ticket-selector-submit-btn[type=submit]
{
	background:#a0ce4e;color:#ffffff;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr=#a0ce4e, endColorstr=#a0ce4e);transition:all .2s;-webkit-transition:all .2s;-moz-transition:all .2s;-ms-transition:all .2s;-o-transition:all .2s;
}
.link-type-button-bar .fusion-read-more,.no-cssgradients #main .comment-submit,.no-cssgradients #reviews input#submit,.no-cssgradients .button-default,.no-cssgradients .button.default,.no-cssgradients .comment-form input[type="submit"],.no-cssgradients .fusion-button-default,.no-cssgradients .fusion-portfolio-one .fusion-button,.no-cssgradients .post-password-form input[type="submit"],.no-cssgradients .ticket-selector-submit-btn[type="submit"]
{
	background:#a0ce4e;
}
#main .comment-submit:hover,#reviews input#submit:hover,.button-default:hover,.button.default:hover,.comment-form input[type="submit"]:hover,.fusion-button-default:hover,.fusion-portfolio-one .fusion-button:hover,.post-password-form input[type="submit"]:hover,.ticket-selector-submit-btn[type="submit"]:hover
{
	background:#96c346;color:#ffffff;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr=#96c346, endColorstr=#96c346);
}
.no-cssgradients #main .comment-submit:hover,.no-cssgradients #reviews input#submit:hover,.no-cssgradients .button-default:hover,.no-cssgradients .comment-form input[type="submit"]:hover,.no-cssgradients .fusion-button-default:hover,.no-cssgradients .fusion-portfolio-one .fusion-button:hover,.no-cssgradients .ticket-selector-submit-btn[type="submit"]:hover,.no-cssgradinets .button.default:hover,.no-cssgradinets .post-password-form input[type="submit"]:hover
{
	background:#96c346 !important;
}
.link-type-button-bar .fusion-read-more,.link-type-button-bar .fusion-read-more:after,.link-type-button-bar .fusion-read-more:before
{
	color:#ffffff;
}
.link-type-button-bar .fusion-read-more:hover,.link-type-button-bar .fusion-read-more:hover:after,.link-type-button-bar .fusion-read-more:hover:before,.link-type-button-bar.link-area-box:hover .fusion-read-more,.link-type-button-bar.link-area-box:hover .fusion-read-more:after,.link-type-button-bar.link-area-box:hover .fusion-read-more:before
{
	color:#ffffff !important;
}
.fusion-image-wrapper .fusion-rollover .fusion-rollover-gallery,.fusion-image-wrapper .fusion-rollover .fusion-rollover-link
{
	background-color:#333333;width:36px;height:36px;
}
.fusion-image-wrapper .fusion-rollover .fusion-rollover-content .fusion-product-buttons a:before,.fusion-image-wrapper .fusion-rollover .fusion-rollover-content .fusion-rollover-categories,.fusion-image-wrapper .fusion-rollover .fusion-rollover-content .fusion-rollover-categories a,.fusion-image-wrapper .fusion-rollover .fusion-rollover-content .fusion-rollover-title a,.fusion-image-wrapper .fusion-rollover .fusion-rollover-content .price *,.fusion-image-wrapper .fusion-rollover .fusion-rollover-content a,.fusion-rollover .fusion-rollover-content .fusion-rollover-title
{
	color:#333333;
}
.fusion-page-title-bar
{
	border-color:#f2f2f2;background-image:url("http://nith.ac.in/nith/wp-content/themes/avada/assets/images/page_title_bg.png");background-color:#F6F6F6;height:87px;
}
.fusion-footer-copyright-area > .fusion-row,.fusion-footer-widget-area > .fusion-row
{
	padding-left:0px;padding-right:0px;
}
.fontawesome-icon.circle-yes
{
	background-color:#333333;
}
.content-box-shortcode-timeline,.fontawesome-icon.circle-yes
{
	border-color:#333333;
}
.fontawesome-icon,.fontawesome-icon.circle-yes,.post-content .error-menu li:after,.post-content .error-menu li:before
{
	color:#ffffff;
}
.fusion-title .title-sep,.fusion-title.sep-underline,.product .product-border
{
	border-color:#e0dede;
}
.checkout .payment_methods .payment_box,.post-content blockquote,.review blockquote q
{
	background-color:#f6f6f6;
}
.fusion-testimonials .author:after
{
	border-top-color:#f6f6f6;
}
.post-content blockquote,.review blockquote q
{
	color:#747474;
}
#nav ul li ul li a,#sticky-nav ul li ul li a,#wrapper #nav ul li ul li > a,#wrapper #sticky-nav ul li ul li > a,.avada-container h3,.comment-form input[type="submit"],.ei-title h3,.fusion-blog-shortcode .fusion-timeline-date,.fusion-image-wrapper .fusion-rollover .fusion-rollover-content .fusion-rollover-categories,.fusion-image-wrapper .fusion-rollover .fusion-rollover-content .fusion-rollover-title,.fusion-image-wrapper .fusion-rollover .fusion-rollover-content .price,.fusion-image-wrapper .fusion-rollover .fusion-rollover-content a,.fusion-load-more-button,.fusion-page-title-bar h3,.meta .fusion-date,.more,.post-content blockquote,.project-content .project-info h4,.review blockquote div strong,.review blockquote q,.ticket-selector-submit-btn[type="submit"],body
{
	font-family:Verdana, Geneva, sans-serif;font-weight:400;
}
#slidingbar-area h3,.avada-container h3,.comment-form input[type="submit"],.fusion-footer-widget-area .widget-title,.fusion-footer-widget-area h3,.fusion-load-more-button,.project-content .project-info h4,.review blockquote div strong,.ticket-selector-submit-btn[type="submit"]
{
	font-weight:bold;
}
.meta .fusion-date,.post-content blockquote,.review blockquote q
{
	font-style:italic;
}
.side-nav li a
{
	font-family:Verdana, Geneva, sans-serif;font-weight:400;font-size:12px;
}
#main .post h2,#main .reading-box h2,#main h2,#wrapper .fusion-tabs-widget .tab-holder .tabs li a,.ei-title h2,.fusion-accordian .panel-heading a,.fusion-accordian .panel-title,.fusion-author .fusion-author-title,.fusion-carousel-title,.fusion-content-widget-area .widget h4,.fusion-countdown-heading,.fusion-countdown-subheading,.fusion-flip-box .flip-box-heading-back,.fusion-header-tagline,.fusion-image-wrapper .fusion-rollover .fusion-rollover-content .fusion-rollover-title,.fusion-image-wrapper .fusion-rollover .fusion-rollover-content .fusion-rollover-title a,.fusion-modal .modal-title,.fusion-page-title-bar h1,.fusion-person .person-desc .person-author .person-author-wrapper,.fusion-pricing-table .pricing-row,.fusion-pricing-table .title-row,.fusion-tabs .nav-tabs  li .fusion-tab-heading,.fusion-title h3,.main-flex .slide-content h2,.main-flex .slide-content h3,.popover .popover-title,.post-content h1,.post-content h2,.post-content h3,.post-content h4,.post-content h5,.post-content h6,.project-content h3,.share-box h4,table th
{
	font-family:Verdana, Geneva, sans-serif;
}
.project-content .project-info h4
{
	font-family:Verdana, Geneva, sans-serif;
}
#main .post h2,#main .reading-box h2,#main h2,#wrapper .fusion-tabs-widget .tab-holder .tabs li a,.ei-title h2,.fusion-accordian .panel-heading a,.fusion-accordian .panel-title,.fusion-author .fusion-author-title,.fusion-carousel-title,.fusion-content-widget-area .widget h4,.fusion-flip-box .flip-box-heading-back,.fusion-header-tagline,.fusion-image-wrapper .fusion-rollover .fusion-rollover-content .fusion-rollover-title,.fusion-image-wrapper .fusion-rollover .fusion-rollover-content .fusion-rollover-title a,.fusion-modal .modal-title,.fusion-page-title-bar h1,.fusion-person .person-desc .person-author .person-author-wrapper,.fusion-pricing-table .pricing-row,.fusion-pricing-table .title-row,.fusion-tabs .nav-tabs  li .fusion-tab-heading,.fusion-title h3,.main-flex .slide-content h2,.main-flex .slide-content h3,.popover .popover-title,.post-content h1,.post-content h2,.post-content h3,.post-content h4,.post-content h5,.post-content h6,.project-content h3,.share-box h4,table th
{
	font-weight:400;
}
#slidingbar-area .widget-title,#slidingbar-area h3,.fusion-footer-widget-area .widget-title,.fusion-footer-widget-area h3
{
	font-family:Verdana, Geneva, sans-serif;font-weight:400;
}
.fusion-content-widget-area .jtwt .jtwt_tweet,.fusion-widget-area .slide-excerpt h2,.jtwt .jtwt_tweet,body
{
	font-size:11px;line-height:17px;
}
#slidingbar-area ul,.fusion-footer-widget-area ul,.fusion-tabs-widget .tab-holder .news-list li .post-holder .meta,.fusion-tabs-widget .tab-holder .news-list li .post-holder a,.project-content .project-info h4
{
	font-size:11px;line-height:17px;
}
.counter-box-content,.fusion-alert,.fusion-blog-layout-timeline .fusion-timeline-date,.fusion-progressbar .sr-only,.post-content blockquote,.review blockquote q
{
	font-size:11px;
}
#side-header .fusion-contact-info,#side-header .header-social .top-menu,.fusion-accordian .panel-body,.fusion-widget-area .slide-excerpt h2,.post-content blockquote,.project-content .project-info h4,.review blockquote q,body
{
	line-height:20px;
}
.fusion-page-title-bar .fusion-breadcrumbs,.fusion-page-title-bar .fusion-breadcrumbs li,.fusion-page-title-bar .fusion-breadcrumbs li a
{
	font-size:10px;
}
.sidebar .widget h4
{
	font-size:11px;
}
#slidingbar-area .widget-title,#slidingbar-area h3
{
	font-size:12px;line-height:12px;
}
.fusion-footer-widget-area .widget-title,.fusion-footer-widget-area h3
{
	font-size:12px;line-height:12px;
}
.fusion-copyright-notice
{
	font-size:7px;
}
#main .fusion-row,#slidingbar-area .fusion-row,.fusion-footer-copyright-area .fusion-row,.fusion-footer-widget-area .fusion-row,.fusion-page-title-row,.tfs-slider .slide-content-container .slide-content
{
	max-width:100%;
}
.post-content h1
{
	font-size:34px;line-height:48px;
}
#main .fusion-portfolio h2,#wrapper  #main .post h2,#wrapper #main .post-content .fusion-title h2,#wrapper #main .post-content .title h2,#wrapper .fusion-title h2,#wrapper .post-content h2,#wrapper .title h2,h2.entry-title
{
	font-size:18px;line-height:41px;
}
#main .fusion-portfolio h2,#wrapper #main .post h2,#wrapper #main .post-content .fusion-title h2,#wrapper #main .post-content .title h2,#wrapper .fusion-title h2,#wrapper .post-content h2,#wrapper .title h2,h2.entry-title
{
	line-height:27px;
}
#wrapper #main .fusion-portfolio-content > h2.entry-title,#wrapper #main .fusion-post-content > .blog-shortcode-post-title,#wrapper #main .fusion-post-content > h2.entry-title,#wrapper #main .post > h2.entry-title,#wrapper .fusion-events-shortcode .fusion-events-meta h2
{
	font-size:18px;line-height:27px;
}
#wrapper #main #comments .fusion-title h3,#wrapper #main #respond .fusion-title h3,#wrapper #main .about-author .fusion-title h3,#wrapper #main .related-posts .fusion-title h3,#wrapper #main .related.products .fusion-title h3
{
	font-size:18px;line-height:27px;
}
.fusion-person .person-author-wrapper .person-name,.post-content h3,.project-content h3
{
	font-size:16px;line-height:24px;
}
.fusion-modal .modal-title
{
	font-size:16px;line-height:36px;
}
.fusion-carousel-title,.fusion-person .person-author-wrapper .person-title,.fusion-portfolio-post .fusion-portfolio-content h4,.fusion-rollover .fusion-rollover-content .fusion-rollover-title,.post-content h4
{
	font-size:13px;line-height:20px;
}
#wrapper .fusion-tabs-widget .tab-holder .tabs li a,.fusion-flip-box .flip-box-heading-back,.person-author-wrapper,.popover .popover-title
{
	font-size:13px;
}
.fusion-accordian .panel-title,.fusion-sharing-box h4,.fusion-tabs .nav-tabs > li .fusion-tab-heading,.fusion-widget-area .fusion-accordian .panel-title
{
	font-size:13px;line-height:30px;
}
.post-content h5
{
	font-size:12px;line-height:18px;
}
.post-content h6
{
	font-size:11px;line-height:17px;
}
.ei-title h2
{
	font-size:42px;line-height:63px;color:#333333;
}
.ei-title h3
{
	font-size:20px;line-height:30px;color:#747474;
}
#wrapper .fusion-events-shortcode .fusion-events-meta h4,.fusion-carousel-meta,.fusion-image-wrapper .fusion-rollover .fusion-rollover-content .fusion-rollover-categories,.fusion-image-wrapper .fusion-rollover .fusion-rollover-content .fusion-rollover-categories a,.fusion-recent-posts .columns .column .meta,.fusion-single-line-meta
{
	font-size:12px;line-height:18px;
}
.fusion-carousel-meta,.fusion-meta,.fusion-meta-info,.fusion-recent-posts .columns .column .meta,.post .single-line-meta
{
	font-size:12px;
}
.fusion-image-wrapper .fusion-rollover .fusion-rollover-content .fusion-product-buttons a,.product-buttons a
{
	font-size:12px;line-height:18px;
}
.page-links,.pagination,.pagination .pagination-next,.pagination .pagination-prev
{
	font-size:12px;
}
#wrapper .fusion-tabs-widget .tab-holder .news-list li .post-holder .meta,#wrapper .meta,.fusion-blog-timeline-layout .fusion-timeline-date,.fusion-content-widget-area .jtwt,.fusion-content-widget-area .widget .recentcomments,.fusion-content-widget-area .widget_archive li,.fusion-content-widget-area .widget_categories li,.fusion-content-widget-area .widget_links li,.fusion-content-widget-area .widget_meta li,.fusion-content-widget-area .widget_nav_menu li,.fusion-content-widget-area .widget_pages li,.fusion-content-widget-area .widget_recent_entries li,.fusion-rollover .price .amount,.post .post-content,.post-content blockquote,.project-content .project-info h4,.quantity .minus,.quantity .plus,.quantity .qty,.review blockquote div,.search input,.title-row,body
{
	color:#747474;
}
.fusion-post-content h1,.post-content h1,.title h1
{
	color:#333333;
}
#main .post h2,.cart-empty,.fusion-post-content h2,.fusion-title h2,.post-content h2,.search-page-search-form h2,.title h2
{
	color:#333333;
}
.fusion-post-content h3,.fusion-title h3,.person-author-wrapper span,.post-content h3,.product-title,.project-content h3,.title h3
{
	color:#333333;
}
#wrapper .fusion-tabs-widget .tab-holder .tabs li a,.fusion-accordian .panel-title a,.fusion-carousel-title,.fusion-content-widget-area .widget h4,.fusion-post-content h4,.fusion-tabs .nav-tabs > li .fusion-tab-heading,.fusion-title h4,.post-content h4,.project-content .project-info h4,.share-box h4,.title h4
{
	color:#333333;
}
.fusion-post-content h5,.fusion-title h5,.post-content h5,.title h5
{
	color:#333333;
}
.fusion-post-content h6,.fusion-title h6,.post-content h6,.title h6
{
	color:#333333;
}
.fusion-page-title-bar h1,.fusion-page-title-bar h3
{
	color:#333333;
}
.sep-boxed-pricing .panel-heading h3
{
	color:#333333;
}
.full-boxed-pricing.fusion-pricing-table .panel-heading h3
{
	color:#333333;
}
#main .post h2 a,.about-author .title a,.fusion-content-widget-area .widget .recentcomments,.fusion-content-widget-area .widget li a,.fusion-content-widget-area .widget li a:before,.fusion-content-widget-area .widget_categories li,.fusion-load-more-button,.fusion-rollover a,.project-content .project-info .project-info-box a,.shop_attributes tr th,.single-navigation a[rel="next"]:after,.single-navigation a[rel="prev"]:before,body a,body a:after,body a:before
{
	color:#0a0a0a;
}
body #toTop:before
{
	color:#fff;
}
.fusion-page-title-bar .fusion-breadcrumbs,.fusion-page-title-bar .fusion-breadcrumbs a
{
	color:#333333;
}
#slidingbar-area .fusion-title > *,#slidingbar-area .widget-title,#slidingbar-area h3
{
	color:#DDDDDD;
}
#slidingbar-area,#slidingbar-area .fusion-column,#slidingbar-area .jtwt,#slidingbar-area .jtwt .jtwt_tweet
{
	color:#8C8989;
}
 #slidingbar-area .jtwt .jtwt_tweet a,#slidingbar-area .fusion-accordian .panel-title a,#wrapper #slidingbar-area .fusion-tabs-widget .tab-holder .tabs li a,.slidingbar-area .widget li a:before,.slidingbar-area a
 {
 	color:#BFBFBF;
}
.sidebar .widget .heading h4,.sidebar .widget h4
{
	color:#333333;
}
.sidebar .widget .heading .widget-title,.sidebar .widget .widget-title
{
	background-color:transparent;
}
.fusion-footer-widget-area .widget-title,.fusion-footer-widget-area h3,.fusion-footer-widget-column .product-title
{
	color:#DDDDDD;
}
.fusion-copyright-notice,.fusion-footer-widget-area,.fusion-footer-widget-area .jtwt,.fusion-footer-widget-area .jtwt .jtwt_tweet,.fusion-footer-widget-area article.col
{
	color:#8C8989;
}
#wrapper .fusion-footer-widget-area .fusion-tabs-widget .tab-holder .tabs li a,.fusion-copyright-notice a,.fusion-footer-widget-area .fusion-accordian .panel-title a,.fusion-footer-widget-area .fusion-tabs-widget .tab-holder .news-list li .post-holder a,.fusion-footer-widget-area .jtwt .jtwt_tweet a,.fusion-footer-widget-area .widget li a:before,.fusion-footer-widget-area a
{
	color:#BFBFBF;
}
#customer_login .col-1,#customer_login .col-2,#customer_login h2,#customer_login_box,#reviews li .comment-text,#small-nav,#wrapper .fusion-tabs-widget .tab-holder,#wrapper .side-nav li a,#wrapper .side-nav li.current_page_item li a,.avada-skin-rev,.chzn-container-single .chzn-single,.chzn-container-single .chzn-single div,.chzn-drop,.commentlist .the-comment,.es-carousel-wrapper.fusion-carousel-small .es-carousel ul li img,.fusion-accordian .fusion-panel,.fusion-author .fusion-author-social,.fusion-blog-layout-grid .post .flexslider,.fusion-blog-layout-grid .post .fusion-content-sep,.fusion-blog-layout-grid .post .post-wrapper,.fusion-content-widget-area .widget .recentcomments,.fusion-content-widget-area .widget li a,.fusion-content-widget-area .widget_archive li,.fusion-content-widget-area .widget_categories li,.fusion-content-widget-area .widget_links li,.fusion-content-widget-area .widget_meta li,.fusion-content-widget-area .widget_nav_menu li,.fusion-content-widget-area .widget_pages li,.fusion-content-widget-area .widget_recent_entries li,.fusion-counters-box .fusion-counter-box .counter-box-border,.fusion-filters,.fusion-hide-pagination-text .pagination-next,.fusion-hide-pagination-text .pagination-prev,.fusion-layout-timeline .post,.fusion-layout-timeline .post .flexslider,.fusion-layout-timeline .post .fusion-content-sep,.fusion-portfolio .fusion-portfolio-boxed .fusion-content-sep,.fusion-portfolio .fusion-portfolio-boxed .fusion-portfolio-post-wrapper,.fusion-portfolio-one .fusion-portfolio-boxed .fusion-portfolio-post-wrapper,.fusion-tabs.vertical-tabs.clean .nav-tabs li .tab-link,.fusion-timeline-arrow,.fusion-timeline-date,.input-radio,.ls-avada,.page-links a,.pagination a.inactive,.panel.entry-content,.post .fusion-meta-info,.price_slider_wrapper,.progress-bar,.project-content .project-info .project-info-box,.quantity,.quantity .minus,.quantity .qty,.search-page-search-form,.sep-dashed,.sep-dotted,.sep-double,.sep-single,.side-nav,.side-nav li a,.single-navigation,.table,.table > tbody > tr > td,.table > tbody > tr > th,.table > tfoot > tr > td,.table > tfoot > tr > th,.table > thead > tr > td,.table > thead > tr > th,.table-1 table,.table-1 table th,.table-1 tr td,.table-2 table thead,.table-2 tr td,.tabs-vertical .tabs-container .tab_content,.tabs-vertical .tabset,.tagcloud a,.tkt-slctr-tbl-wrap-dv table,.tkt-slctr-tbl-wrap-dv tr td,h5.toggle.active + .toggle-content,tr td
{
	border-color:#e0dede;
}
.price_slider_wrapper .ui-widget-content
{
	background-color:#e0dede;
}
.fusion-load-more-button
{
	background-color:#ebeaea;
}
.fusion-load-more-button:hover
{
	background-color:rgba(235,234,234,0.8);
}
.quantity .minus,.quantity .plus
{
	background-color:#fbfaf9;
}
.quantity .minus:hover,.quantity .plus:hover
{
	background-color:#ffffff;
}
.sb-toggle-wrapper .sb-toggle:after
{
	color:#ffffff;
}
#slidingbar-area .product_list_widget li,#slidingbar-area .widget_categories li a,#slidingbar-area .widget_recent_entries ul li,#slidingbar-area li.recentcomments,#slidingbar-area ul li a
{
	border-bottom-color:#282A2B;
}
#slidingbar-area .fusion-accordian .fusion-panel,#slidingbar-area .tagcloud a,#wrapper #slidingbar-area .fusion-tabs-widget .tab-holder,#wrapper #slidingbar-area .fusion-tabs-widget .tab-holder .news-list li
{
	border-color:#282A2B;
}
#wrapper .fusion-footer-widget-area .fusion-tabs-widget .tab-holder,#wrapper .fusion-footer-widget-area .fusion-tabs-widget .tab-holder .news-list li,.fusion-footer-widget-area .fusion-accordian .fusion-panel,.fusion-footer-widget-area .product_list_widget li,.fusion-footer-widget-area .tagcloud a,.fusion-footer-widget-area .widget_categories li a,.fusion-footer-widget-area .widget_recent_entries li,.fusion-footer-widget-area li.recentcomments,.fusion-footer-widget-area ul li a
{
	border-color:#505152;
}
#comment-input input,#comment-textarea textarea,#wrapper .search-table .search-field input,.avada-select .select2-container .select2-choice,.avada-select .select2-container .select2-choice2,.avada-select-parent select,.chzn-container .chzn-drop,.chzn-container-single .chzn-single,.comment-form-comment textarea,.input-text,.main-nav-search-form input,.post-password-form label input[type="password"],.search-page-search-form input,input.s,input[type="text"],select,textarea
{
	background-color:#ffffff;
}
#wrapper .select-arrow,.avada-select-parent .select-arrow
{
	background-color:#ffffff;
}
#comment-input .placeholder,#comment-input input,#comment-textarea .placeholder,#comment-textarea textarea,#wrapper .search-table .search-field input,.avada-select .select2-container .select2-choice,.avada-select .select2-container .select2-choice2,.avada-select-parent select,.chzn-container .chzn-drop,.chzn-container-single .chzn-single,.comment-form-comment textarea,.input-text,.main-nav-search-form input,.post-password-form label input[type="password"],.search-page-search-form input,input.s,input.s .placeholder,input[type="text"],select,textarea
{
	color:#aaa9a9;
}
#comment-input input::-webkit-input-placeholder,#comment-textarea textarea::-webkit-input-placeholder,.comment-form-comment textarea::-webkit-input-placeholder,.input-text::-webkit-input-placeholder,.post-password-form label input[type="password"]::-webkit-input-placeholder,.searchform .s::-webkit-input-placeholder,input#s::-webkit-input-placeholder
{
	color:#aaa9a9;
}
#comment-input input:-moz-placeholder,#comment-textarea textarea:-moz-placeholder,.comment-form-comment textarea:-moz-placeholder,.input-text:-moz-placeholder,.post-password-form label input[type="password"]:-moz-placeholder,.searchform .s:-moz-placeholder,input#s:-moz-placeholder
{
	color:#aaa9a9;
}
#comment-input input::-moz-placeholder,#comment-textarea textarea::-moz-placeholder,.comment-form-comment textarea::-moz-placeholder,.input-text::-moz-placeholder,.post-password-form label input[type="password"]::-moz-placeholder,.searchform .s::-moz-placeholder,input#s::-moz-placeholder
{
	color:#aaa9a9;
}
#comment-input input:-ms-input-placeholder,#comment-textarea textarea:-ms-input-placeholder,.comment-form-comment textarea:-ms-input-placeholder,.input-text:-ms-input-placeholder,.post-password-form label input[type="password"]::-ms-input-placeholder,.searchform .s:-ms-input-placeholder,input#s:-ms-input-placeholder
{
	color:#aaa9a9;
}
#comment-input input,#comment-textarea textarea,#wrapper .search-table .search-field input,.avada-select .select2-container .select2-choice,.avada-select .select2-container .select2-choice .select2-arrow,.avada-select .select2-container .select2-choice2 .select2-arrow,.avada-select-parent .select-arrow,.avada-select-parent select,.chzn-container .chzn-drop,.chzn-container-single .chzn-single,.comment-form-comment textarea,.gravity-select-parent .select-arrow,.input-text,.main-nav-search-form input,.post-password-form label input[type="password"],.search-page-search-form input,.select-arrow,input.s,input[type="text"],select,textarea
{
	border-color:#d2d2d2;
}
#comment-input input,.avada-select .select2-container .select2-choice,.avada-select-parent select,.chzn-container .chzn-drop,.chzn-container-single .chzn-single,.input-text:not(textarea),.main-nav-search-form input,.post-password-form label input[type="password"],.search-page-search-form input,.searchform .search-table .search-field input,input.s,input[type="text"],select
{
	height:29px;padding-top:0;padding-bottom:0;
}
.avada-select .select2-container .select2-choice .select2-arrow,.avada-select .select2-container .select2-choice2 .select2-arrow,.searchform .search-table .search-button input[type="submit"]
{
	height:29px;width:29px;line-height:29px;
}
.select2-container .select2-choice > .select2-chosen
{
	line-height:29px;
}
.select-arrow,.select2-arrow
{
	color:#d2d2d2;
}
.fusion-page-title-bar h1
{
	font-size:18px;line-height:normal;
}
.fusion-page-title-bar h3
{
	font-size:13px;line-height:25px;
}
body.has-sidebar #content
{
	width:calc(100% - 23% - 6%);
}
body.has-sidebar #main .sidebar
{
	width:23%;
}
body.has-sidebar.double-sidebars #content
{
	width:calc(100% - 21% - 21% - 6%);margin-left:calc(21% + 3%);
}
body.has-sidebar.double-sidebars #main #sidebar
{
	width:21%;margin-left:calc(3% - (100% - 21%));
}
body.has-sidebar.double-sidebars #main #sidebar-2
{
	width:21%;margin-left:3%;
}
#main .sidebar
{
	background-color:transparent;padding:0;
}
.fusion-accordian .panel-title a .fa-fusion-box
{
	background-color:#333333;
}
.progress-bar-content
{
	background-color:#a0ce4e;border-color:#a0ce4e;
}
.content-box-percentage
{
	color:#a0ce4e;
}
.progress-bar
{
	background-color:#f6f6f6;border-color:#f6f6f6;
}
#wrapper .fusion-date-and-formats .fusion-format-box, .tribe-mini-calendar-event .list-date .list-dayname
{
	background-color:#eef0f2;
}
.fusion-carousel .fusion-carousel-nav .fusion-nav-next,.fusion-carousel .fusion-carousel-nav .fusion-nav-prev
{
	background-color:rgba(0,0,0,0.6);width:30px;height:30px;margin-top:-15px;
}
.fusion-carousel .fusion-carousel-nav .fusion-nav-next:hover,.fusion-carousel .fusion-carousel-nav .fusion-nav-prev:hover
{
	background-color:rgba(0,0,0,0.7);
}
.fusion-flexslider .flex-direction-nav .flex-next,.fusion-flexslider .flex-direction-nav .flex-prev
{
	background-color:rgba(0,0,0,0.6);
}
.fusion-flexslider .flex-direction-nav .flex-next:hover,.fusion-flexslider .flex-direction-nav .flex-prev:hover
{
	background-color:rgba(0,0,0,0.7);
}
.content-boxes .col
{
	background-color:transparent;
}
#wrapper .fusion-content-widget-area .fusion-tabs-widget .tabs-container
{
	background-color:#ffffff;
}
body .fusion-content-widget-area .fusion-tabs-widget .tab-hold .tabs li
{
	border-right:1px solid #ffffff;
}
.fusion-content-widget-area .fusion-tabs-widget .tab-holder .tabs li a,body .fusion-content-widget-area .fusion-tabs-widget .tab-holder .tabs li a
{
	background:#ebeaea;border-bottom:0;color:#747474;
}
body .fusion-content-widget-area .fusion-tabs-widget .tab-hold .tabs li a:hover
{
	background:#ffffff;border-bottom:0;
}
body .fusion-content-widget-area .fusion-tabs-widget .tab-hold .tabs li.active a,body .fusion-content-widget-area .fusion-tabs-widget .tab-holder .tabs li.active a
{
	background:#ffffff;border-bottom:0;border-top-color:#640f12;
}
#wrapper .fusion-content-widget-area .fusion-tabs-widget .tab-holder,.fusion-content-widget-area .fusion-tabs-widget .tab-holder .news-list li
{
	border-color:#ebeaea;
}
.fusion-single-sharing-box
{
	background-color:#f6f6f6;
}
.fusion-blog-layout-grid .post .fusion-post-wrapper,.fusion-blog-layout-timeline .post,.fusion-events-shortcode .fusion-layout-column,.fusion-portfolio.fusion-portfolio-boxed .fusion-portfolio-content-wrapper,.products li.product
{
	background-color:transparent;
}
.fusion-blog-layout-grid .post .flexslider,.fusion-blog-layout-grid .post .fusion-content-sep,.fusion-blog-layout-grid .post .fusion-post-wrapper,.fusion-blog-layout-timeline .fusion-timeline-date,.fusion-blog-layout-timeline .fusion-timeline-line,.fusion-blog-layout-timeline .post,.fusion-blog-layout-timeline .post .flexslider,.fusion-blog-layout-timeline .post .fusion-content-sep,.fusion-blog-timeline-layout .post,.fusion-blog-timeline-layout .post .flexslider,.fusion-blog-timeline-layout .post .fusion-content-sep,.fusion-events-shortcode .fusion-events-thumbnail,.fusion-events-shortcode .fusion-layout-column,.fusion-portfolio.fusion-portfolio-boxed .fusion-content-sep,.fusion-portfolio.fusion-portfolio-boxed .fusion-portfolio-content-wrapper,.product .product-buttons,.product-buttons,.product-buttons-container,.product-details-container,.products li
{
	border-color:#ebeaea;
}
.fusion-blog-layout-timeline .fusion-timeline-circle,.fusion-blog-layout-timeline .fusion-timeline-date,.fusion-blog-timeline-layout .fusion-timeline-circle,.fusion-blog-timeline-layout .fusion-timeline-date
{
	background-color:#ebeaea;
}
.fusion-blog-timeline-layout .fusion-timeline-arrow:before,.fusion-blog-timeline-layout .fusion-timeline-icon,.fusion-timeline-arrow:before,.fusion-timeline-icon
{
	color:#ebeaea;
}
div.indicator-hint
{
	background:#ebeaea;border-color:#ebeaea;
}
#posts-container.fusion-blog-layout-grid
{
	margin:-20px -20px 0 -20px;
}
#posts-container.fusion-blog-layout-grid .fusion-post-grid
{
	padding:20px;
}
.quicktags-toolbar input
{
	background:linear-gradient(to top, #f2f2f2, #ffffff ) #3E3E3E;background:-webkit-linear-gradient(to top, #f2f2f2, #ffffff ) #3E3E3E;background:-moz-linear-gradient(to top, #f2f2f2, #ffffff ) #3E3E3E;background:-ms-linear-gradient(to top, #f2f2f2, #ffffff ) #3E3E3E;background:-o-linear-gradient(to top, #f2f2f2, #ffffff ) #3E3E3E;background-image:-webkit-gradient( linear, left top, left bottom, color-stop(0, #ffffff), color-stop(1, #f2f2f2));filter:progid:DXImageTransform.Microsoft.gradient(startColorstr=#ffffff, endColorstr=#f2f2f2), progid: DXImageTransform.Microsoft.Alpha(Opacity=0);border:1px solid #d2d2d2;color:#aaa9a9;
}
.quicktags-toolbar input:hover
{
	background:#ffffff;
}
.ei-slider
{
	width:100%;height:400px;
}
#comment-submit,#reviews input#submit,.button.default,.fusion-button.fusion-button-default,.post-password-form input[type="submit"],.ticket-selector-submit-btn[type="submit"]
{
	border-color:#ffffff;
}
#comment-submit:hover,#reviews input#submit:hover,.button.default:hover,.fusion-button.fusion-button-default:hover,.post-password-form input[type="submit"]:hover,.ticket-selector-submit-btn[type="submit"]:hover
{
	border-color:#ffffff;
}
.button.default,.fusion-button-default,.post-password-form input[type="submit"]
{
	padding:13px 29px;line-height:17px;font-size:14px;
}
.button.default.button-3d.button-small,.fusion-button.button-small.button-3d,.fusion-button.fusion-button-3d.fusion-button-small,.ticket-selector-submit-btn[type="submit"]
{
	box-shadow:inset 0px 1px 0px #ffffff, 0px 2px 0px #54770F, 1px 4px 4px 2px rgba(0, 0, 0, 0.3);-webkit-box-shadow:inset 0px 1px 0px #ffffff, 0px 2px 0px #54770F, 1px 4px 4px 2px rgba(0, 0, 0, 0.3);-moz-box-shadow:inset 0px 1px 0px #ffffff, 0px 2px 0px #54770F, 1px 4px 4px 2px rgba(0, 0, 0, 0.3);
}
.button.default.button-3d.button-small:active,.fusion-button.button-small.button-3d:active,.fusion-button.fusion-button-3d.fusion-button-small:active,.ticket-selector-submit-btn[type="submit"]:active
{
	box-shadow:inset 0px 1px 0px #ffffff, 0px 1px 0px #54770F, 1px 4px 4px 2px rgba(0, 0, 0, 0.3);-webkit-box-shadow:inset 0px 1px 0px #ffffff, 0px 1px 0px #54770F, 1px 4px 4px 2px rgba(0, 0, 0, 0.3);-moz-box-shadow:inset 0px 1px 0px #ffffff, 0px 1px 0px #54770F, 1px 4px 4px 2px rgba(0, 0, 0, 0.3);
}
.button.default.button-3d.button-medium,.fusion-button.button-medium.button-3d,.fusion-button.fusion-button-3d.fusion-button-medium
{
	box-shadow:inset 0px 1px 0px #ffffff, 0px 3px 0px #54770F, 1px 5px 5px 3px rgba(0, 0, 0, 0.3);-webkit-box-shadow:inset 0px 1px 0px #ffffff, 0px 3px 0px #54770F, 1px 5px 5px 3px rgba(0, 0, 0, 0.3);-moz-box-shadow:inset 0px 1px 0px #ffffff, 0px 3px 0px #54770F, 1px 5px 5px 3px rgba(0, 0, 0, 0.3);
}
.button.default.button-3d.button-medium:active,.fusion-button.button-medium.button-3d:active,.fusion-button.fusion-button-3d.fusion-button-medium:active
{
	box-shadow:inset 0px 1px 0px #ffffff, 0px 1px 0px #54770F, 1px 5px 5px 3px rgba(0, 0, 0, 0.3);-webkit-box-shadow:inset 0px 1px 0px #ffffff, 0px 1px 0px #54770F, 1px 5px 5px 3px rgba(0, 0, 0, 0.3);-moz-box-shadow:inset 0px 1px 0px #ffffff, 0px 1px 0px #54770F, 1px 5px 5px 3px rgba(0, 0, 0, 0.3);
}
.button.default.button-3d.button-large,.fusion-button.button-large.button-3d,.fusion-button.fusion-button-3d.fusion-button-large
{
	box-shadow:inset 0px 1px 0px #ffffff, 0px 4px 0px #54770F, 1px 5px 6px 3px rgba(0, 0, 0, 0.3);-webkit-box-shadow:inset 0px 1px 0px #ffffff, 0px 4px 0px #54770F, 1px 5px 6px 3px rgba(0, 0, 0, 0.3);-moz-box-shadow:inset 0px 1px 0px #ffffff, 0px 4px 0px #54770F, 1px 5px 6px 3px rgba(0, 0, 0, 0.3);
}
.button.default.button-3d.button-large:active,.fusion-button.button-large.button-3d:active,.fusion-button.fusion-button-3d.fusion-button-large:active
{
	box-shadow:inset 0px 1px 0px #ffffff, 0px 1px 0px #54770F, 1px 6px 6px 3px rgba(0, 0, 0, 0.3);-webkit-box-shadow:inset 0px 1px 0px #ffffff, 0px 1px 0px #54770F, 1px 6px 6px 3px rgba(0, 0, 0, 0.3);-moz-box-shadow:inset 0px 1px 0px #ffffff, 0px 1px 0px #54770F, 1px 6px 6px 3px rgba(0, 0, 0, 0.3);
}
.button.default.button-3d.button-xlarge,.fusion-button.button-xlarge.button-3d,.fusion-button.fusion-button-3d.fusion-button-xlarge
{
	box-shadow:inset 0px 1px 0px #ffffff, 0px 5px 0px #54770F, 1px 7px 7px 3px rgba(0, 0, 0, 0.3);-webkit-box-shadow:inset 0px 1px 0px #ffffff, 0px 5px 0px #54770F, 1px 7px 7px 3px rgba(0, 0, 0, 0.3);-moz-box-shadow:inset 0px 1px 0px #ffffff, 0px 5px 0px #54770F, 1px 7px 7px 3px rgba(0, 0, 0, 0.3);
}
.button.default.button-3d.button-xlarge:active,.fusion-button.button-xlarge.button-3d:active,.fusion-button.fusion-button-3d.fusion-button-xlarge:active
{
	box-shadow:inset 0px 1px 0px #ffffff, 0px 2px 0px #54770F, 1px 7px 7px 3px rgba(0, 0, 0, 0.3);-webkit-box-shadow:inset 0px 1px 0px #ffffff, 0px 2px 0px #54770F, 1px 7px 7px 3px rgba(0, 0, 0, 0.3);-moz-box-shadow:inset 0px 1px 0px #ffffff, 0px 2px 0px #54770F, 1px 7px 7px 3px rgba(0, 0, 0, 0.3);
}
#comment-submit,#reviews input#submit,.button-default,.button.default,.fusion-button,.fusion-button-default,.post-password-form input[type="submit"]
{
	border-width:0px;border-style:solid;
}
.button.default:hover,.fusion-button.button-default:hover,.ticket-selector-submit-btn[type="submit"]
{
	border-width:0px;border-style:solid;
}
.fusion-menu-item-button .menu-text
{
	border-color:#fff;
}
.fusion-menu-item-button:hover .menu-text
{
	border-color:#fff;
}
#comment-submit,#reviews input#submit,.button-default,.button.default,.fusion-button-default,.post-password-form input[type="submit"],.ticket-selector-submit-btn[type="submit"]
{
	border-radius:2px;-webkit-border-radius:2px;
}
.reading-box
{
	background-color:#f6f6f6;
}
.isotope .isotope-item
{
	transition-property:top, left, opacity;-webkit-transition-property:top, left, opacity;-moz-transition-property:top, left, opacity;-ms-transition-property:top, left, opacity;-o-transition-property:top, left, opacity;
}
.comment-form input[type="submit"],.fusion-button,.fusion-load-more-button,.ticket-selector-submit-btn[type="submit"]
{
	font-family:Verdana, Geneva, sans-serif;font-weight:700;
}
.fusion-image-wrapper .fusion-rollover .fusion-rollover-gallery:before,.fusion-image-wrapper .fusion-rollover .fusion-rollover-link:before
{
	font-size:15px;margin-left:-7px;line-height:36px;color:#ffffff;
}
.fusion-title-size-one,h1
{
	margin-top:0.67em;margin-bottom:0.67em;
}
.fusion-title-size-two,h2
{
	margin-top:0em;margin-bottom:1.1em;
}
.fusion-title-size-three,h3
{
	margin-top:1em;margin-bottom:1em;
}
.fusion-title-size-four,h4
{
	margin-top:1.33em;margin-bottom:1.33em;
}
.fusion-title-size-five,h5
{
	margin-top:1.67em;margin-bottom:1.67em;
}
.fusion-title-size-six,h6
{
	margin-top:2.33em;margin-bottom:2.33em;
}
.fusion-logo
{
	margin-top:0px;margin-right:0px;margin-bottom:0px;margin-left:50px;
}
.fusion-header-wrapper .fusion-row
{
	padding-left:0px;padding-right:0px;max-width:100%;
}
.fusion-header-v2 .fusion-header,.fusion-header-v3 .fusion-header,.fusion-header-v4 .fusion-header,.fusion-header-v5 .fusion-header
{
	border-bottom-color:#640f12;
}
#side-header .fusion-secondary-menu-search-inner
{
	border-top-color:#640f12;
}
.fusion-header .fusion-row
{
	padding-top:0px;padding-bottom:0px;
}
.fusion-secondary-header
{
	background-color:#02263c;font-size:11px;color:#ffffff;border-bottom-color:#640f12;
}
.fusion-secondary-header a,.fusion-secondary-header a:hover
{
	color:#ffffff;
}
.fusion-header-v2 .fusion-secondary-header
{
	border-top-color:#640f12;
}
.fusion-mobile-menu-design-modern .fusion-secondary-header .fusion-alignleft
{
	border-bottom-color:#640f12;
}
.fusion-header-tagline
{
	font-size:16px;color:#747474;
}
.fusion-mobile-menu-sep,.fusion-secondary-main-menu
{
	border-bottom-color:#640f12;
}
#side-header
{
	width:0px;padding-top:0px;padding-bottom:0px;
}
#side-header .side-header-background
{
	width:0px;
}
#side-header .side-header-border
{
	width:0px;border-color:#640f12;
}
#side-header .side-header-content
{
	padding-left:0px;padding-right:0px;
}
#side-header .fusion-main-menu > ul > li > a
{
	padding-left:0px;padding-right:0px;border-top-color:#640f12;border-bottom-color:#640f12;text-align:center;height:auto;min-height:40px;
}
.side-header-left .fusion-main-menu > ul > li > a > .fusion-caret
{
	right:0px;
}
.side-header-right .fusion-main-menu > ul > li > a > .fusion-caret
{
	left:0px;
}
#side-header .fusion-main-menu > ul > li.current-menu-ancestor > a,#side-header .fusion-main-menu > ul > li.current-menu-item > a
{
	color:#ffffff;border-right-color:#ffffff;border-left-color:#ffffff;
}
body.side-header-left #side-header .fusion-main-menu > ul > li > ul
{
	left:-1px;
}
body.side-header-left #side-header .fusion-main-menu .fusion-custom-menu-item-contents
{
	top:0;left:-1px;
}
#side-header .fusion-main-menu .fusion-main-menu-search .fusion-custom-menu-item-contents
{
	border-top-width:1px;border-top-style:solid;
}
#side-header .fusion-secondary-menu > ul > li > a,#side-header .side-header-content-1,#side-header .side-header-content-2
{
	color:#bcd86e;font-size:11px;
}
.side-header-left #side-header .fusion-main-menu > ul > li.current-menu-ancestor > a,.side-header-left #side-header .fusion-main-menu > ul > li.current-menu-item > a
{
	border-right-width:3px;
}
.side-header-right #side-header .fusion-main-menu > ul > li.current-menu-ancestor > a,.side-header-right #side-header .fusion-main-menu > ul > li.current-menu-item > a
{
	border-left-width:3px;
}
.side-header-right #side-header .fusion-main-menu .fusion-menu-cart-items,.side-header-right #side-header .fusion-main-menu .fusion-menu-login-box .fusion-custom-menu-item-contents,.side-header-right #side-header .fusion-main-menu ul .fusion-dropdown-menu .sub-menu,.side-header-right #side-header .fusion-main-menu ul .fusion-dropdown-menu .sub-menu li ul,.side-header-right #side-header .fusion-main-menu ul .fusion-menu-login-box .sub-menu
{
	left:-180px;
}
.side-header-right #side-header .fusion-main-menu-search .fusion-custom-menu-item-contents
{
	left:-250px;
}
.fusion-main-menu > ul > li
{
	padding-right:20px;
}
.fusion-main-menu > ul > li > a
{
	border-top:3px solid transparent;height:40px;line-height:40px;font-family:Verdana, Geneva, sans-serif;font-weight:400;font-size:14px;
}
.fusion-megamenu-icon img
{
	max-height:14px;
}
.fusion-main-menu .fusion-widget-cart-counter > a:before,.fusion-main-menu > ul > li > a
{
	color:#ffffff;
}
.fusion-main-menu .fusion-widget-cart-counter > a:hover:before,.fusion-main-menu > ul > li > a:hover
{
	color:#ffffff;
}
.fusion-main-menu > ul > li > a:hover
{
	border-color:#ffffff;
}
.fusion-main-menu > ul > .fusion-menu-item-button > a:hover
{
	border-color:transparent;
}
.fusion-widget-cart-number
{
	background-color:#ffffff;color:#ffffff;
}
.fusion-widget-cart-counter a:hover:before
{
	color:#ffffff;
}
.fusion-main-menu .current-menu-ancestor > a,.fusion-main-menu .current-menu-item > a,.fusion-main-menu .current-menu-parent > a,.fusion-main-menu .current_page_item > a
{
	color:#ffffff;border-color:#ffffff;
}
.fusion-main-menu > ul > .fusion-menu-item-button > a
{
	border-color:transparent;
}
.fusion-main-menu .fusion-main-menu-icon:after
{
	color:#ffffff;height:14px;width:14px;
}
.fusion-main-menu .fusion-menu-cart-checkout-link a:hover,.fusion-main-menu .fusion-menu-cart-checkout-link a:hover:before,.fusion-main-menu .fusion-menu-cart-link a:hover,.fusion-main-menu .fusion-menu-cart-link a:hover:before
{
	color:#ffffff;
}
.fusion-main-menu .fusion-main-menu-icon:hover
{
	border-color:transparent;
}
.fusion-main-menu .fusion-main-menu-icon:hover:after
{
	color:#ffffff;
}
.fusion-main-menu .fusion-main-menu-icon-active:after,.fusion-main-menu .fusion-main-menu-search-open .fusion-main-menu-icon:after
{
	color:#ffffff;
}
.fusion-main-menu .sub-menu
{
	background-color:#02263c;border-top:3px solid #ffffff;font-family:Verdana, Geneva, sans-serif;font-weight:400;box-shadow:1px 1px 30px rgba(0, 0, 0, 0.06);-webkit-box-shadow:1px 1px 30px rgba(0, 0, 0, 0.06);-moz-box-shadow:1px 1px 30px rgba(0, 0, 0, 0.06);
}
.fusion-main-menu .sub-menu, .fusion-main-menu .fusion-menu-cart-items, .fusion-main-menu .fusion-menu-login-box .fusion-custom-menu-item-contents
{
	width:180px;
}
.fusion-main-menu .sub-menu ul
{
	left:180px;top:-3px;
}
.fusion-main-menu .sub-menu li a
{
	border-bottom:1px solid #e0e0e0;padding-top:7px;padding-bottom:7px;color:#ffffff;font-family:Verdana, Geneva, sans-serif;font-weight:400;font-size:12px;
}
.fusion-main-menu .sub-menu li a:hover
{
	background-color:#ffffff;
}
.fusion-main-menu .sub-menu .current-menu-item > a,.fusion-main-menu .sub-menu .current-menu-parent > a,.fusion-main-menu .sub-menu .current_page_item > a
{
	background-color:#ffffff;
}
.fusion-main-menu .fusion-custom-menu-item-contents
{
	font-family:Verdana, Geneva, sans-serif;font-weight:400;
}
.fusion-main-menu .fusion-main-menu-cart .fusion-custom-menu-item-contents,.fusion-main-menu .fusion-main-menu-search .fusion-custom-menu-item-contents,.fusion-main-menu .fusion-menu-login-box .fusion-custom-menu-item-contents
{
	background-color:#02263c;border-color:#e0e0e0;
}
.fusion-secondary-menu > ul > li
{
	border-color:#7609e2;
}
.fusion-secondary-menu > ul > li > a
{
	height:44px;line-height:44px;
}
.fusion-secondary-menu .sub-menu, .fusion-secondary-menu .fusion-custom-menu-item-contents
{
	width:180px;
}
.fusion-secondary-menu .fusion-secondary-menu-icon
{
	min-width:180px;
}
.fusion-secondary-menu .sub-menu
{
	background-color:#307993;border-color:#e5e5e5;
}
.fusion-secondary-menu .sub-menu a
{
	border-color:#e5e5e5;color:#bcd86e;
}
.fusion-secondary-menu .sub-menu a:hover
{
	background-color:#fafafa;color:#333333;
}
.fusion-secondary-menu > ul > li > .sub-menu .sub-menu
{
	left:180px;
}
.fusion-secondary-menu .fusion-custom-menu-item-contents
{
	background-color:#307993;border-color:#e5e5e5;color:#bcd86e;
}
.fusion-secondary-menu .fusion-secondary-menu-icon,.fusion-secondary-menu .fusion-secondary-menu-icon:hover
{
	color:#ffffff;
}
.fusion-secondary-menu .fusion-menu-cart-items a
{
	color:#bcd86e;
}
.fusion-secondary-menu .fusion-menu-cart-item a
{
	border-color:#e5e5e5;
}
.fusion-secondary-menu .fusion-menu-cart-item img
{
	border-color:#e0dede;
}
.fusion-secondary-menu .fusion-menu-cart-item a:hover
{
	background-color:#fafafa;color:#333333;
}
.fusion-secondary-menu-icon
{
	background-color:#fafafa;color:#ffffff;
}
.fusion-secondary-menu-icon:after,.fusion-secondary-menu-icon:before
{
	color:#ffffff;
}
.fusion-contact-info
{
	line-height:44px;
}
.fusion-megamenu-holder
{
	border-color:#ffffff;
}
.fusion-megamenu
{
	background-color:#02263c;box-shadow:1px 1px 30px rgba(0, 0, 0, 0.06);-webkit-box-shadow:1px 1px 30px rgba(0, 0, 0, 0.06);-moz-box-shadow:1px 1px 30px rgba(0, 0, 0, 0.06);
}
.fusion-megamenu-wrapper .fusion-megamenu-submenu
{
	border-color:#e0e0e0;padding-bottom:0;
}
.rtl .fusion-megamenu-wrapper .fusion-megamenu-submenu:last-child
{
	border-color:#e0e0e0;
}
.fusion-megamenu-wrapper .fusion-megamenu-submenu .sub-menu a
{
	padding-top:5px;padding-bottom:5px;border-bottom:1px solid #e0e0e0;
}
.fusion-megamenu-wrapper .fusion-megamenu-submenu > a
{
	border-bottom:1px solid #e0e0e0;
}
#side-header .fusion-main-menu > ul .sub-menu > li:last-child > a
{
	border-bottom:1px solid #e0e0e0;
}
.fusion-megamenu-wrapper .fusion-megamenu-submenu-notitle
{
	padding-top:0;
}
.fusion-megamenu-wrapper .fusion-megamenu-submenu > a:hover
{
	background-color:#ffffff;color:#ffffff;font-family:Verdana, Geneva, sans-serif;font-weight:400;font-size:12;
}
.fusion-megamenu-title
{
	font-family:Verdana, Geneva, sans-serif;font-weight:400;font-size:18px;color:#ffffff;
}
.fusion-megamenu-title a
{
	color:#ffffff;
}
.fusion-megamenu-bullet
{
	border-left-color:#ffffff;
}
.fusion-megamenu-widgets-container
{
	color:#ffffff;font-family:Verdana, Geneva, sans-serif;font-weight:400;font-size:12px;
}
.fusion-header-wrapper.fusion-is-sticky .fusion-header,.fusion-header-wrapper.fusion-is-sticky .fusion-secondary-main-menu
{
	background-color:rgba(100,15,18,0.97);
}
.no-rgba .fusion-header-wrapper.fusion-is-sticky .fusion-header,.no-rgba .fusion-header-wrapper.fusion-is-sticky .fusion-secondary-main-menu
{
	background-color:rgba(100,15,18,0.97);opacity:0.97;filter:progid: DXImageTransform.Microsoft.Alpha(Opacity=97);
}
.fusion-is-sticky .fusion-main-menu > ul > li:last-child
{
	padding-right:0;
}
.rtl .fusion-is-sticky .fusion-main-menu > ul > li:last-child
{
	padding-right:20px;
}
.fusion-mobile-selector
{
	background-color:#f9f9f9;border-color:#dadada;font-size:10px;height:35px;line-height:35px;color:#333333;
}
.fusion-selector-down
{
	height:33px;line-height:33px;border-color:#dadada;
}
.fusion-selector-down:before
{
	color:#dadada;
}
.fusion-mobile-menu-design-modern .fusion-mobile-nav-holder > ul,.fusion-mobile-nav-holder > ul
{
	border-color:#dadada;
}
.fusion-mobile-nav-item .fusion-open-submenu
{
	color:#333333;
}
.fusion-mobile-nav-item a
{
	color:#333333;font-size:10px;background-color:#f9f9f9;border-color:#dadada;height:35px;line-height:35px;
}
.fusion-mobile-nav-item a:hover
{
	background-color:#f6f6f6;
}
.fusion-mobile-nav-item a:before
{
	color:#333333;
}
.fusion-mobile-current-nav-item > a
{
	background-color:#f6f6f6;
}
.fusion-mobile-menu-icons
{
	margin-top:0px;
}
.fusion-mobile-menu-icons a
{
	color:#dadada;
}
.fusion-mobile-menu-icons a:before
{
	color:#dadada;
}
.fusion-open-submenu
{
	font-size:10px;height:35px;line-height:35px;
}
.fusion-open-submenu:hover
{
	color:#640f12;
}
#wrapper .post-content .content-box-heading
{
	font-size:18px;line-height:27px;
}
.fusion-social-links-header .fusion-social-networks a
{
	font-size:16px;
}
.fusion-social-links-header .fusion-social-networks.boxed-icons a
{
	padding:4px;
}
.fusion-social-links-footer .fusion-social-networks a
{
	font-size:16px;
}
.fusion-social-links-footer .fusion-social-networks.boxed-icons a
{
	padding:8px;
}
.fusion-sharing-box .fusion-social-networks a
{
	font-size:16px;
}
.fusion-sharing-box .fusion-social-networks.boxed-icons a
{
	padding:8px;
}
.post-content .fusion-social-links .fusion-social-networks a,.widget .fusion-social-links .fusion-social-networks a
{
	font-size:16px;
}
.post-content .fusion-social-links .fusion-social-networks.boxed-icons a,.widget .fusion-social-links .fusion-social-networks.boxed-icons a
{
	padding:8px;
}
.fusion-body .error-menu li:after,.fusion-body .error-menu li:before
{
	background-color:#a0ce4e;color:#ffffff;
}
.avada-select-parent .select-arrow,.select-arrow
{
	height:33px;line-height:33px;
}
#main,.fusion-secondary-header,.header-v4 #small-nav,.header-v5 #small-nav
{
	padding-left:0px;padding-right:0px;
}
#main .fusion-row,#sliders-container .tfs-slider .slide-content-container,#slidingbar .fusion-row,.fusion-footer-copyright-area,.fusion-footer-widget-area,.fusion-header,.fusion-page-title-bar,.fusion-secondary-header .fusion-row
{
	padding-left:30px;padding-right:30px;
}
.fullwidth-box,.fullwidth-box .fusion-row .fusion-full-width-sep
{
	margin-left:-30px;margin-right:-30px;
}
#main.width-100 > .fusion-row
{
	padding-left:0;padding-right:0;
}
body,html
{
	background-color:#d8d8d8;
}
#wrapper,.fusion-footer-parallax
{
	max-width:100%;margin:0 auto;
}
.wrapper_blank
{
	display:block;
}
#main .fusion-row,#slidingbar-area .fusion-row,#small-nav .fusion-row,.fusion-footer-copyright-area .fusion-row,.fusion-footer-widget-area .fusion-row,.fusion-header .fusion-row,.fusion-page-title-row,.fusion-secondary-header .fusion-row
{
	max-width:none;padding:0 10px;
}
#side-header,.fusion-header,.layout-boxed-mode .side-header-wrapper,.side-header-background
{
	background-color:rgba(100,15,18,1);
}
.fusion-secondary-main-menu
{
	background-color:rgba(255,255,255,1);
}
.rev_slider_wrapper
{
	position:relative;
}
.avada-skin-rev
{
	border-top:1px solid #d2d3d4;border-bottom:1px solid #d2d3d4;box-sizing:content-box;-webkit-box-sizing:content-box;-moz-box-sizing:content-box;
}
.tparrows
{
	border-radius:0;-webkit-border-radius:0;
}
.tp-bullets .bullet.last
{
	clear:none;
}
#main
{
	padding-top:55px;padding-bottom:20px;
}
.width-100 .fusion-section-separator,.width-100 .nonhundred-percent-fullwidth
{
	margin-left:-30px;margin-right:-30px;
}
.side-header-left .fusion-footer-parallax,body.side-header-left #wrapper
{
	margin-left:280px;
}
.side-header-right .fusion-footer-parallax,body.side-header-right #wrapper
{
	margin-right:280px;
}
body.side-header-left #side-header #nav .login-box,body.side-header-left #side-header #nav .main-nav-search-form,body.side-header-left #side-header #nav > ul > li > ul
{
	left:279px;
}
.fusion-flexslider .flex-direction-nav a,.fusion-flexslider.flexslider-attachments .flex-direction-nav a,.fusion-flexslider.flexslider-posts .flex-direction-nav a,.fusion-flexslider.flexslider-posts-with-excerpt .flex-direction-nav a,.fusion-slider-sc .flex-direction-nav a
{
	width:30px;height:30px;line-height:30px;font-size:14px;
}
.fusion-carousel .fusion-carousel-nav .fusion-nav-next:before,.fusion-carousel .fusion-carousel-nav .fusion-nav-prev:before
{
	line-height:30px;font-size:14px;
}
.bbp-pagination .bbp-pagination-links a.inactive,.bbp-topic-pagination .page-numbers,.page-links a,.pagination a.inactive,.woocommerce-pagination .page-numbers
{
	padding:2px 6px;
}
.bbp-pagination .bbp-pagination-links .current,.page-links > .page-number,.pagination .current,.woocommerce-pagination .current
{
	padding:2px 6px;
}
.bbp-pagination .bbp-pagination-links .pagination-prev,.pagination .pagination-prev,.woocommerce-pagination .prev
{
	padding:2px 6px;
}
.bbp-pagination .bbp-pagination-links .pagination-next,.bbp-pagination-links span.dots,.pagination .pagination-next,.woocommerce-pagination .next
{
	padding:2px 6px;
}
@media only screen and (min-width: 1007.2px) and (max-width: 1099px)
{
	.fusion-portfolio-six .fusion-portfolio-post,.grid-layout-6 .fusion-post-grid
	{
		width:20% !important;
}
.fusion-blog-layout-grid-5 .fusion-post-grid,.fusion-portfolio-five .fusion-portfolio-post
{
	width:25% !important;
}

}
@media only screen and (min-width: 915.4px) and (max-width: 1007.2px)
{
	.fusion-blog-layout-grid-6 .fusion-post-grid,.fusion-portfolio-six .fusion-portfolio-post
	{
		width:20% !important;
}
.fusion-blog-layout-grid-5 .fusion-post-grid,.fusion-portfolio-five .fusion-portfolio-post
{
	width:33.3333333333% !important;
}
.fusion-blog-layout-grid-4 .fusion-post-grid,.fusion-portfolio-four .fusion-portfolio-post
{
	width:33.3333333333% !important;
}

}
@media only screen and (min-width: 823.6px) and (max-width: 915.4px)
{
	.fusion-blog-layout-grid-6 .fusion-post-grid,.fusion-portfolio-six .fusion-portfolio-post
	{
		width:25% !important;
}
.fusion-blog-layout-grid-3 .fusion-post-grid,.fusion-blog-layout-grid-4 .fusion-post-grid,.fusion-blog-layout-grid-5 .fusion-post-grid,.fusion-portfolio-five .fusion-portfolio-post,.fusion-portfolio-four .fusion-portfolio-post,.fusion-portfolio-masonry .fusion-portfolio-post,.fusion-portfolio-three .fusion-portfolio-post
{
	width:50% !important;
}

}
@media only screen and (min-width: 731.8px) and (max-width: 823.6px)
{
	.fusion-blog-layout-grid-6 .fusion-post-grid,.fusion-portfolio-six .fusion-portfolio-post
	{
		width:33.33% !important;
}
.fusion-blog-layout-grid-3 .fusion-post-grid,.fusion-blog-layout-grid-4 .fusion-post-grid,.fusion-blog-layout-grid-5 .fusion-post-grid,.fusion-portfolio-five .fusion-portfolio-post,.fusion-portfolio-four .fusion-portfolio-post,.fusion-portfolio-masonry .fusion-portfolio-post,.fusion-portfolio-three .fusion-portfolio-post
{
	width:50% !important;
}

}
@media only screen and (max-width: 731.8px)
{
	.fusion-blog-layout-grid .fusion-post-grid,.fusion-portfolio-post
	{
		width:100% !important;
}
.fusion-blog-layout-grid-6 .fusion-post-grid,.fusion-portfolio-six .fusion-portfolio-post
{
	width:50% !important;
}

}
@media only screen and (max-width: 640px)
{
	.fusion-blog-layout-grid-6 .fusion-post-grid,.fusion-portfolio-six .fusion-portfolio-post
	{
		width:100% !important;
}
.fusion-body .fusion-page-title-bar
{
	max-height:none;
}
.fusion-body .fusion-page-title-bar h1
{
	margin:0;
}
.fusion-body .fusion-page-title-secondary
{
	margin-top:2px;
}
.fusion-blog-layout-large .fusion-meta-info .fusion-alignleft,.fusion-blog-layout-large .fusion-meta-info .fusion-alignright,.fusion-blog-layout-medium .fusion-meta-info .fusion-alignleft,.fusion-blog-layout-medium .fusion-meta-info .fusion-alignright
{
	display:block;float:none;margin:0;width:100%;
}
.fusion-body .fusion-blog-layout-medium .fusion-post-slideshow
{
	float:none;margin:0 0 20px 0;height:auto;width:auto;
}
.fusion-blog-layout-large-alternate .fusion-date-and-formats
{
	margin-bottom:55px;
}
.fusion-body .fusion-blog-layout-large-alternate .fusion-post-content
{
	margin:0;
}
.fusion-blog-layout-medium-alternate .has-post-thumbnail .fusion-post-slideshow
{
	display:inline-block;float:none;margin-right:0;max-width:197px;
}
.fusion-blog-layout-grid .fusion-post-grid
{
	position:static;width:100%;
}
.flex-direction-nav,.wooslider-direction-nav,.wooslider-pauseplay
{
	display:none;
}
.share-box ul li
{
	margin-bottom:10px;margin-right:15px;
}
.buttons a
{
	margin-right:5px;
}
.ls-avada .ls-nav-next,.ls-avada .ls-nav-prev
{
	display:none !important;
}
#wrapper .ei-slider
{
	width:100% !important;height:200px !important;
}
.progress-bar
{
	margin-bottom:10px !important;
}
#wrapper .content-boxes-icon-boxed .content-wrapper-boxed
{
	min-height:inherit !important;padding-bottom:20px;padding-left:3% !important;padding-right:3% !important;
}
#wrapper .content-boxes-icon-boxed .content-box-column,#wrapper .content-boxes-icon-on-top .content-box-column
{
	margin-bottom:55px;
}
#wrapper .content-boxes-icon-boxed .content-box-column .heading h2
{
	margin-top:-5px;
}
#wrapper .content-boxes-icon-boxed .content-box-column .more
{
	margin-top:12px;
}
.page-template-contact-php .fusion-google-map
{
	height:270px !important;
}
.share-box .social-networks li
{
	margin-right:20px !important;
}
.timeline-icon
{
	display:none !important;
}
.timeline-layout
{
	padding-top:0 !important;
}
.fusion-counters-circle .counter-circle-wrapper
{
	display:block;margin-right:auto;margin-left:auto;
}
.post-content .wooslider .wooslider-control-thumbs
{
	margin-top:-10px;
}
body .wooslider .overlay-full.layout-text-left .slide-excerpt
{
	padding:20px !important;
}
.content-boxes-icon-boxed .col
{
	box-sizing:border-box;-webkit-box-sizing:border-box;-moz-box-sizing:border-box;
}
.social_links_shortcode li
{
	height:40px !important;
}
.products-slider .es-nav span
{
	transform:scale(0.5) !important;-webkit-transform:scale(0.5) !important;-moz-transform:scale(0.5) !important;-ms-transform:scale(0.5) !important;-o-transform:scale(0.5) !important;
}
.portfolio-masonry .portfolio-item
{
	width:100% !important;
}
.table-1 table,.tkt-slctr-tbl-wrap-dv table
{
	border-collapse:collapse;border-spacing:0;width:100%;
}
.table-1 td,.table-1 th,.tkt-slctr-tbl-wrap-dv td,.tkt-slctr-tbl-wrap-dv th
{
	white-space:nowrap;
}
.table-2 table
{
	border-collapse:collapse;border-spacing:0;width:100%;
}
.table-2 td,.table-2 th
{
	white-space:nowrap;
}
#main,.footer-area,.page-title-bar,body
{
	background-attachment:scroll !important;
}
.tfs-slider[data-animation="slide"]
{
	height:auto !important;
}
#wrapper .share-box h4
{
	display:block;float:none;line-height:20px !important;margin-top:0;padding:0;margin-bottom:10px;
}
.fusion-sharing-box .fusion-social-networks
{
	float:none;display:block;width:100%;text-align:left;
}
#content
{
	width:100% !important;margin-left:0px !important;
}
.sidebar
{
	width:100% !important;float:none !important;margin-left:0 !important;clear:both;
}
.fusion-hide-on-mobile
{
	display:none;
}
.fusion-blog-layout-timeline
{
	padding-top:0;
}
.fusion-blog-layout-timeline .fusion-post-timeline
{
	float:none;width:100%;
}
.fusion-blog-layout-timeline .fusion-timeline-date
{
	margin-bottom:0;margin-top:2px;
}
.fusion-timeline-arrow,.fusion-timeline-circle,.fusion-timeline-icon,.fusion-timeline-line
{
	display:none;
}

}
@media only screen and (min-device-width: 768px) and (max-device-width: 1024px) and (orientation: portrait)
{
	.fusion-columns-1 .fusion-column:first-child,.fusion-columns-2 .fusion-column:first-child,.fusion-columns-3 .fusion-column:first-child,.fusion-columns-4 .fusion-column:first-child,.fusion-columns-5 .fusion-column:first-child
	{
		margin-left:0;
}
.fusion-column,.fusion-column:nth-child(2n),.fusion-column:nth-child(3n),.fusion-column:nth-child(4n),.fusion-column:nth-child(5n)
{
	margin-right:0;
}
#wrapper
{
	width:auto !important;
}
.create-block-format-context
{
	display:none;
}
.columns .col
{
	float:none;width:100% !important;margin:0 0 20px;box-sizing:border-box;-webkit-box-sizing:border-box;-moz-box-sizing:border-box;
}
.fullwidth-box
{
	background-attachment:scroll;
}
.fusion-main-menu > ul > li
{
	padding-right:25px;
}
.fusion-body .fusion-page-title-bar .fusion-breadcrumbs
{
	display:none;
}
.review
{
	float:none;width:100%;
}
.fusion-social-links-footer,.fusion-social-networks
{
	display:block;text-align:center;
}
.fusion-social-links-footer
{
	width:auto;
}
.fusion-social-links-footer .fusion-social-networks
{
	display:inline-block;float:none;
}
.fusion-social-networks
{
	padding:0 0 15px;
}
.fusion-author .fusion-author-ssocial .fusion-author-tagline
{
	float:none;text-align:center;max-width:100%;
}
.fusion-author .fusion-author-ssocial .fusion-social-networks
{
	text-align:center;
}
.fusion-author .fusion-author-ssocial .fusion-social-networks .fusion-social-network-icon:first-child
{
	margin-left:0;
}
.fusion-social-networks:after
{
	content:"";display:block;clear:both;
}
.fusion-social-networks li
{
	float:none;display:inline-block;
}
.fusion-reading-box-container .reading-box.reading-box-center,.fusion-reading-box-container .reading-box.reading-box-right
{
	text-align:left;
}
.fusion-reading-box-container .continue
{
	display:block;
}
.fusion-reading-box-container .mobile-button
{
	display:none;float:none;
}
.fusion-title
{
	margin-top:0px !important;margin-bottom:20px !important;
}
.fusion-body .fusion-page-title-bar
{
	height:70px;
}
.fusion-page-title-bar-left .fusion-page-title-captions,.fusion-page-title-bar-left .fusion-page-title-secondary,.fusion-page-title-bar-right .fusion-page-title-captions,.fusion-page-title-bar-right .fusion-page-title-secondary
{
	display:block;float:none;width:100%;line-height:normal;
}
.fusion-page-title-bar-left .fusion-page-title-secondary
{
	text-align:left;
}
.fusion-page-title-bar-left .searchform
{
	display:block;max-width:100%;
}
.fusion-page-title-bar-right .fusion-page-title-secondary
{
	text-align:right;
}
.fusion-page-title-bar-right .searchform
{
	max-width:100%;
}
.fusion-page-title-row
{
	display:table;width:100%;height:100%;min-height:50px;
}
.fusion-page-title-wrapper
{
	display:table-cell;vertical-align:middle;
}
.products .product-list-view
{
	width:100% !important;min-width:100% !important;
}
.sidebar .social_links .social li
{
	width:auto;margin-right:5px;
}
#comment-input
{
	margin-bottom:0;
}
#comment-input input
{
	width:90%;float:none !important;margin-bottom:10px;
}
#comment-textarea textarea
{
	width:90%;
}
.pagination
{
	margin-top:40px;
}
.portfolio-one .portfolio-item .image
{
	float:none;width:auto;height:auto;margin-bottom:20px;
}
h5.toggle span.toggle-title
{
	width:80%;
}
#wrapper .sep-boxed-pricing .panel-wrapper
{
	padding:0;
}
#wrapper .full-boxed-pricing .column,#wrapper .sep-boxed-pricing .column
{
	float:none;margin-bottom:10px;margin-left:0;width:100%;
}
.share-box
{
	height:auto;
}
#wrapper .share-box h4
{
	float:none;line-height:20px !important;padding:0;
}
.share-box ul
{
	float:none;overflow:hidden;padding:0 25px;padding-bottom:15px;margin-top:0px;
}
.project-content .project-description
{
	float:none !important;
}
.project-content .fusion-project-description-details
{
	margin-bottom:50px;
}
.project-content .project-description,.project-content .project-info
{
	width:100% !important;
}
.portfolio-half .flexslider
{
	width:100%;
}
.portfolio-half .project-content
{
	width:100% !important;
}
#style_selector
{
	display:none;
}
.faq-tabs,.portfolio-tabs
{
	height:auto;border-bottom-width:1px;border-bottom-style:solid;
}
.faq-tabs li,.portfolio-tabs li
{
	float:left;margin-right:30px;border-bottom:0;
}
.ls-avada .ls-nav-next,.ls-avada .ls-nav-prev
{
	display:none !important;
}
nav#nav,nav#sticky-nav
{
	margin-right:0;
}
#footer .social-networks
{
	width:100%;margin:0 auto;position:relative;left:-11px;
}
.tab-holder .tabs
{
	height:auto !important;width:100% !important;
}
.shortcode-tabs .tab-hold .tabs li
{
	width:100% !important;
}
body .shortcode-tabs .tab-hold .tabs li,body.dark .sidebar .tab-hold .tabs li
{
	border-right:none !important;
}
.error-message
{
	line-height:170px;margin-top:20px;font-size:130px;
}
.error_page .useful_links
{
	width:100%;padding-left:0;
}
.fusion-google-map
{
	width:100% !important;
}
.social_links_shortcode .social li
{
	width:10% !important;
}
#wrapper .ei-slider
{
	width:100%;height:200px !important;
}
.progress-bar
{
	margin-bottom:10px !important;
}
.fusion-blog-layout-medium-alternate .fusion-post-content
{
	float:none;width:100% !important;margin-top:20px;
}
#wrapper .content-boxes-icon-boxed .content-wrapper-boxed
{
	min-height:inherit !important;padding-bottom:20px;padding-left:3%;padding-right:3%;
}
#wrapper .content-boxes-icon-boxed .content-box-column,#wrapper .content-boxes-icon-on-top .content-box-column
{
	margin-bottom:55px;
}
.fusion-counters-box .fusion-counter-box
{
	margin-bottom:20px;padding:0 15px;
}
.fusion-counters-box .fusion-counter-box:last-child
{
	margin-bottom:0;
}
.popup
{
	display:none !important;
}
.share-box .social-networks
{
	text-align:left;
}
body #small-nav
{
	visibility:visible !important;
}

{
	float:none !important;width:100% !important;box-sizing:border-box;-webkit-box-sizing:border-box;-moz-box-sizing:border-box;
}
#nav-uber #megaMenu
{
	width:100%;
}
#toTop
{
	bottom:30px;border-radius:4px;height:40px;z-index:10000;-webkit-border-radius:4px;
}
#toTop:before
{
	line-height:38px;
}
#toTop:hover
{
	background-color:#333333;
}
.no-mobile-totop .to-top-container
{
	display:none;
}
.no-mobile-slidingbar #slidingbar-area
{
	display:none;
}
.tfs-slider .slide-content-container .btn
{
	min-height:0 !important;padding-left:20px;padding-right:20px !important;height:26px !important;line-height:26px !important;
}
.fusion-soundcloud iframe
{
	width:100%;
}
.fusion-columns-2 .fusion-column,.fusion-columns-2 .fusion-flip-box-wrapper,.fusion-columns-4 .fusion-column,.fusion-columns-4 .fusion-flip-box-wrapper
{
	width:50% !important;float:left !important;
}
.fusion-columns-2 .fusion-column:nth-of-type(3n),.fusion-columns-2 .fusion-flip-box-wrapper:nth-of-type(3n),.fusion-columns-4 .fusion-column:nth-of-type(3n)
{
	clear:both;
}
.fusion-columns-3 .fusion-column,.fusion-columns-3 .fusion-flip-box-wrapper,.fusion-columns-5 .col-lg-2,.fusion-columns-5 .col-md-2,.fusion-columns-5 .col-sm-2,.fusion-columns-5 .fusion-column,.fusion-columns-5 .fusion-flip-box-wrapper,.fusion-columns-6 .fusion-column,.fusion-columns-6 .fusion-flip-box-wrapper
{
	width:33.33% !important;float:left !important;
}
.fusion-columns-3 .fusion-column:nth-of-type(4n),.fusion-columns-3 .fusion-flip-box-wrapper:nth-of-type(4n),.fusion-columns-5 .fusion-column:nth-of-type(4n),.fusion-columns-5 .fusion-flip-box-wrapper:nth-of-type(4n),.fusion-columns-6 .fusion-column:nth-of-type(4n),.fusion-columns-6 .fusion-flip-box-wrapper:nth-of-type(4n)
{
	clear:both;
}
#slidingbar .fusion-column,.footer-area .fusion-column
{
	margin-bottom:40px;
}
.fusion-layout-column.fusion-five-sixth,.fusion-layout-column.fusion-four-fifth,.fusion-layout-column.fusion-one-fifth,.fusion-layout-column.fusion-one-fourth,.fusion-layout-column.fusion-one-half,.fusion-layout-column.fusion-one-sixth,.fusion-layout-column.fusion-one-third,.fusion-layout-column.fusion-three-fifth,.fusion-layout-column.fusion-three-fourth,.fusion-layout-column.fusion-two-fifth,.fusion-layout-column.fusion-two-third
{
	position:relative;float:left;margin-right:4%;margin-bottom:20px;
}
.fusion-layout-column.fusion-one-sixth
{
	width:13.3333%;
}
.fusion-layout-column.fusion-five-sixth
{
	width:82.6666%;
}
.fusion-layout-column.fusion-one-fifth
{
	width:16.8%;
}
.fusion-layout-column.fusion-two-fifth
{
	width:37.6%;
}
.fusion-layout-column.fusion-three-fifth
{
	width:58.4%;
}
.fusion-layout-column.fusion-four-fifth
{
	width:79.2%;
}
.fusion-layout-column.fusion-one-fourth
{
	width:22%;
}
.fusion-layout-column.fusion-three-fourth
{
	width:74%;
}
.fusion-layout-column.fusion-one-third
{
	width:30.6666%;
}
.fusion-layout-column.fusion-two-third
{
	width:65.3333%;
}
.fusion-layout-column.fusion-one-half
{
	width:48%;
}
.fusion-layout-column.fusion-spacing-no
{
	margin-left:0;margin-right:0;
}
.fusion-layout-column.fusion-one-sixth.fusion-spacing-no
{
	width:16.6666666667%;
}
.fusion-layout-column.fusion-five-sixth.fusion-spacing-no
{
	width:83.333333333%;
}
.fusion-layout-column.fusion-one-fifth.fusion-spacing-no
{
	width:20%;
}
.fusion-layout-column.fusion-two-fifth.fusion-spacing-no
{
	width:40%;
}
.fusion-layout-column.fusion-three-fifth.fusion-spacing-no
{
	width:60%;
}
.fusion-layout-column.fusion-four-fifth.fusion-spacing-no
{
	width:80%;
}
.fusion-layout-column.fusion-one-fourth.fusion-spacing-no
{
	width:25%;
}
.fusion-layout-column.fusion-three-fourth.fusion-spacing-no
{
	width:75%;
}
.fusion-layout-column.fusion-one-third.fusion-spacing-no
{
	width:33.33333333%;
}
.fusion-layout-column.fusion-two-third.fusion-spacing-no
{
	width:66.66666667%;
}
.fusion-layout-column.fusion-one-half.fusion-spacing-no
{
	width:50%;
}
.fusion-layout-column.fusion-column-last
{
	clear:right;zoom:1;margin-left:0;margin-right:0;
}
.fusion-column.fusion-spacing-no
{
	margin-bottom:0;width:100% !important;
}
.ua-mobile #main,.ua-mobile .fusion-footer-widget-area,.ua-mobile .page-title-bar,.ua-mobile body
{
	background-attachment:scroll !important;
}
#footer > .fusion-row,#header-sticky .fusion-row,.footer-area > .fusion-row,.fusion-header .fusion-row,.fusion-secondary-header .fusion-row
{
	padding-left:0px !important;padding-right:0px !important;
}
#footer > .fusion-row,.footer-area > .fusion-row,.fusion-header .fusion-row,.fusion-secondary-header .fusion-row
{
	padding-left:0px !important;padding-right:0px !important;
}
#main,.fullwidth-box,.fusion-footer-widget-area,.page-title-bar,body
{
	background-attachment:scroll !important;
}

}
@media only screen and (max-width: 800px)
{
	body.side-header #wrapper
	{
		margin-left:auto !important;margin-right:auto !important;
}
#side-header,.layout-boxed-mode .side-header-wrapper,.side-header-background
{
	background-color:#ffffff;
}
#side-header
{
	position:static;height:auto;width:100% !important;padding:20px 30px 20px 30px !important;margin:0 !important;
}
#side-header .side-header-background
{
	display:none;
}
#side-header .side-header-border
{
	display:none;
}
#side-header .side-header-wrapper
{
	padding-bottom:0;position:relative;
}
#side-header .header-social,#side-header .header-v4-content
{
	display:none;
}
#side-header .fusion-logo
{
	margin:0;float:left;
}
#side-header .side-header-content
{
	padding:0 !important;
}
#side-header.fusion-mobile-menu-design-classic .fusion-logo
{
	float:none;text-align:center;
}
body #wrapper .header-shadow:after,body.side-header #wrapper #side-header.header-shadow .side-header-border:before
{
	position:static;height:auto;box-shadow:none;-webkit-box-shadow:none;-moz-box-shadow:none;
}
#side-header .fusion-main-menu,#side-header .side-header-content-1-2,#side-header .side-header-content-3
{
	display:none;
}
#side-header.fusion-mobile-menu-design-classic .fusion-main-menu-container .fusion-mobile-nav-holder
{
	display:block;margin-top:20px;
}
#side-header.fusion-mobile-menu-design-classic .fusion-main-menu-container .fusion-mobile-sticky-nav-holder
{
	display:none;
}
#side-header.fusion-mobile-menu-design-modern .fusion-logo
{
	float:left;margin:0;
}
#side-header.fusion-mobile-menu-design-modern .fusion-logo-left
{
	float:left;
}
#side-header.fusion-mobile-menu-design-modern .fusion-logo-right
{
	float:right;
}
#side-header.fusion-mobile-menu-design-modern .fusion-logo-center
{
	float:left;
}
#side-header.fusion-mobile-menu-design-modern .fusion-mobile-menu-icons
{
	display:block;
}
#side-header.fusion-mobile-menu-design-modern .fusion-logo-menu-right .fusion-mobile-menu-icons
{
	float:left;position:static;
}
#side-header.fusion-mobile-menu-design-modern .fusion-logo-menu-right .fusion-mobile-menu-icons a
{
	float:left;
}
#side-header.fusion-mobile-menu-design-modern .fusion-logo-menu-right .fusion-mobile-menu-icons :first-child
{
	margin-left:0;
}
#side-header.fusion-mobile-menu-design-modern .fusion-logo-menu-left .fusion-mobile-menu-icons
{
	float:right;
}
#side-header.fusion-mobile-menu-design-modern .fusion-logo-menu-left .fusion-mobile-menu-icons a:last-child
{
	margin-left:0;
}
#side-header.fusion-mobile-menu-design-modern .fusion-main-menu-container .fusion-mobile-nav-holder,#side-header.fusion-mobile-menu-design-modern .side-header-wrapper > .fusion-secondary-menu-search
{
	padding-top:20px;margin-left:-30px;margin-right:-30px;margin-bottom:-20px;
}
#side-header.fusion-mobile-menu-design-modern .fusion-main-menu-container .fusion-mobile-nav-holder > ul
{
	display:block;border-right:0;border-left:0;border-bottom:0;
}
#side-header.fusion-is-sticky.fusion-sticky-menu-1 .fusion-mobile-nav-holder
{
	display:none;
}
#side-header.fusion-is-sticky.fusion-sticky-menu-1 .fusion-mobile-sticky-nav-holder
{
	display:none;
}
.fusion-mobile-menu-design-modern .fusion-secondary-header
{
	padding:0px;padding-left:0 !important;padding-right:0 !important;
}
.fusion-mobile-menu-design-modern .fusion-secondary-header .fusion-row
{
	padding-left:0px;padding-right:0px;
}
.fusion-mobile-menu-design-modern .fusion-social-links-header
{
	max-width:100%;text-align:center;margin-top:10px;margin-bottom:8px;
}
.fusion-mobile-menu-design-modern .fusion-social-links-header a
{
	margin-right:20px;margin-bottom:5px;
}
.fusion-mobile-menu-design-modern .fusion-alignleft
{
	border-bottom:1px solid transparent;
}
.fusion-mobile-menu-design-modern .fusion-alignleft,.fusion-mobile-menu-design-modern .fusion-alignright
{
	width:100%;float:none;display:block;
}
.fusion-body .fusion-mobile-menu-design-modern .fusion-secondary-header .fusion-alignleft,.fusion-body .fusion-mobile-menu-design-modern .fusion-secondary-header .fusion-alignright
{
	text-align:center;
}
.fusion-mobile-menu-design-modern .fusion-secondary-menu > ul > li
{
	display:inline-block;text-align:left;
}
.fusion-body .fusion-mobile-menu-design-modern .fusion-secondary-menu > ul > li
{
	float:none;
}
.fusion-mobile-menu-design-modern .fusion-secondary-menu-cart
{
	border-right:0;
}
.fusion-mobile-menu-design-modern .fusion-secondary-menu-icon
{
	background-color:transparent;padding-left:10px;padding-right:7px;min-width:100%;
}
.fusion-mobile-menu-design-modern .fusion-secondary-menu-icon:after
{
	display:none;
}
.fusion-mobile-menu-design-modern .fusion-secondary-menu .fusion-secondary-menu-icon,.fusion-mobile-menu-design-modern .fusion-secondary-menu .fusion-secondary-menu-icon:hover,.fusion-mobile-menu-design-modern .fusion-secondary-menu-icon:before
{
	color:#ffffff;
}
.fusion-mobile-menu-design-modern .fusion-header-tagline
{
	margin-top:10px;float:none;line-height:24px;
}
.fusion-header .fusion-row
{
	padding-left:0;padding-right:0;
}
.fusion-header-wrapper .fusion-header,.fusion-header-wrapper .fusion-secondary-main-menu
{
	background-color:#ffffff;
}
.fusion-header-wrapper .fusion-row
{
	padding-left:0;padding-right:0;max-width:100%;
}
.fusion-footer-copyright-area > .fusion-row,.fusion-footer-widget-area > .fusion-row
{
	padding-left:0;padding-right:0;
}
.fusion-secondary-header .fusion-row
{
	display:block;
}
.fusion-secondary-header .fusion-alignleft
{
	margin-right:0;
}
.fusion-secondary-header .fusion-alignright
{
	margin-left:0;
}
body.fusion-body .fusion-secondary-header .fusion-alignright > *
{
	float:none;
}
body.fusion-body .fusion-secondary-header .fusion-alignright .fusion-social-links-header .boxed-icons
{
	margin-bottom:5px;
}
.fusion-mobile-menu-design-classic.fusion-header-v1 .fusion-header,.fusion-mobile-menu-design-classic.fusion-header-v2 .fusion-header,.fusion-mobile-menu-design-classic.fusion-header-v3 .fusion-header
{
	padding-top:20px;padding-bottom:20px;
}
.fusion-header-v4 .fusion-logo
{
	display:block;
}
.fusion-header-v4.fusion-mobile-menu-design-modern .fusion-logo .fusion-logo-link
{
	max-width:75%;
}
.fusion-header-v4.fusion-mobile-menu-design-modern .fusion-mobile-menu-icons
{
	position:absolute;
}
.fusion-mobile-menu-design-classic.fusion-header-v1 .fusion-logo,.fusion-mobile-menu-design-classic.fusion-header-v1 .fusion-logo a,.fusion-mobile-menu-design-classic.fusion-header-v2 .fusion-logo,.fusion-mobile-menu-design-classic.fusion-header-v2 .fusion-logo a,.fusion-mobile-menu-design-classic.fusion-header-v3 .fusion-logo,.fusion-mobile-menu-design-classic.fusion-header-v3 .fusion-logo a
{
	float:none;text-align:center;margin:0 !important;
}
.fusion-mobile-menu-design-classic.fusion-header-v1 .fusion-main-menu,.fusion-mobile-menu-design-classic.fusion-header-v2 .fusion-main-menu,.fusion-mobile-menu-design-classic.fusion-header-v3 .fusion-main-menu
{
	display:none;
}
.fusion-mobile-menu-design-classic.fusion-header-v1 .fusion-mobile-nav-holder,.fusion-mobile-menu-design-classic.fusion-header-v2 .fusion-mobile-nav-holder,.fusion-mobile-menu-design-classic.fusion-header-v3 .fusion-mobile-nav-holder
{
	display:block;margin-top:20px;
}
.fusion-mobile-menu-design-classic .fusion-secondary-header
{
	padding:10px;
}
.fusion-mobile-menu-design-classic .fusion-secondary-header .fusion-mobile-nav-holder
{
	margin-top:0;
}
.fusion-mobile-menu-design-classic.fusion-header-v4 .fusion-header,.fusion-mobile-menu-design-classic.fusion-header-v5 .fusion-header
{
	padding-top:20px;padding-bottom:20px;
}
.fusion-mobile-menu-design-classic.fusion-header-v4 .fusion-secondary-main-menu,.fusion-mobile-menu-design-classic.fusion-header-v5 .fusion-secondary-main-menu
{
	padding-top:6px;padding-bottom:6px;
}
.fusion-mobile-menu-design-classic.fusion-header-v4 .fusion-main-menu,.fusion-mobile-menu-design-classic.fusion-header-v5 .fusion-main-menu
{
	display:none;
}
.fusion-mobile-menu-design-classic.fusion-header-v4 .fusion-mobile-nav-holder,.fusion-mobile-menu-design-classic.fusion-header-v5 .fusion-mobile-nav-holder
{
	display:block;
}
.fusion-mobile-menu-design-classic.fusion-header-v4 .fusion-logo,.fusion-mobile-menu-design-classic.fusion-header-v4 .fusion-logo a,.fusion-mobile-menu-design-classic.fusion-header-v5 .fusion-logo,.fusion-mobile-menu-design-classic.fusion-header-v5 .fusion-logo a
{
	float:none;text-align:center;margin:0 !important;
}
.fusion-mobile-menu-design-classic.fusion-header-v4 .searchform,.fusion-mobile-menu-design-classic.fusion-header-v5 .searchform
{
	display:block;float:none;width:100%;margin:0;margin-top:13px;
}
.fusion-mobile-menu-design-classic.fusion-header-v4 .search-table,.fusion-mobile-menu-design-classic.fusion-header-v5 .search-table
{
	width:100%;
}
.fusion-mobile-menu-design-classic.fusion-header-v4 .fusion-logo a
{
	float:none;
}
.fusion-mobile-menu-design-classic.fusion-header-v4 .fusion-header-banner
{
	margin-top:10px;
}
.fusion-mobile-menu-design-classic.fusion-header-v4 .fusion-secondary-main-menu .searchform
{
	display:none;
}
.fusion-mobile-menu-design-classic .fusion-alignleft
{
	margin-bottom:10px;
}
.fusion-mobile-menu-design-classic .fusion-alignleft,.fusion-mobile-menu-design-classic .fusion-alignright
{
	float:none;width:100%;line-height:normal;display:block;
}
.fusion-header-wrapper .fusion-mobile-menu-design-classic .fusion-contact-info
{
	text-align:center;line-height:normal;
}
.fusion-header-wrapper .fusion-mobile-menu-design-classic .fusion-secondary-menu
{
	display:none;
}
.fusion-header-wrapper .fusion-mobile-menu-design-classic .fusion-social-links-header
{
	max-width:100%;margin-top:5px;text-align:center;
}
.fusion-header-wrapper .fusion-mobile-menu-design-classic .fusion-social-links-header a
{
	margin-bottom:5px;
}
.fusion-header-wrapper .fusion-mobile-menu-design-classic .fusion-header-tagline
{
	float:none;text-align:center;margin-top:10px;line-height:24px;margin-left:auto;margin-right:auto;
}
.fusion-header-wrapper .fusion-mobile-menu-design-classic .fusion-header-banner
{
	float:none;text-align:center;margin:0 auto;width:100%;margin-top:20px;clear:both;
}
.fusion-mobile-menu-design-modern .ubermenu-responsive-toggle,.fusion-mobile-menu-design-modern .ubermenu-sticky-toggle-wrapper
{
	clear:both;
}
.fusion-mobile-menu-design-modern.fusion-header-v1 .fusion-main-menu,.fusion-mobile-menu-design-modern.fusion-header-v2 .fusion-main-menu,.fusion-mobile-menu-design-modern.fusion-header-v3 .fusion-main-menu,.fusion-mobile-menu-design-modern.fusion-header-v4 .fusion-main-menu,.fusion-mobile-menu-design-modern.fusion-header-v5 .fusion-main-menu
{
	display:none;
}
.fusion-mobile-menu-design-modern.fusion-header-v1 .fusion-header,.fusion-mobile-menu-design-modern.fusion-header-v2 .fusion-header,.fusion-mobile-menu-design-modern.fusion-header-v3 .fusion-header,.fusion-mobile-menu-design-modern.fusion-header-v4 .fusion-header,.fusion-mobile-menu-design-modern.fusion-header-v5 .fusion-header
{
	padding-top:20px;padding-bottom:20px;
}
.fusion-mobile-menu-design-modern.fusion-header-v1 .fusion-header .fusion-row,.fusion-mobile-menu-design-modern.fusion-header-v2 .fusion-header .fusion-row,.fusion-mobile-menu-design-modern.fusion-header-v3 .fusion-header .fusion-row,.fusion-mobile-menu-design-modern.fusion-header-v4 .fusion-header .fusion-row,.fusion-mobile-menu-design-modern.fusion-header-v5 .fusion-header .fusion-row
{
	width:100%;
}
.fusion-mobile-menu-design-modern.fusion-header-v1 .fusion-logo,.fusion-mobile-menu-design-modern.fusion-header-v2 .fusion-logo,.fusion-mobile-menu-design-modern.fusion-header-v3 .fusion-logo,.fusion-mobile-menu-design-modern.fusion-header-v4 .fusion-logo,.fusion-mobile-menu-design-modern.fusion-header-v5 .fusion-logo
{
	margin:0 !important;
}
.fusion-mobile-menu-design-modern.fusion-header-v1 .modern-mobile-menu-expanded .fusion-logo,.fusion-mobile-menu-design-modern.fusion-header-v2 .modern-mobile-menu-expanded .fusion-logo,.fusion-mobile-menu-design-modern.fusion-header-v3 .modern-mobile-menu-expanded .fusion-logo,.fusion-mobile-menu-design-modern.fusion-header-v4 .modern-mobile-menu-expanded .fusion-logo,.fusion-mobile-menu-design-modern.fusion-header-v5 .modern-mobile-menu-expanded .fusion-logo
{
	margin-bottom:20px !important;
}
.fusion-mobile-menu-design-modern.fusion-header-v1 .fusion-mobile-nav-holder,.fusion-mobile-menu-design-modern.fusion-header-v2 .fusion-mobile-nav-holder,.fusion-mobile-menu-design-modern.fusion-header-v3 .fusion-mobile-nav-holder,.fusion-mobile-menu-design-modern.fusion-header-v4 .fusion-mobile-nav-holder,.fusion-mobile-menu-design-modern.fusion-header-v5 .fusion-mobile-nav-holder
{
	padding-top:20px;margin-left:-30px;margin-right:-30px;margin-bottom:calc(-20px - 0px);
}
.fusion-mobile-menu-design-modern.fusion-header-v1 .fusion-mobile-nav-holder > ul,.fusion-mobile-menu-design-modern.fusion-header-v2 .fusion-mobile-nav-holder > ul,.fusion-mobile-menu-design-modern.fusion-header-v3 .fusion-mobile-nav-holder > ul,.fusion-mobile-menu-design-modern.fusion-header-v4 .fusion-mobile-nav-holder > ul,.fusion-mobile-menu-design-modern.fusion-header-v5 .fusion-mobile-nav-holder > ul
{
	display:block;
}
.fusion-mobile-menu-design-modern.fusion-header-v1 .fusion-mobile-sticky-nav-holder,.fusion-mobile-menu-design-modern.fusion-header-v2 .fusion-mobile-sticky-nav-holder,.fusion-mobile-menu-design-modern.fusion-header-v3 .fusion-mobile-sticky-nav-holder,.fusion-mobile-menu-design-modern.fusion-header-v4 .fusion-mobile-sticky-nav-holder,.fusion-mobile-menu-design-modern.fusion-header-v5 .fusion-mobile-sticky-nav-holder
{
	display:none;
}
.fusion-mobile-menu-design-modern.fusion-header-v1 .fusion-mobile-menu-icons,.fusion-mobile-menu-design-modern.fusion-header-v2 .fusion-mobile-menu-icons,.fusion-mobile-menu-design-modern.fusion-header-v3 .fusion-mobile-menu-icons,.fusion-mobile-menu-design-modern.fusion-header-v4 .fusion-mobile-menu-icons,.fusion-mobile-menu-design-modern.fusion-header-v5 .fusion-mobile-menu-icons
{
	display:block;
}
.fusion-mobile-menu-design-modern.fusion-header-v4 .fusion-logo a
{
	float:none;
}
.fusion-mobile-menu-design-modern.fusion-header-v4 .fusion-logo .searchform
{
	float:none;display:none;
}
.fusion-mobile-menu-design-modern.fusion-header-v4 .fusion-header-banner
{
	margin-top:10px;
}
.fusion-mobile-menu-design-modern.fusion-header-v5.fusion-logo-center .fusion-logo
{
	float:left;
}
.fusion-mobile-menu-design-modern.fusion-header-v4 .fusion-mobile-nav-holder,.fusion-mobile-menu-design-modern.fusion-header-v5 .fusion-mobile-nav-holder
{
	padding-top:0;margin-left:-30px;margin-right:-30px;margin-bottom:0;
}
.fusion-mobile-menu-design-modern.fusion-header-v4 .fusion-secondary-main-menu,.fusion-mobile-menu-design-modern.fusion-header-v5 .fusion-secondary-main-menu
{
	position:static;border:0;
}
.fusion-mobile-menu-design-modern.fusion-header-v4 .fusion-secondary-main-menu .fusion-mobile-nav-holder > ul,.fusion-mobile-menu-design-modern.fusion-header-v5 .fusion-secondary-main-menu .fusion-mobile-nav-holder > ul
{
	border:0;
}
.fusion-mobile-menu-design-modern.fusion-header-v4 .fusion-secondary-main-menu .searchform,.fusion-mobile-menu-design-modern.fusion-header-v5 .fusion-secondary-main-menu .searchform
{
	float:none;
}
.fusion-is-sticky .fusion-mobile-menu-design-modern.fusion-header-v4 .fusion-sticky-header-wrapper,.fusion-is-sticky .fusion-mobile-menu-design-modern.fusion-header-v5 .fusion-sticky-header-wrapper
{
	position:fixed;width:100%;
}
.fusion-mobile-menu-design-modern.fusion-logo-right.fusion-header-v4 .fusion-logo,.fusion-mobile-menu-design-modern.fusion-logo-right.fusion-header-v5 .fusion-logo
{
	float:right;
}
.fusion-mobile-menu-design-modern.fusion-sticky-menu-only.fusion-header-v4 .fusion-secondary-main-menu,.fusion-mobile-menu-design-modern.fusion-sticky-menu-only.fusion-header-v5 .fusion-secondary-main-menu
{
	position:static;
}
.fusion-mobile-menu-design-classic.fusion-header-v1 .fusion-mobile-sticky-nav-holder,.fusion-mobile-menu-design-classic.fusion-header-v2 .fusion-mobile-sticky-nav-holder,.fusion-mobile-menu-design-classic.fusion-header-v3 .fusion-mobile-sticky-nav-holder,.fusion-mobile-menu-design-classic.fusion-header-v4 .fusion-mobile-sticky-nav-holder,.fusion-mobile-menu-design-classic.fusion-header-v5 .fusion-mobile-sticky-nav-holder,.fusion-mobile-menu-design-modern.fusion-header-v1 .fusion-mobile-sticky-nav-holder,.fusion-mobile-menu-design-modern.fusion-header-v2 .fusion-mobile-sticky-nav-holder,.fusion-mobile-menu-design-modern.fusion-header-v3 .fusion-mobile-sticky-nav-holder,.fusion-mobile-menu-design-modern.fusion-header-v4 .fusion-mobile-sticky-nav-holder,.fusion-mobile-menu-design-modern.fusion-header-v5 .fusion-mobile-sticky-nav-holder
{
	display:none;
}
.fusion-is-sticky .fusion-mobile-menu-design-classic.fusion-header-v1.fusion-sticky-menu-1 .fusion-mobile-nav-holder,.fusion-is-sticky .fusion-mobile-menu-design-classic.fusion-header-v2.fusion-sticky-menu-1 .fusion-mobile-nav-holder,.fusion-is-sticky .fusion-mobile-menu-design-classic.fusion-header-v3.fusion-sticky-menu-1 .fusion-mobile-nav-holder,.fusion-is-sticky .fusion-mobile-menu-design-classic.fusion-header-v4.fusion-sticky-menu-1 .fusion-mobile-nav-holder,.fusion-is-sticky .fusion-mobile-menu-design-classic.fusion-header-v5.fusion-sticky-menu-1 .fusion-mobile-nav-holder,.fusion-is-sticky .fusion-mobile-menu-design-modern.fusion-header-v1.fusion-sticky-menu-1 .fusion-mobile-nav-holder,.fusion-is-sticky .fusion-mobile-menu-design-modern.fusion-header-v2.fusion-sticky-menu-1 .fusion-mobile-nav-holder,.fusion-is-sticky .fusion-mobile-menu-design-modern.fusion-header-v3.fusion-sticky-menu-1 .fusion-mobile-nav-holder,.fusion-is-sticky .fusion-mobile-menu-design-modern.fusion-header-v4.fusion-sticky-menu-1 .fusion-mobile-nav-holder,.fusion-is-sticky .fusion-mobile-menu-design-modern.fusion-header-v5.fusion-sticky-menu-1 .fusion-mobile-nav-holder
{
	display:none;
}
.fusion-mobile-menu-design-classic .fusion-mobile-nav-item,.fusion-mobile-menu-design-classic .fusion-mobile-selector,.fusion-mobile-menu-design-modern .fusion-mobile-nav-item,.fusion-mobile-menu-design-modern .fusion-mobile-selector
{
	text-align:center;
}
.fusion-is-sticky .fusion-mobile-menu-design-classic.fusion-header-v1.fusion-sticky-menu-1 .fusion-mobile-sticky-nav-holder,.fusion-is-sticky .fusion-mobile-menu-design-classic.fusion-header-v2.fusion-sticky-menu-1 .fusion-mobile-sticky-nav-holder,.fusion-is-sticky .fusion-mobile-menu-design-classic.fusion-header-v3.fusion-sticky-menu-1 .fusion-mobile-sticky-nav-holder,.fusion-is-sticky .fusion-mobile-menu-design-classic.fusion-header-v4.fusion-sticky-menu-1 .fusion-mobile-sticky-nav-holder,.fusion-is-sticky .fusion-mobile-menu-design-classic.fusion-header-v5.fusion-sticky-menu-1 .fusion-mobile-sticky-nav-holder
{
	display:block;
}
.fusion-mobile-menu-design-classic .fusion-mobile-nav-holder .fusion-secondary-menu-icon
{
	text-align:inherit;
}
.fusion-mobile-menu-design-classic .fusion-mobile-nav-holder .fusion-secondary-menu-icon:after,.fusion-mobile-menu-design-classic .fusion-mobile-nav-holder .fusion-secondary-menu-icon:before
{
	display:none;
}
.no-overflow-y
{
	overflow-y:visible !important;
}
#content
{
	width:100% !important;margin-left:0px !important;
}
.sidebar
{
	width:100% !important;float:none !important;margin-left:0 !important;clear:both;
}
.fusion-layout-column
{
	margin-left:0;margin-right:0;
}
.fusion-layout-column:nth-child(2n),.fusion-layout-column:nth-child(3n),.fusion-layout-column:nth-child(4n),.fusion-layout-column:nth-child(5n)
{
	margin-left:0;margin-right:0;
}
.fusion-layout-column.fusion-spacing-no
{
	margin-bottom:0;
}
.fusion-body .fusion-layout-column.fusion-spacing-no
{
	width:100%;
}
.fusion-body .fusion-layout-column.fusion-spacing-yes
{
	width:100%;
}
.fusion-columns-1 .fusion-column:first-child,.fusion-columns-2 .fusion-column:first-child,.fusion-columns-3 .fusion-column:first-child,.fusion-columns-4 .fusion-column:first-child,.fusion-columns-5 .fusion-column:first-child
{
	margin-left:0;
}
.fusion-columns .fusion-column
{
	width:100% !important;float:none;box-sizing:border-box;-webkit-box-sizing:border-box;-moz-box-sizing:border-box;
}
.fusion-columns .fusion-column:not(.fusion-column-last)
{
	margin:0 0 50px;
}
#slidingbar-area .columns .col,.avada-container .columns .col,.col-sm-12,.col-sm-2,.col-sm-3,.col-sm-4,.col-sm-6,.footer-area .fusion-columns .fusion-column,.fusion-columns-5 .col-lg-2,.fusion-columns-5 .col-md-2,.fusion-columns-5 .col-sm-2
{
	float:none;width:100%;
}
.fusion-filters
{
	border-bottom:0;
}
.fusion-body .fusion-filter
{
	float:none;margin:0;border-bottom:1px solid #E7E6E6;
}
#side-header .fusion-mobile-logo-1 .fusion-standard-logo,.fusion-mobile-logo-1 .fusion-standard-logo
{
	display:none;
}
#side-header .fusion-mobile-logo-1 .fusion-mobile-logo-1x,.fusion-mobile-logo-1 .fusion-mobile-logo-1x
{
	display:inline-block;
}
.fusion-secondary-menu-icon
{
	min-width:100%;
}
.fusion-body .fusion-page-title-bar
{
	padding-top:5px;padding-bottom:5px;min-height:60px;height:auto;
}
.fusion-page-title-bar-left .fusion-page-title-captions,.fusion-page-title-bar-left .fusion-page-title-secondary,.fusion-page-title-bar-right .fusion-page-title-captions,.fusion-page-title-bar-right .fusion-page-title-secondary
{
	display:block;float:none;width:100%;line-height:normal;
}
.fusion-page-title-bar-left .fusion-page-title-secondary
{
	text-align:left;
}
.fusion-page-title-bar-left .searchform
{
	display:block;max-width:100%;
}
.fusion-page-title-bar-right .fusion-page-title-secondary
{
	text-align:right;
}
.fusion-page-title-bar-right .searchform
{
	max-width:100%;
}
.fusion-body .fusion-page-title-bar .fusion-breadcrumbs
{
	display:none;
}
.fusion-page-title-row
{
	display:table;width:100%;min-height:50px;
}
.fusion-page-title-bar-center .fusion-page-title-row
{
	width:auto;
}
.fusion-page-title-wrapper
{
	display:table-cell;vertical-align:middle;
}
.fusion-body .fusion-blog-layout-medium-alternate .fusion-post-content,.fusion-body .fusion-blog-layout-medium-alternate .has-post-thumbnail .fusion-post-content
{
	float:none;clear:both;margin:0;padding-top:20px;
}
.fusion-author .fusion-social-networks
{
	display:block;margin-top:10px;
}
.fusion-body .fusion-author .fusion-social-networks
{
	text-align:center;
}
.fusion-author-tagline
{
	display:block;float:none;text-align:center;max-width:100%;
}
.fusion-content-boxes.content-boxes-clean-horizontal .content-box-column,.fusion-content-boxes.content-boxes-clean-vertical .content-box-column
{
	border-right-width:1px;
}
.fusion-content-boxes .content-box-shortcode-timeline
{
	display:none;
}
.fusion-countdown,.fusion-countdown .fusion-countdown-counter-wrapper,.fusion-countdown .fusion-countdown-heading-wrapper,.fusion-countdown .fusion-countdown-link-wrapper
{
	display:block;
}
.fusion-countdown .fusion-countdown-heading-wrapper
{
	text-align:center;
}
.fusion-countdown .fusion-countdown-counter-wrapper
{
	margin-top:20px;margin-bottom:10px;
}
.fusion-countdown .fusion-dash-title
{
	display:block;font-size:16px;
}
.fusion-body .fusion-countdown .fusion-dash-title
{
	padding:0;
}
.fusion-countdown .fusion-countdown-link-wrapper
{
	text-align:center;
}
.fusion-reading-box-container .reading-box.reading-box-center
{
	text-align:left;
}
.fusion-reading-box-container .reading-box.reading-box-right
{
	text-align:left;
}
.fusion-reading-box-container .fusion-desktop-button
{
	display:none;
}
.fusion-reading-box-container .fusion-mobile-button
{
	display:block;
}
.fusion-reading-box-container .fusion-mobile-button.continue-center
{
	display:block;
}
#wrapper
{
	width:auto !important;
}
.create-block-format-context
{
	display:none;
}
.review
{
	float:none;width:100%;
}
.fusion-body .fusion-social-links-footer,.fusion-copyright-notice
{
	display:block;text-align:center;
}
.fusion-social-links-footer
{
	width:auto;
}
.fusion-social-links-footer .fusion-social-networks
{
	display:inline-block;float:none;margin-top:0;
}
.fusion-copyright-notice
{
	padding:0 0 15px;
}
.fusion-copyright-notice:after,.fusion-social-networks:after
{
	content:"";display:block;clear:both;
}
.fusion-copyright-notice li,.fusion-social-networks li
{
	float:none;display:inline-block;
}
.fusion-title
{
	margin-top:0px !important;margin-bottom:20px !important;
}
.tfs-slider .fusion-title
{
	margin-bottom:0 !important;
}
#main .cart-empty
{
	float:none;text-align:center;border-top:1px solid;border-bottom:none;width:100%;line-height:normal !important;height:auto !important;margin-bottom:10px;padding-top:10px;
}
#main .return-to-shop
{
	float:none;border-top:none;border-bottom:1px solid;width:100%;text-align:center;line-height:normal !important;height:auto !important;padding-bottom:10px;
}
#content.full-width
{
	margin-bottom:0;
}
.sidebar .social_links .social li
{
	width:auto;margin-right:5px;
}
#comment-input
{
	margin-bottom:0;
}
#comment-input input
{
	width:100%;float:none !important;margin-bottom:10px;
}
#comment-textarea textarea
{
	width:100%;
}
.widget.facebook_like iframe
{
	width:100% !important;max-width:none !important;
}
.pagination
{
	margin-top:40px;
}
.portfolio-one .portfolio-item .image
{
	float:none;width:auto;height:auto;margin-bottom:20px;
}
h5.toggle span.toggle-title
{
	width:80%;
}
#wrapper .sep-boxed-pricing .panel-wrapper
{
	padding:0;
}
#wrapper .full-boxed-pricing .column,#wrapper .sep-boxed-pricing .column
{
	float:none;margin-bottom:10px;margin-left:0;width:100%;
}
.share-box
{
	height:auto;
}
#wrapper .share-box h4
{
	float:none;line-height:20px !important;margin-top:0;padding:0;
}
.share-box ul
{
	float:none;overflow:hidden;padding:0 25px;padding-bottom:15px;margin-top:0px;
}
.project-content .project-description
{
	float:none !important;
}
.single-avada_portfolio .portfolio-half .project-content .project-description h3
{
	margin-top:24px;
}
.project-content .fusion-project-description-details
{
	margin-bottom:50px;
}
.project-content .project-description,.project-content .project-info
{
	width:100% !important;
}
.portfolio-half .flexslider
{
	width:100% !important;
}
.portfolio-half .project-content
{
	width:100% !important;
}
#style_selector
{
	display:none;
}
.ls-avada .ls-nav-next,.ls-avada .ls-nav-prev
{
	display:none !important;
}
#footer .social-networks
{
	width:100%;margin:0 auto;position:relative;left:-11px;
}
.tab-holder .tabs
{
	height:auto !important;width:100% !important;
}
.shortcode-tabs .tab-hold .tabs li
{
	width:100% !important;
}
body .shortcode-tabs .tab-hold .tabs li,body.dark .sidebar .tab-hold .tabs li
{
	border-right:none !important;
}
.error-message
{
	line-height:170px;margin-top:20px;
}
.error_page .useful_links
{
	width:100%;
}
.error-page .useful_links
{
	padding-left:0;
}
.fusion-google-map
{
	width:100% !important;
}
.social_links_shortcode .social li
{
	width:10% !important;
}
#wrapper .ei-slider
{
	width:100% !important;height:200px !important;
}
.progress-bar
{
	margin-bottom:10px !important;
}
#wrapper .content-boxes-icon-boxed .content-wrapper-boxed
{
	min-height:inherit !important;padding-bottom:20px;padding-left:3%;padding-right:3%;
}
#wrapper .content-boxes-icon-boxed .content-box-column,#wrapper .content-boxes-icon-on-top .content-box-column
{
	margin-bottom:55px;
}
.fusion-counters-box .fusion-counter-box
{
	margin-bottom:20px;padding:0 15px;
}
.fusion-counters-box .fusion-counter-box:last-child
{
	margin-bottom:0;
}
.popup
{
	display:none !important;
}
.share-box .social-networks
{
	text-align:left;
}
.product .images #carousel .flex-direction-nav,.product .images #slider .flex-direction-nav
{
	display:none !important;
}
.fullwidth-box
{
	background-attachment:scroll !important;
}
#toTop
{
	bottom:30px;border-radius:4px;height:40px;z-index:10000;-webkit-border-radius:4px;
}
#toTop:before
{
	line-height:38px;
}
#toTop:hover
{
	background-color:#333333;
}
.no-mobile-totop .to-top-container
{
	display:none;
}
.no-mobile-slidingbar #slidingbar-area
{
	display:none;
}
.no-mobile-slidingbar.mobile-logo-pos-left .mobile-menu-icons
{
	margin-right:0;
}
.tfs-slider .slide-content-container .btn
{
	min-height:0 !important;padding-left:30px;padding-right:30px !important;height:26px !important;line-height:26px !important;
}
.fusion-soundcloud iframe
{
	width:100%;
}
.ua-mobile #main,.ua-mobile .footer-area,.ua-mobile .fusion-page-title-bar,.ua-mobile body
{
	background-attachment:scroll !important;
}
.fusion-contact-info
{
	padding:1em 30px;line-height:1.5em;
}

}
@media only screen and (max-width: 800px) and (-webkit-min-device-pixel-ratio: 1.5), only screen and (max-width: 800px) and (min-resolution: 144dpi), only screen and (max-width: 800px) and (min-resolution: 1.5dppx)
{
	#side-header .fusion-mobile-logo-1 .fusion-mobile-logo-1x,.fusion-mobile-logo-1 .fusion-mobile-logo-1x
	{
		display:none;
}
#side-header .fusion-mobile-logo-1 .fusion-mobile-logo-2x,.fusion-mobile-logo-1 .fusion-mobile-logo-2x
{
	display:inline-block;
}

}
@media only screen and (min-device-width: 320px) and (max-device-width: 640px)
{
	#wrapper
	{
		width:auto !important;overflow-x:hidden !important;
}
.fusion-columns .fusion-column
{
	float:none;width:100% !important;margin:0 0 50px;box-sizing:border-box;-webkit-box-sizing:border-box;-moz-box-sizing:border-box;
}
#slidingbar-area .fusion-columns .fusion-column,.footer-area .fusion-columns .fusion-column
{
	float:left;width:98% !important;
}
.fullwidth-box
{
	background-attachment:scroll !important;
}
.no-mobile-totop .to-top-container
{
	display:none;
}
.no-mobile-slidingbar #slidingbar-area
{
	display:none;
}
.review
{
	float:none;width:100%;
}
.copyright,.social-networks
{
	float:none;padding:0 0 15px;text-align:center;
}
.copyright:after,.social-networks:after
{
	content:"";display:block;clear:both;
}
.copyright li,.social-networks li
{
	float:none;display:inline-block;
}
.continue
{
	display:none;
}
.mobile-button
{
	display:block !important;float:none;
}
.title
{
	margin-top:0px !important;margin-bottom:20px !important;
}
#content
{
	width:100% !important;float:none !important;margin-left:0px !important;margin-bottom:50px;
}
#content.full-width
{
	margin-bottom:0;
}
.sidebar
{
	width:100% !important;float:none !important;margin-left:0 !important;
}
.sidebar .social_links .social li
{
	width:auto;margin-right:5px;
}
#comment-input
{
	margin-bottom:0;
}
#comment-input input
{
	width:90%;float:none !important;margin-bottom:10px;
}
#comment-textarea textarea
{
	width:90%;
}
.widget.facebook_like iframe
{
	width:100% !important;max-width:none !important;
}
.pagination
{
	margin-top:40px;
}
.portfolio-one .portfolio-item .image
{
	float:none;width:auto;height:auto;margin-bottom:20px;
}
h5.toggle span.toggle-title
{
	width:80%;
}
#wrapper .sep-boxed-pricing .panel-wrapper
{
	padding:0;
}
#wrapper .full-boxed-pricing .column,#wrapper .sep-boxed-pricing .column
{
	float:none;margin-bottom:10px;margin-left:0;width:100%;
}
.share-box
{
	height:auto;
}
#wrapper .share-box h4
{
	float:none;line-height:20px !important;margin-top:0;padding:0;
}
.share-box ul
{
	float:none;overflow:hidden;padding:0 25px;padding-bottom:25px;margin-top:0px;
}
.project-content .project-description
{
	float:none !important;
}
.project-content .fusion-project-description-details
{
	margin-bottom:50px;
}
.project-content .project-description,.project-content .project-info
{
	width:100% !important;
}
.portfolio-half .flexslider
{
	width:100% !important;
}
.portfolio-half .project-content
{
	width:100% !important;
}
#style_selector
{
	display:none;
}
.ls-avada .ls-nav-next,.ls-avada .ls-nav-prev
{
	display:none !important;
}
#footer .social-networks
{
	width:100%;margin:0 auto;position:relative;left:-11px;
}
.recent-works-items a
{
	max-width:64px;
}
#slidingbar-area .flickr_badge_image img,.footer-area .flickr_badge_image img
{
	max-width:64px;padding:3px !important;
}
.tab-holder .tabs
{
	height:auto !important;width:100% !important;
}
.shortcode-tabs .tab-hold .tabs li
{
	width:100% !important;
}
body .shortcode-tabs .tab-hold .tabs li,body.dark .sidebar .tab-hold .tabs li
{
	border-right:none !important;
}
.error_page .useful_links
{
	width:100%;padding-left:0;
}
.fusion-google-map
{
	width:100% !important;
}
.social_links_shortcode .social li
{
	width:10% !important;
}
#wrapper .ei-slider
{
	width:100% !important;height:200px !important;
}
.progress-bar
{
	margin-bottom:10px !important;
}
#wrapper .content-boxes-icon-boxed .content-wrapper-boxed
{
	min-height:inherit !important;padding-bottom:20px;padding-left:3% !important;padding-right:3% !important;
}
#wrapper .content-boxes-icon-boxed .content-box-column,#wrapper .content-boxes-icon-on-top .content-box-column
{
	margin-bottom:55px;
}
.share-box .social-networks
{
	text-align:left;
}

}
@media only screen and (max-width: 1000px)
{
	.no-csstransforms .sep-boxed-pricing .column
	{
		margin-left:1.5% !important;
}

}
@media only screen and (min-width: 800px)
{
	body.side-header-right.layout-boxed-mode #side-header
	{
		position:absolute;top:0;
}
body.side-header-right.layout-boxed-mode #side-header .side-header-wrapper
{
	position:absolute;
}

}
@media screen and (max-width: 782px)
{
	.admin-bar p.demo_store,body.admin-bar #wrapper #slidingbar-area,body.layout-boxed-mode.side-header-right #slidingbar-area
	{
		top:46px;
}
body.body_blank.admin-bar
{
	top:45px;
}
html #wpadminbar
{
	z-index:99999 !important;position:fixed !important;
}

}
@media screen and (max-width: 768px)
{
	.fusion-tabs.vertical-tabs .tab-pane
	{
		max-width:none !important;
}

}
@media only screen and (min-device-width: 768px) and (max-device-width: 1024px)
{
	#wrapper .ei-slider
	{
		width:100%;
}

}
@media only screen and (min-device-width: 320px) and (max-device-width: 480px)
{
	#wrapper .ei-slider
	{
		width:100%;
}

}
@media only screen and (min-device-width: 768px) and (max-device-width: 1024px) and (orientation: landscape)
{
	.fullwidth-box
	{
		background-attachment:scroll !important;
}
.fusion-main-menu > ul > li
{
	padding-right:25px;
}
#wrapper .fusion-page-title-bar
{
	height:87px !important;
}
#wrapper .ei-slider
{
	width:100%;
}
#main,.fullwidth-box,.fusion-footer-widget-area,.page-title-bar,body
{
	background-attachment:scroll !important;
}

}
@media screen and (-ms-high-contrast: active), (-ms-high-contrast: none)
{
	.gravity-select-parent .select-arrow
	{
		height:24px;line-height:24px;
}
.fusion-imageframe, .imageframe-align-center
{
	font-size:0px;line-height:normal;
}

}
@media (min-width: 1014px)
{
	body #header-sticky.sticky-header
	{
		width:100%;left:0;right:0;margin:0 auto;
}

}
@media only screen and (min-width: 801px) and (max-width: 1014px)
{
	#wrapper
	{
		width:auto;
}

}
@media only screen and (min-device-width: 801px) and (max-device-width: 1014px)
{
	#wrapper
	{
		width:auto;
}

}
@-webkit-keyframes avadaSonarEffect
{
	0%
	{
		opacity:0.3;
}
40%
{
	opacity:0.5;
}
100%
{
	-webkit-transform:scale(1.5);opacity:0;
}

}
@-moz-keyframes avadaSonarEffect
{
	0%
	{
		opacity:0.3;
}
40%
{
	opacity:0.5;
}
100%
{
	-moz-transform:scale(1.5);opacity:0;
}

}
@keyframes avadaSonarEffect
{
	0%
	{
		opacity:0.3;
}
40%
{
	opacity:0.5;
}
100%
{
	transform:scale(1.5);opacity:0;-webkit-transform:scale(1.5);-moz-transform:scale(1.5);-ms-transform:scale(1.5);-o-transform:scale(1.5);
}

}
.link {
	color: white !important;
	padding-left: 128px;
	line-height: 26px;
}
.imLink4 h4 {
	background-color: #02263c;
	font-size: 16px !important;
	font-weight: bold !important;
	color: white !important;
	padding: 8px !important;
	margin-top: 9px !important;
	box-shadow: 0 0 1px 2px #ccc;
	border: 1px solid #fff !important;
	border-radius: 15px 15px 0 0;
	font-size: 15px !important;
}
.fusion-widget-area-2 {
	background-color: #fff !important;
}
.imLink1 {
	//margin-left: 126px !important;
        margin-left: 6% !important;
	margin-right: .1% !important;
        margin-top: -13px !important;
	position: relative;
}

@media screen and min-width: 40.5em)
  {
 .imLink1
{
  margin-left: 1px !important;
  }
}


.imLink4 {
	margin-top: -13px !important;
	padding-left: 15px !important;
}
.imLink2 {
	margin-top: -13px !important;
	padding-left: 16px;
}
.imLink3 {
	margin-top: -13px !important;
	padding-left: 18px;
}


.departmentnotices {
	background-color: #02263C !important;
	width: 212px !important;
	padding: 7px !important;
	height: 648px !important;
	border: 2px solid #fff;
	margin-left: 0px;
}
.widget.SP_News_thmb_Widget {
	background-color: #fff !important;
	border: 1px solid #fff !important;
	box-shadow: 0 1px 1px 2px #ccc;
	height: 244px !important;
	/* width: 312px !important; */
	opacity: 0.87 !important;
	/* overflow-y: scroll !important; */
	padding: 10px;
	text-align: center !important;
	margin-top: -8px;
}
.chemicaltab {
	margin-left: 68px !important;
}
.logoicon {
	
      background-color: #FFFFFF !important;
      }
.departmentnotices {
	background-color: #02263C !important;
	width: 212px !important;
	padding: 7px !important;
	height: 648px !important;
	border: 2px solid #fff;
	position: relative;
	margin-left: -150px;
}
.travelPage {

	padding: 30px 0;
	float: left;
}

.vcsird {
    background: #8e0000;
    padding: 10px;
    min-height: 230px;
    height: 50%;
    color: #fff;
    padding-bottom: 20px;
}

.vcsird_chairman {
    background: #8e0000;
    padding: 10px;
    color: #fff;
    padding-bottom: 20px;
}

.blockquote {
    font-family: Georgia, serif;
    font-size: 20px !important;
    font-style: italic !important;
    margin: 5px 0 !important;
   
    line-height: 1.45 !important;
    position: relative !important;
    color: #ecebeb !important;
    text-align: justify !important;
}
.blockquote cite {
    color: #fff;
    font-size: 14px;
    display: block;
    margin-top: 5px;
    font-weight: 700;
}
:after, :before {
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    box-sizing: border-box;
}
.row-padded {

 background-color:#FFFFFF;
}

.imgStyleBottom
{
display: block;
    float:none !important;
   margin: 0 auto;
}
.clr{
background-color:#FFFFFF;
}
.pdtop{
padding-top:20px;
}

#blog-author{
background-color:#FFFFFF;
padding: 20px;
margin-top: 5px;
}
.imgcenter {
    display: block;
    margin-left: auto;
    margin-right: auto;
    width: 50%;
}
.simple{
background-color: #ffffff !important;
color:black !important;
text-align:justify !important;
font-size: 13px !important;
border: 0px solid !important;
margin-top: 9px !important;
padding: 7px !important;
 box-shadow: none !important;
}
.butt_on {
    background-color: #78cad3;
    border: none;
    color: black;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
     width: 100%;
}

.butt_on1 {
    background-color: #008CBA;
    border: none;
    color: black;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 2px 2px;
    cursor: pointer;
    width: 100%;
}
//small screen sizes
   @media screen and (max-width: 480px)
{
.screen-only
{
display: none;
}
.mobile-only
{
display: block;
}
}

.convocation {
	font-size: 24px;
	text-align: center !important;
color: #640f12;
}
.nav.nav-pills.nav-justified.nvas {
	margin-top: -24px !important;
}


.imgwithoutborder {
     border: 1px solid #ffffff !important; 
    box-shadow: 0 0px 1px 1px #ffffff !important;
}
.leftdiv {
	margin-left: 41px;
	margin-top: 17px !important;
}
.toprightdive {
	margin-left: 50px;
	margin-top: 19px !important;
}
.topleftdive {
	
	margin-top: 19px !important;
}
.rightdiv {
	margin-left: 35px;
	margin-top: 18px !important;
}

.registrarButton .fusion-button {
	font-size: 12px !important;
	text-transform: unset;
}
.leffbox {
	margin-left: 99px !important;
}
.boxtop {
	margin-left: 39px;
}
#menu-item-20925 {
	display: none;
}
#menu-item-20930 {
	display: none;
}
#menu-item-17224{
	display: none;
}

.title-heading-center {
	color: black !important;
}
.\31 0convocation {
	font-size: 20px;
	color: #640f12;
}
.\31 0convocation a{
	font-size: 20px;
	color: #640f12;
}
#text1 {
	margin-bottom: -19px !important;
	margin-top: 2px;
}
.table-1.contactTableData th {
	text-align: center !important;
}
.table-1.contactTableData th strong {
	font-size: 18px;
}
.table-1.contactTableData td {
	font-size: 16px !important;
}
</style>

	<title>Teacher Dashboard</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">

<!-- <-- jQuery library -> -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- <-- Latest compiled JavaScript -> -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
	<style>
		table {
		    border-collapse: collapse;
		    border: 1px solid #000;
		    text-align: left;
		}
		th, td {
		    padding: 10px;
		}
	</style>
</head>

<body class="page page-id-12049 page-template-default fusion-body no-tablet-sticky-header no-mobile-sticky-header no-mobile-slidingbar no-mobile-totop layout-boxed-mode menu-text-align-center mobile-menu-design-classic fusion-image-hovers fusion-show-pagination-text do-animate">

<div id="wrapper" class="">
    <div id="home" style="position:relative;top:1px;"></div>
    <div id="slidingbar-area" class="slidingbar-area fusion-widget-area">
		<div id="slidingbar">
			<div class="fusion-row">
				<div class="fusion-columns row fusion-columns-2 columns columns-2">
					<div class="fusion-column col-lg-6 col-md-6 col-sm-6"></div>
					<div class="fusion-column fusion-column-last col-lg-6 col-md-6 col-sm-6"></div>
					<div class="fusion-clearfix"></div>
				</div>
			</div>
		</div>
		<div class="sb-toggle-wrapper">
			<a class="sb-toggle" href="#"></a>
		</div>
	</div>
    <div class="fusion-header-wrapper">
        <div class="fusion-header-v4 fusion-logo-left fusion-sticky-menu- fusion-sticky-logo- fusion-mobile-logo-fusion-mobile-menu-design-classic fusion-sticky-menu-only fusion-header-menu-align-center">
 		    <div class="fusion-secondary-header">
                <div class="zooneffect"></div>
                    <div class="fusion-row">
                        <div class="fusion-alignleft">
                           	<div class="fusion-contact-info">
                           		<div class="cont">
 									<a href="https://accounts.google.com" target="_blank">Webmail</a> | <a href="/td/index.html" target="_blank">Directory</a> | <a href="http://nith.ac.in/?page_id=23733">Contact Us</a>
								</div>
								<a href="mailto:"></a>
							</div>
						</div>
                    </div>
           	</div>
            <div class="fusion-header-sticky-height" style="display: none;"></div>
      		<div class="fusion-sticky-header-wrapper" style="height: 133px;">
           		<div class="fusion-header">
               		<div class="fusion-row">                   
       					<div class="fusion-logo" data-margin-top="0px" data-margin-bottom="0px" data-margin-left="50px" data-margin-right="0px">
                   			<a class="fusion-logo-link" href="https://nith.ac.in"><img src="logo.png" alt="National Institute of Technology Hamirpur" class="fusion-logo-1x fusion-standard-logo" width="" height=""><img src="logo.png" alt="National Institute of Technology Hamirpur" class="fusion-standard-logo fusion-logo-2x" width="" height=""></a>
                       		<div class="fusion-header-content-3-wrapper">
                       			<div class="fusion-secondary-menu-search">
                       				<form role="search" class="searchform" method="get" action="https://nith.ac.in/">
										<div class="search-table">
											<div class="search-field">
												<input type="text" value="" name="s" class="s" placeholder="Search ..">
											</div>
											<div class="search-button">
												<input type="submit" class="searchsubmit" value="">
											</div>
										</div>
									</form>
								</div>
							</div>        
						</div> 
					</div>
				</div>
				<div class="fusion-secondary-main-menu">
        			<div class="fusion-row">                    
            			<div class="fusion-main-menu" style="">
            				<ul id="menu-main" class="fusion-menu" align="left">
            					<li id="menu-item-12570" class="menu-item menu-item-type-custom menu-item-object-custom  menu-item-12570"><a href="/"><span class="menu-text">Home</span></a></li>
								<li id="menu-item-17216" class="menu-item menu-item-type-custom menu-item-object-custom current-menu-item current_page_item menu-item-17216" style=""><a href="#"><span class="menu-text">OTC Platform</span></a></li>
								<li id="menu-item-12619" class="menu-item menu-item-type-custom menu-item-object-custom  menu-item-12619" style=""><a href="../OEAS/index.php"><span class="menu-text">OEA System</span></a>
								</li>
								<li id="menu-item-12624" class="menu-item menu-item-type-custom menu-item-object-custom  menu-item-12624" style=""><a href="../SERP/index.php"><span class="menu-text ">SER Portal</span></a>
						</div>
						<div class="fusion-secondary-menu-search">
							<form role="search" class="searchform" method="get" action="https://nith.ac.in/">
								<div class="search-table">
									<div class="search-field">
										<input type="text" value="" name="s" class="s" placeholder="Search ...">
									</div>
									<div class="search-button">
										<input type="submit" class="searchsubmit" value="">
									</div>
								</div>
							</form>
						</div>
        			</div>
    			</div>
			</div> <!-- end fusion sticky header wrapper -->
		</div>
		<div class="fusion-clearfix"></div>
	</div>
	<div id="sliders-container"></div>
	<div id="main" class="clearfix " style="">
        <div class="fusion-row" style="">
			<div id="content" style="width: 100%;">
				<div id="post-12049" class="post-12049 page type-page status-publish hentry">
																						
					<div class="post-content">
						<div class="fusion-fullwidth fullwidth-box fusion-fullwidth-1  fusion-parallax-none hundred-percent-fullwidth faded-background fusion-equal-height-columns chemical" style="border-color:#eae9e9;border-bottom-width: 0px;border-top-width: 0px;border-bottom-style: solid;border-top-style: solid;padding-bottom:0px;padding-top:0px;padding-left:;padding-right:;background-color:#0c1325;background-position:left top;background-repeat:repeat-x;">
							<div class="fullwidth-faded" style="background-attachment:none;background-color:#0c1325;background-image: url(/wp-content/uploads/2016/05/9048148-architectural-black-and-white-background-with-plans-of-building-Stock-Vector.jpg);background-position:left top;background-repeat:repeat-x;"></div>
							<div class="fusion-row">
								<div class="fusion-title title fusion-sep-none fusion-title-center fusion-title-size-one" style="margin-top:50px;margin-bottom:50px;"><h1 class="title-heading-center" data-fontsize="27" data-lineheight="48">My Question Papers</h1></div>
							</div>
						</div>
						<div class="fusion-one-full fusion-layout-column fusion-column-last fusion-spacing-yes " style="margin-top:0px;margin-bottom:10px;">
							<div class="fusion-column-wrapper">
								<style type="text/css">#wonderplugintabs-35 > .wonderplugintabs-header-wrap { 	box-sizing: border-box; 	display: block; 	position: relative; 	z-index: 1; 	float: left; }  #wonderplugintabs-35 > .wonderplugintabs-header-wrap .wonderplugintabs-header-inner-wrap { 	box-sizing: border-box; 	display: block; 	height: 100%; }  #wonderplugintabs-35 > .wonderplugintabs-header-wrap .wonderplugintabs-header-ul { 	box-sizing: border-box; 	display: block; 	position: relative; 	list-style: none; 	margin: 0; 	padding: 0; 	color: #fff; }  #wonderplugintabs-35 > .wonderplugintabs-header-wrap .wonderplugintabs-header-li { 	box-sizing: border-box; 	display: block; 	position: relative; 	text-align: left; 	cursor: pointer; 	margin: 0 0 0px 0; 	padding: 10px; 	background-color: #307993; 	border-top: 1px solid #307993; 	border-bottom: 1px solid #0c1325; }  #wonderplugintabs-35 > .wonderplugintabs-header-wrap .wonderplugintabs-header-li:hover { 	background-color: #0c1325; }  #wonderplugintabs-35 > .wonderplugintabs-header-wrap .wonderplugintabs-header-li-active { 	background-color: #0c1325; }  #wonderplugintabs-35 > .wonderplugintabs-header-wrap .wonderplugintabs-header-li-active:after { 	position: absolute; 	top: 50%; 	margin-top: -8px; 	left: 100%; 	content: " "; 	height: 0; 	width: 0; 	border-top: 8px solid transparent; 	border-bottom: 8px solid transparent; 	border-left: 8px solid #0c1325; 	z-index: 100; }  #wonderplugintabs-35 > .wonderplugintabs-header-wrap-fullwidth .wonderplugintabs-header-li-active:after { 	display:none; }  #wonderplugintabs-35 > .wonderplugintabs-header-wrap .wonderplugintabs-header-prev { 	display: none; 	text-align: center; 	position: absolute; 	top: 0; 	left: 0; 	width: 100%; 	cursor: pointer; 	background-color: transparent; 	height:	40px; 	z-index: 1; }  #wonderplugintabs-35 > .wonderplugintabs-header-wrap .wonderplugintabs-header-prev:before {    position: relative;    top: 50%;    margin-top: -8px;    font-family: FontAwesome;    font-weight: bold;    font-size: 20px;    display: block;    color: #666; }  #wonderplugintabs-35 > .wonderplugintabs-header-wrap .wonderplugintabs-header-prev:hover:before {    color: #333; }  #wonderplugintabs-35 > .wonderplugintabs-header-wrap .wonderplugintabs-header-next { 	display: none; 	text-align: center; 	position: absolute; 	bottom: 0; 	left: 0; 	width: 100%; 	cursor:pointer; 	background-color: transparent; 	height:	40px; 	z-index: 1; }  #wonderplugintabs-35 > .wonderplugintabs-header-wrap .wonderplugintabs-header-next:before {    position: relative;    top: 50%;    margin-top: -8px;    font-family: FontAwesome;    font-weight: bold;    font-size: 20px;    display: block;    color: #666; }  #wonderplugintabs-35 > .wonderplugintabs-header-wrap .wonderplugintabs-header-next:hover:before {    color: #333; }  #wonderplugintabs-35 > .wonderplugintabs-header-wrap .wonderplugintabs-header-menu { 	box-sizing: border-box; 	display: none; 	text-align: center; 	position: absolute; 	bottom: 0; 	left: 0; 	cursor: pointer; 	width: 100%; 	background-color: #307993; 	padding: 10px; }  #wonderplugintabs-35 > .wonderplugintabs-header-wrap .wonderplugintabs-header-menu-caption { 	display: table-cell; 	vertical-align: middle; }  #wonderplugintabs-35 > .wonderplugintabs-header-wrap .wonderplugintabs-header-menu-text { 	font-family: "Open Sans", Arial, sans-serif; 	font-size: 12px; 	font-weight: 400; 	vertical-align: middle; 	color: #fff; }  #wonderplugintabs-35 > .wonderplugintabs-header-wrap .wonderplugintabs-header-menu-icon { 	font-family: FontAwesome; 	font-size: 14px; 	vertical-align: middle; 	margin: 8px; 	color: #ffffff; }  #wonderplugintabs-35 > .wonderplugintabs-header-wrap .wonderplugintabs-header-menu:hover { 	background-color: #0c1325;	 }  #wonderplugintabs-35 > .wonderplugintabs-header-wrap .wonderplugintabs-header-menu-dropdown { 	box-sizing: border-box; 	display: none; 	position: absolute; 	white-space: nowrap; 	bottom: 0; 	left: 100%;	 }  #wonderplugintabs-35 > .wonderplugintabs-header-wrap .wonderplugintabs-header-menu-dropdown-item { 	padding: 12px 32px 12px 20px;	 	cursor: pointer; 	text-align: left; 	background-color: #307993; }  #wonderplugintabs-35 > .wonderplugintabs-header-wrap .wonderplugintabs-header-menu-dropdown-item:hover { 	background-color: #0c1325;	 }  #wonderplugintabs-35 > .wonderplugintabs-header-wrap .wonderplugintabs-header-icon-fontawesome { 	font-family: FontAwesome; 	font-size: 16px; 	vertical-align: middle; 	margin: 8px; 	color: #ffffff; }  #wonderplugintabs-35 > .wonderplugintabs-header-wrap .wonderplugintabs-header-icon-image { 	margin: 4px; 	vertical-align: middle; }  #wonderplugintabs-35 > .wonderplugintabs-header-wrap .wonderplugintabs-header-title { 	display: inline-block; 	margin: 4px; 	font-family: "Open Sans", Arial, sans-serif; 	font-size: 12px; 	font-weight: 400; 	vertical-align: middle; 	color: #fff; 	white-space: nowrap; }  #wonderplugintabs-35 > .wonderplugintabs-header-wrap-fullwidth { 	float: none; }  #wonderplugintabs-35 > .wonderplugintabs-panel-wrap-fullwidth { 	left: 0; }  #wonderplugintabs-35 > .wonderplugintabs-header-wrap .wonderplugintabs-header-li-fullwidth { 	display: block; 	text-align: left; }  #wonderplugintabs-35 > .wonderplugintabs-panel-wrap { 	box-sizing: border-box; 	position: relative; 	display: block; 	overflow: hidden; 	background-color: #fff;	 }  #wonderplugintabs-35 > .wonderplugintabs-panel-wrap > .wonderplugintabs-panel { 	box-sizing: border-box; 	display: block; 	visibility: hidden; 	position: absolute; 	top: 0; 	left: 0; 	width: 100%; 	text-align: left; 	padding: 24px; }  #wonderplugintabs-35 > .wonderplugintabs-panel-wrap > .wonderplugintabs-panel-active { 	position: relative; }</style><div style="max-width:1300px;margin:0 auto;"><div style="display: block; max-width: 1300px;" class="wonderplugintabs" id="wonderplugintabs-35" data-tabsid="35" data-width="1300" data-height="400" data-skin="verticalleftdarktabs" data-keyaccess="false" data-fullwidthtabs="false" data-accordion="false" data-accordionmultiple="false" data-accordioncloseall="false" data-savestatusincookie="false" data-extendedheight="false" data-responsive="true" data-fullwidth="false" data-applydisplaynonetohiddenpanel="true" data-triggerresize="true" data-triggerresizeonload="true" data-disablewpautop="false" data-hidetitleonsmallscreen="false" data-donotinit="false" data-addinitscript="false" data-fullwidthtabsonsmallscreen="true" data-heightmode="auto" data-minheight="702" data-firstid="0" data-direction="vertical" data-tabposition="left" data-tabiconposition="left" data-horizontaltabalign="left" data-hidetitleonsmallscreenwidth="768" data-transition="" data-responsivemode="arrow" data-tabarrowmode="slide" data-horizontalarrowwidthsameasheight="sameheight" data-horizontalarrowwidth="32" data-arrowprevicon="fa-angle-up" data-arrownexticon="fa-angle-down" data-dropdownmenutext="More" data-dropdownmenuicon="fa-angle-right" data-triggerresizeonloadtimeout="0" data-fullwidthtabsonsmallscreenwidth="600" data-jsfolder="https://nith.ac.in/wp-content/plugins/wonderplugin-tabs/engine/" data-skinsfoldername="skins">
									<div class="wonderplugintabs-header-wrap" style="height: 702px; padding-top: 0px; padding-bottom: 0px;">
										<div class="wonderplugintabs-header-prev fa-angle-up" style="display: none;"></div>
										<div class="wonderplugintabs-header-inner-wrap">
											<ul class="wonderplugintabs-header-ul" style="margin-top: 0px;">
												<li class="wonderplugintabs-header-li wonderplugintabs-header-li-next">
                                                    <div class="wonderplugintabs-header-caption">
                                                        <!-- <span class="wonderplugintabs-header-icon-fontawesome fa fa-users"></span> -->
                                                        <div class="wonderplugintabs-header-title"><a href="t_dashboard.php">Dashboard</a></div>
                                                    </div>
                                                </li>
                                                <li class="wonderplugintabs-header-li wonderplugintabs-header-li-next">
                                                    <div class="wonderplugintabs-header-caption">
                                                        <!-- <span class="wonderplugintabs-header-icon-fontawesome fa fa-users"></span> -->
                                                        <div class="wonderplugintabs-header-title"><a href="update_tinfo.php">Edit Profile</a></div>
                                                    </div>
                                                </li>
                                                <li class="wonderplugintabs-header-li wonderplugintabs-header-li-first wonderplugintabs-header-li-active wonderplugintabs-header-li-active-first">
                                                    <div class="wonderplugintabs-header-caption">
                                                        <!-- <span class="wonderplugintabs-header-icon-fontawesome fa fa-user"></span> -->
                                                        <div class="wonderplugintabs-header-title"><a href="#">My Question Papers</a></div>
                                                    </div>
                                                </li>
                                                <li class="wonderplugintabs-header-li wonderplugintabs-header-li-next">
                                                    <div class="wonderplugintabs-header-caption">
                                                        <!-- <span class="wonderplugintabs-header-icon-fontawesome fa fa-users"></span> -->
                                                        <div class="wonderplugintabs-header-title"><a href="paper_name.php">Submit New Question Paper</a></div>
                                                    </div>
                                                </li>
                                                <li class="wonderplugintabs-header-li wonderplugintabs-header-li-next">
                                                    <div class="wonderplugintabs-header-caption">
                                                        <!-- <span class="wonderplugintabs-header-icon-fontawesome fa fa-users"></span> -->
                                                        <div class="wonderplugintabs-header-title"><a href="download_results.php">Download Results</a></div>
                                                    </div>
                                                </li>
                                                <li class="wonderplugintabs-header-li">
                                                    <div class="wonderplugintabs-header-caption">
                                                        <!-- <span class="wonderplugintabs-header-icon-fontawesome fa fa-beer"></span> -->
                                                        <div class="wonderplugintabs-header-title"><a href="logout.php">Logout</a></div>
                                                    </div>
                                                </li>
												<!--li class="wonderplugintabs-header-li wonderplugintabs-header-li-next">
													<div class="wonderplugintabs-header-caption">
														<span class="wonderplugintabs-header-icon-fontawesome fa fa-users"></span>
														<div class="wonderplugintabs-header-title">Supplimentary Exam Registration</div>
													</div>
												</li>
												<li class="wonderplugintabs-header-li">
													<div class="wonderplugintabs-header-caption">
														<span class="wonderplugintabs-header-icon-fontawesome fa fa-beer"></span>
														<div class="wonderplugintabs-header-title">Dean Message</div>
													</div>
												</li>
												<li class="wonderplugintabs-header-li">
													<div class="wonderplugintabs-header-caption">
														<span class="wonderplugintabs-header-icon-fontawesome fa fa-registered"></span>
														<div class="wonderplugintabs-header-title">Register</div>
													</div>
												</li>
												<li class="wonderplugintabs-header-li">
													<div class="wonderplugintabs-header-caption">
														<span class="wonderplugintabs-header-icon-fontawesome fa fa-search"></span>
														<div class="wonderplugintabs-header-title">Search</div>
													</div>
												</li>
												<li class="wonderplugintabs-header-li wonderplugintabs-header-li-last">
													<div class="wonderplugintabs-header-caption">
														<span class="wonderplugintabs-header-icon-fontawesome fa fa-user"></span>
														<div class="wonderplugintabs-header-title">Members</div>
													</div>
												</li-->
											</ul>
										</div>
										<div class="wonderplugintabs-header-next fa-angle-down" style="display: none;"></div>
									</div>
									<div class="wonderplugintabs-panel-wrap">
										<div class="wonderplugintabs-panel wonderplugintabs-panel-first wonderplugintabs-panel-active" style="display: block; visibility: visible; opacity: 1;">
											<div class="wonderplugintabs-panel-inner">
												<div class="">
													<!-- <p style="font-weight:bold" ;=""> -->
															<h3><b>User Name: </b><i><?php echo $userid; ?></i></h3>
<center>
	<table class="table table-hover">
		<tr>
			<td>Subject</td>
			<td>Paper Name</td>
			<td>Paper Time</td>
		</tr>
		<?php

			$sql = "SELECT * FROM `mcq_paper` WHERE `user_id`='$userid'";
			$result = mysqli_query($conn,$sql);
			if ($result) {
				while($row = mysqli_fetch_assoc($result)) {
					echo "<tr> <td>". $row["subject"]."</td> <td>" . $row["paper_name"]. "</td> <td>" . $row["paper_time"]."</td> </tr>";
				}
			}else {
				echo "No paper was created..!!";
			}
		?>
	</table>
</center>
<hr/><br>
														<!-- </p> -->
												</div>
											</div>
										</div>
										<!--div class="wonderplugintabs-panel" style="display: none; visibility: hidden; opacity: 0;">
											<div class="wonderplugintabs-panel-inner">
												<div class="">
													<h2 data-fontsize="18" data-lineheight="27"><b>Page Under Construction</b></h2><p></p>
												</div>
											</div>
										</div>
										<div class="wonderplugintabs-panel" style="display: none; visibility: hidden; opacity: 0;">
											<div class="wonderplugintabs-panel-inner">
												<div class="">
													<h2 data-fontsize="18" data-lineheight="27"><strong>Page Under Construction</strong></h2><p></p>
												</div>
											</div>
										</div>
										<div class="wonderplugintabs-panel" style="display: none; visibility: hidden; opacity: 0;">
											<div class="wonderplugintabs-panel-inner">
												<h2 class="heading" style="text-align:center" data-fontsize="18" data-lineheight="27"><b>ALUMNI Management System<br>National Institute of Technology ,Hamirpur</b></h2><p class="reg" style="font-weight:bold" ;="">Click here to get   <a href="http://14.139.56.7:8080/alumni/"> <b>REGISTER</b></a></p>
											</div>
										</div>
										<div class="wonderplugintabs-panel" style="display: none; visibility: hidden; opacity: 0;">
											<div class="wonderplugintabs-panel-inner">
												<h2 class="heading" style="text-align:center" data-fontsize="18" data-lineheight="27"><b>ALUMNI Management System<br>National Institute of Technology ,Hamirpur</b></h2><p class="reg" style="font-weight:bold" ;="">Click here to  <a href="http://14.139.56.7:8080/alumni/alumnisearch.jsp"> <b>SEARCH</b></a></p>
											</div>
										</div>
										<div class="wonderplugintabs-panel wonderplugintabs-panel-last" style="display: none; visibility: hidden; opacity: 0;">
											<div class="wonderplugintabs-panel-inner">
												<div class=""><h2 style="text-align: center;" data-fontsize="18" data-lineheight="27">Alumni Members</h2>
													<table class="table table-hover stafftable" style="width: 100%" border="1" align="center">
														<thead>
															<tr>
																<th style="text-align: justify !important; width: 10%;">Sr. No.</th>
																<th style="text-align: justify !important; width: 60%;">Name</th>
																<th style="text-align: justify !important; width: 30%;">Designation</th>
															</tr>
														</thead>
														<tbody>
															<tr>
																<td class="sciencback">
																	<div class="computersci" style="text-align: justify;">
																	<b>	1.	</b></div></td>
																<td class="scienceimage"><div class="computersci" style="text-align: justify;"><b>	  Mr. Rajender Singh Barwal (91/BTech/EE)    </b></div></td>
																<td class="scienceimage"><div class="computersci" style="text-align: justify;"><b>	  President  	</b></div></td>
															</tr>
															<tr>
																<td class="sciencback"><div class="computersci" style="text-align: justify;"><b>	2.	</b></div></td>
																<td class="scienceimage"><div class="computersci" style="text-align: justify;"><b>	 Mr. Pankaj Lakkhanpal (93/BTech/EE)     </b></div></td>
																<td class="scienceimage"><div class="computersci" style="text-align: justify;"><b>	  Vice President  	</b></div></td>
															</tr>
															<tr>
																<td class="sciencback"><div class="computersci" style="text-align: justify;"><b>	3.	</b></div></td>
																<td class="scienceimage"><div class="computersci" style="text-align: justify;"><b>	 Dr. Ashok Kumar (2013/PhD/ECE)     </b></div></td>
																<td class="scienceimage"><div class="computersci" style="text-align: justify;"><b>	 Secretary   	</b></div></td>
															</tr>
															<tr>
																<td class="sciencback"><div class="computersci" style="text-align: justify;"><b>	4.	</b></div></td>
																<td class="scienceimage"><div class="computersci" style="text-align: justify;"><b>	 Dr. Gargi Khanna (97/BTech/ECE)     </b></div></td>
																<td class="scienceimage"><div class="computersci" style="text-align: justify;"><b>	  Joint Secretary  	</b></div></td>
															</tr>
															<tr><td class="sciencback"><div class="computersci" style="text-align: justify;"><b>	5.	</b></div></td>
																<td class="scienceimage"><div class="computersci" style="text-align: justify;"><b>	 Dr. Ashwani Rana (98/BTech/ECE)     </b></div></td>
																<td class="scienceimage"><div class="computersci" style="text-align: justify;"><b>	 Treasurer   	</b></div></td>
															</tr>
															<tr>
																<td class="sciencback"><div class="computersci" style="text-align: justify;"><b>	6.	</b></div></td>
																<td class="scienceimage"><div class="computersci" style="text-align: justify;"><b>	 <ol>
																	<li>Dr. Narottam Chand (93/BTech/CSE)   </li>
																	<li>Ms. Prachi Burathoki (93/BTech/CSE)   </li>
																	<li>Mr. Vivek Bhushan Sood (93/BTech/Civil)   </li>
																	<li>Mr. Nitin Singhai (93/BTech/ECE)   </li>
																	<li>Dr. Arun Bhardwaj (93/BTech/ECE)   </li>
																	<li>Mr. Surender Pal Jagota (93/BTech/Civil)   </li></ol> </b></div></td>
																<td class="scienceimage"><div class="computersci" style="text-align: justify;"><b>	 Executive Members   	</b></div></td>
															</tr>
														</tbody>
													</table>
												</div>
											</div>
										</div-->
									</div>
								</div>
							</div>
							<div class="fusion-clearfix"></div>
						</div>
					</div>
					<div class="fusion-clearfix"></div>
				</div>
			</div>
		</div>
	</div>  <!-- fusion-row -->
</div>  <!-- #main -->
</div>
</body>
</html>