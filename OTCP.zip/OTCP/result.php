<?php

	include "mysql_conn.php";
	session_start();
	$user_id = $_SESSION["student"];

// 	print_r($_POST);
	$Result = 0;

// 	$myarray = array( $_POST);
// // 	echo $myarray;
// 	foreach ($myarray as $key => $value) {
// 	    print_r( $value);
//         // $ss="Select * from mcq_question where ques_id='$key'";
//         // $r=mysqli_query($conn,$ss);
//         // $row=mysqli_fetch_array($r);
//         // echo $row['ans'];
//         // if($row['ans']==$value)
//         // {
//         //     $Result++;
//         // }
// 	  echo "<hr />";
// 	}


 	$paper_id = $_POST["paper_id"];
 	$qus_id = $_POST["qus_id"];

	$i = 0;
	foreach ($qus_id as $k => $v) {
		$index = $v;

		$ans = $_POST[$index];
		if ($ans[0] == $_POST["answer"][$i]) {
			$Result++;
		}
		//echo $ans[0];
		$i++;
	}

// 	//echo $paper_id;

//  	$qus_id =isset( $_POST["qus_id"]);
//  	$answer=isset($_POST["answer"]);
//  	echo $answer;

// 	$i = 0;
// 	foreach ($qus_id as $k => $v) {
// 		$index = "ans".$v;
// // 		$anss = $_POST[$index];
// // 		echo $anss;
// 		if ($index[0] == $_POST["answer"][$i]) {
// 			$Result++;
// 		}
// 		//echo $ans[0];
// 		$i=$i+1;
// 	}
// $array_keys=array_keys($_POST);
// 	foreach($qus_id as $q_id)
// 	{
// 		if(in_array($q_id, $array_keys))
// 		{
// 			$user_value=$_POST[$q_id];
// 			echo $user_value;
// 		}
// 		else
// 		{
			
// 		}
// 	}
	
// 	echo $Result;

	$sql = "INSERT INTO `test_ans`(`user_id`, `paper_id`, `result`) VALUES ('$user_id','$paper_id','$Result')";
	mysqli_query($conn,$sql);
	
?>

<!DOCTYPE html>
<html class="csstransforms csstransforms3d csstransitions ua-gecko ua-gecko-70 ua-gecko-70-0 ua-firefox ua-firefox-70 ua-firefox-70-0 ua-desktop ua-desktop-linux js js flexbox canvas canvastext webgl no-touch geolocation postmessage no-websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients no-cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers applicationcache svg inlinesvg smil svgclippaths" prefix="og: http://ogp.me/ns# fb: http://ogp.me/ns/fb#" data-useragent="Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:70.0) Gecko/20100101 Firefox/70.0" style="overflow-y: auto;" lang="en-US">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="dns-prefetch" href="//s.w.org">
<link rel="alternate" type="application/rss+xml" title="National Institute of Technology Hamirpur » Feed" href="https://nith.ac.in/?feed=rss2">
<link rel="alternate" type="application/rss+xml" title="National Institute of Technology Hamirpur » Comments Feed" href="https://nith.ac.in/?feed=comments-rss2">
<meta property="og:title" content="Alumni Association">
<meta property="og:type" content="article">
<meta property="og:url" content="https://nith.ac.in/?page_id=12049">
<meta property="og:site_name" content="National Institute of Technology Hamirpur">
<meta property="og:description" content="Alumni">
<meta property="og:image" content="http://nith.ac.in/wp-content/uploads/2018/07/newlogo.png">

<script type="text/javascript">
	window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/2\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/2\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/nith.ac.in\/wp-includes\/js\/wp-emoji-release.min.js?ver=4.6.1"}};
	!function(a,b,c){function d(a){var c,d,e,f,g,h=b.createElement("canvas"),i=h.getContext&&h.getContext("2d"),j=String.fromCharCode;if(!i||!i.fillText)return!1;switch(i.textBaseline="top",i.font="600 32px Arial",a){case"flag":return i.fillText(j(55356,56806,55356,56826),0,0),!(h.toDataURL().length<3e3)&&(i.clearRect(0,0,h.width,h.height),i.fillText(j(55356,57331,65039,8205,55356,57096),0,0),c=h.toDataURL(),i.clearRect(0,0,h.width,h.height),i.fillText(j(55356,57331,55356,57096),0,0),d=h.toDataURL(),c!==d);case"diversity":return i.fillText(j(55356,57221),0,0),e=i.getImageData(16,16,1,1).data,f=e[0]+","+e[1]+","+e[2]+","+e[3],i.fillText(j(55356,57221,55356,57343),0,0),e=i.getImageData(16,16,1,1).data,g=e[0]+","+e[1]+","+e[2]+","+e[3],f!==g;case"simple":return i.fillText(j(55357,56835),0,0),0!==i.getImageData(16,16,1,1).data[0];case"unicode8":return i.fillText(j(55356,57135),0,0),0!==i.getImageData(16,16,1,1).data[0];case"unicode9":return i.fillText(j(55358,56631),0,0),0!==i.getImageData(16,16,1,1).data[0]}return!1}function e(a){var c=b.createElement("script");c.src=a,c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var f,g,h,i;for(i=Array("simple","flag","unicode8","diversity","unicode9"),c.supports={everything:!0,everythingExceptFlag:!0},h=0;h<i.length;h++)c.supports[i[h]]=d(i[h]),c.supports.everything=c.supports.everything&&c.supports[i[h]],"flag"!==i[h]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[i[h]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(g=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",g,!1),a.addEventListener("load",g,!1)):(a.attachEvent("onload",g),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),f=c.source||{},f.concatemoji?e(f.concatemoji):f.wpemoji&&f.twemoji&&(e(f.twemoji),e(f.wpemoji)))}(window,document,window._wpemojiSettings);
</script>
<script src="https://nith.ac.in/wp-includes/js/wp-emoji-release.min.js?ver=4.6.1" type="text/javascript"></script>
<script type="text/javascript">
    var doc = document.documentElement;
    doc.setAttribute('data-useragent', navigator.userAgent);
</script>
        
<link rel="stylesheet" href="https://nith.ac.in/wp-content/themes/avada/css/bootstrap.min.css">
<link rel="stylesheet" href="https://nith.ac.in/wp-content/themes/avada/css/responsive.css">
<link rel="stylesheet" href="https://nith.ac.in/wp-content/themes/avada/css/style.css">

<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>

<link rel="stylesheet" id="style2-os-css-css" href="https://nith.ac.in/wp-content/plugins/gallery-images/style/style2-os.css?ver=4.6.1" type="text/css" media="all">
<link rel="stylesheet" id="lightbox-css-css" href="https://nith.ac.in/wp-content/plugins/gallery-images/style/lightbox.css?ver=4.6.1" type="text/css" media="all">
<link rel="stylesheet" id="fontawesome-css-css" href="https://nith.ac.in/wp-content/plugins/gallery-images/style/css/font-awesome.css?ver=4.6.1" type="text/css" media="all">
<link rel="stylesheet" id="cssnews-css" href="https://nith.ac.in/wp-content/plugins/sp-news-and-widget/css/stylenews.css?ver=3.2.7" type="text/css" media="all">
<link rel="stylesheet" id="vsel_style-css" href="https://nith.ac.in/wp-content/plugins/very-simple-event-list/css/vsel-style.css?ver=4.6.1" type="text/css" media="all">
<link rel="stylesheet" id="font-awesome-css" href="https://nith.ac.in/wp-content/plugins/wonderplugin-tabs/font-awesome/css/font-awesome.min.css?ver=4.6.1" type="text/css" media="all">
<link rel="stylesheet" id="wonderplugin-tabs-engine-css-css" href="https://nith.ac.in/wp-content/plugins/wonderplugin-tabs/engine/wonderplugin-tabs-engine.css?ver=4.6.1" type="text/css" media="all">
<link rel="stylesheet" id="avada-stylesheet-css" href="https://nith.ac.in/wp-content/themes/avada/style.css?ver=3.9.3" type="text/css" media="all">
<link rel="stylesheet" id="fontawesome-css" href="https://nith.ac.in/wp-content/themes/avada/assets/fonts/fontawesome/font-awesome.css?ver=3.9.3" type="text/css" media="all">
<link rel="stylesheet" id="avada-iLightbox-css" href="https://nith.ac.in/wp-content/themes/avada/ilightbox.css?ver=3.9.3" type="text/css" media="all">
<link rel="stylesheet" id="avada-animations-css" href="https://nith.ac.in/wp-content/themes/avada/animations.css?ver=3.9.3" type="text/css" media="all">

<script type="text/javascript" src="https://nith.ac.in/wp-includes/js/jquery/jquery.js?ver=1.12.4"></script>
<script type="text/javascript" src="https://nith.ac.in/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1"></script>
<script type="text/javascript" src="https://nith.ac.in/wp-content/plugins/sp-news-and-widget/js/jquery.newstape.js?ver=3.2.7"></script>
<script type="text/javascript" src="https://nith.ac.in/wp-content/plugins/wonderplugin-carousel/engine/wonderplugincarouselskins.js?ver=8.3"></script>
<script type="text/javascript" src="https://nith.ac.in/wp-content/plugins/wonderplugin-carousel/engine/wonderplugincarousel.js?ver=8.3"></script>
<script type="text/javascript" src="https://nith.ac.in/wp-content/plugins/wonderplugin-gallery/engine/wonderplugingallery.js?ver=8.4"></script>
<script type="text/javascript" src="https://nith.ac.in/wp-content/plugins/wonderplugin-tabs/engine/wonderplugin-tabs-engine.js?ver=3.0"></script>

<link rel="https://api.w.org/" href="https://nith.ac.in/?rest_route=/">
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://nith.ac.in/xmlrpc.php?rsd">
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://nith.ac.in/wp-includes/wlwmanifest.xml"> 
<meta name="generator" content="WordPress 4.6.1">
<link rel="canonical" href="https://nith.ac.in/?page_id=12049">
<link rel="shortlink" href="https://nith.ac.in/?p=12049">
<link rel="alternate" type="application/json+oembed" href="https://nith.ac.in/?rest_route=%2Foembed%2F1.0%2Fembed&amp;url=https%3A%2F%2Fnith.ac.in%2F%3Fpage_id%3D12049">
<link rel="alternate" type="text/xml+oembed" href="https://nith.ac.in/?rest_route=%2Foembed%2F1.0%2Fembed&amp;url=https%3A%2F%2Fnith.ac.in%2F%3Fpage_id%3D12049&amp;format=xml">

<link rel="stylesheet" type="text/css" href="style.css"/>

<title>Result</title>
<script type="text/javascript">
        function preventBack() { window.history.forward(); }
        setTimeout("preventBack()", 0);
        window.onunload = function () { null };
</script>
</head>

<body class="page page-id-12049 page-template-default fusion-body no-tablet-sticky-header no-mobile-sticky-header no-mobile-slidingbar no-mobile-totop layout-boxed-mode menu-text-align-center mobile-menu-design-classic fusion-image-hovers fusion-show-pagination-text do-animate">
<div id="wrapper" class="">
    <div id="home" style="position:relative;top:1px;"></div>
    <div id="slidingbar-area" class="slidingbar-area fusion-widget-area">
		<div id="slidingbar">
			<div class="fusion-row">
				<div class="fusion-columns row fusion-columns-2 columns columns-2">
					<div class="fusion-column col-lg-6 col-md-6 col-sm-6"></div>
					<div class="fusion-column fusion-column-last col-lg-6 col-md-6 col-sm-6"></div>
					<div class="fusion-clearfix"></div>
				</div>
			</div>
		</div>
		<div class="sb-toggle-wrapper">
			<a class="sb-toggle" href="#"></a>
		</div>
	</div>
    <div class="fusion-header-wrapper">
        <div class="fusion-header-v4 fusion-logo-left fusion-sticky-menu- fusion-sticky-logo- fusion-mobile-logo-fusion-mobile-menu-design-classic fusion-sticky-menu-only fusion-header-menu-align-center">
 		    <div class="fusion-secondary-header">
                <div class="zooneffect"></div>
                    <div class="fusion-row">
                        <div class="fusion-alignleft">
                           	<div class="fusion-contact-info">
                           		<div class="cont">
 									<a href="https://accounts.google.com" target="_blank">Webmail</a> | <a href="/td/index.html" target="_blank">Directory</a> | <a href="http://nith.ac.in/?page_id=23733">Contact Us</a>
								</div>
								<a href="mailto:"></a>
							</div>
						</div>
                    </div>
           	</div>
            <div class="fusion-header-sticky-height" style="display: none;"></div>
      		<div class="fusion-sticky-header-wrapper" style="height: 133px;">
           		<div class="fusion-header">
               		<div class="fusion-row">                   
       					<div class="fusion-logo" data-margin-top="0px" data-margin-bottom="0px" data-margin-left="50px" data-margin-right="0px">
                   			<a class="fusion-logo-link" href="https://nith.ac.in"><img src="logo.png" alt="National Institute of Technology Hamirpur" class="fusion-logo-1x fusion-standard-logo" width="" height=""><img src="logo.png" alt="National Institute of Technology Hamirpur" class="fusion-standard-logo fusion-logo-2x" width="" height=""></a>
                       		<div class="fusion-header-content-3-wrapper">
                       			<div class="fusion-secondary-menu-search">
                       				<form role="search" class="searchform" method="get" action="https://nith.ac.in/">
										<div class="search-table">
											<div class="search-field">
												<input type="text" value="" name="s" class="s" placeholder="Search ..">
											</div>
											<div class="search-button">
												<input type="submit" class="searchsubmit" value="">
											</div>
										</div>
									</form>
								</div>
							</div>        
						</div> 
					</div>
				</div>
				<div class="fusion-secondary-main-menu">
        			<div class="fusion-row">                    
            			<div class="fusion-main-menu" style="">
            				<ul id="menu-main" class="fusion-menu" align="left">
            					<li id="menu-item-12570" class="menu-item menu-item-type-custom menu-item-object-custom  menu-item-12570"><a href="/"><span class="menu-text">Home</span></a></li>
								<li id="menu-item-17216" class="menu-item menu-item-type-custom menu-item-object-custom current-menu-item current_page_item menu-item-17216" style=""><a href="#"><span class="menu-text">OTC Platform</span></a></li>
								<li id="menu-item-12619" class="menu-item menu-item-type-custom menu-item-object-custom  menu-item-12619" style=""><a href="../OEAS/index.php"><span class="menu-text">OEA System</span></a>
								</li>
								<li id="menu-item-12624" class="menu-item menu-item-type-custom menu-item-object-custom  menu-item-12624" style=""><a href="../SERP/index.php"><span class="menu-text ">SER Portal</span></a>
						</div>
						<div class="fusion-secondary-menu-search">
							<form role="search" class="searchform" method="get" action="https://nith.ac.in/">
								<div class="search-table">
									<div class="search-field">
										<input type="text" value="" name="s" class="s" placeholder="Search ...">
									</div>
									<div class="search-button">
										<input type="submit" class="searchsubmit" value="">
									</div>
								</div>
							</form>
						</div>
        			</div>
    			</div>
			</div> <!-- end fusion sticky header wrapper -->
		</div>
		<div class="fusion-clearfix"></div>
	</div>
	<div id="sliders-container"></div>
	<div id="main" class="clearfix " style="">
        <div class="fusion-row" style="">
			<div id="content" style="width: 100%;">
				<div id="post-12049" class="post-12049 page type-page status-publish hentry">
																							
					<div class="post-content">
						<div class="fusion-fullwidth fullwidth-box fusion-fullwidth-1  fusion-parallax-none hundred-percent-fullwidth faded-background fusion-equal-height-columns chemical" style="border-color:#eae9e9;border-bottom-width: 0px;border-top-width: 0px;border-bottom-style: solid;border-top-style: solid;padding-bottom:0px;padding-top:0px;padding-left:;padding-right:;background-color:#0c1325;background-position:left top;background-repeat:repeat-x;">
							<div class="fullwidth-faded" style="background-attachment:none;background-color:#0c1325;background-image: url(/wp-content/uploads/2016/05/9048148-architectural-black-and-white-background-with-plans-of-building-Stock-Vector.jpg);background-position:left top;background-repeat:repeat-x;"></div>
							<div class="fusion-row">
								<div class="fusion-title title fusion-sep-none fusion-title-center fusion-title-size-one" style="margin-top:50px;margin-bottom:50px;"><h1 class="title-heading-center" data-fontsize="27" data-lineheight="48">Result</h1></div>
							</div>
						</div>
						<div class="fusion-one-full fusion-layout-column fusion-column-last fusion-spacing-yes" style="margin-top:0px;margin-bottom:10px;">
							<div class="fusion-column-wrapper">
								<style type="text/css">#wonderplugintabs-35 > .wonderplugintabs-header-wrap { 	box-sizing: border-box; 	display: block; 	position: relative; 	z-index: 1; 	float: left; }  #wonderplugintabs-35 > .wonderplugintabs-header-wrap .wonderplugintabs-header-inner-wrap { 	box-sizing: border-box; 	display: block; 	height: 100%; }  #wonderplugintabs-35 > .wonderplugintabs-header-wrap .wonderplugintabs-header-ul { 	box-sizing: border-box; 	display: block; 	position: relative; 	list-style: none; 	margin: 0; 	padding: 0; 	color: #fff; }  #wonderplugintabs-35 > .wonderplugintabs-header-wrap .wonderplugintabs-header-li { 	box-sizing: border-box; 	display: block; 	position: relative; 	text-align: left; 	cursor: pointer; 	margin: 0 0 0px 0; 	padding: 10px; 	background-color: #307993; 	border-top: 1px solid #307993; 	border-bottom: 1px solid #0c1325; }  #wonderplugintabs-35 > .wonderplugintabs-header-wrap .wonderplugintabs-header-li:hover { 	background-color: #0c1325; }  #wonderplugintabs-35 > .wonderplugintabs-header-wrap .wonderplugintabs-header-li-active { 	background-color: #0c1325; }  #wonderplugintabs-35 > .wonderplugintabs-header-wrap .wonderplugintabs-header-li-active:after { 	position: absolute; 	top: 50%; 	margin-top: -8px; 	left: 100%; 	content: " "; 	height: 0; 	width: 0; 	border-top: 8px solid transparent; 	border-bottom: 8px solid transparent; 	border-left: 8px solid #0c1325; 	z-index: 100; }  #wonderplugintabs-35 > .wonderplugintabs-header-wrap-fullwidth .wonderplugintabs-header-li-active:after { 	display:none; }  #wonderplugintabs-35 > .wonderplugintabs-header-wrap .wonderplugintabs-header-prev { 	display: none; 	text-align: center; 	position: absolute; 	top: 0; 	left: 0; 	width: 100%; 	cursor: pointer; 	background-color: transparent; 	height:	40px; 	z-index: 1; }  #wonderplugintabs-35 > .wonderplugintabs-header-wrap .wonderplugintabs-header-prev:before {    position: relative;    top: 50%;    margin-top: -8px;    font-family: FontAwesome;    font-weight: bold;    font-size: 20px;    display: block;    color: #666; }  #wonderplugintabs-35 > .wonderplugintabs-header-wrap .wonderplugintabs-header-prev:hover:before {    color: #333; }  #wonderplugintabs-35 > .wonderplugintabs-header-wrap .wonderplugintabs-header-next { 	display: none; 	text-align: center; 	position: absolute; 	bottom: 0; 	left: 0; 	width: 100%; 	cursor:pointer; 	background-color: transparent; 	height:	40px; 	z-index: 1; }  #wonderplugintabs-35 > .wonderplugintabs-header-wrap .wonderplugintabs-header-next:before {    position: relative;    top: 50%;    margin-top: -8px;    font-family: FontAwesome;    font-weight: bold;    font-size: 20px;    display: block;    color: #666; }  #wonderplugintabs-35 > .wonderplugintabs-header-wrap .wonderplugintabs-header-next:hover:before {    color: #333; }  #wonderplugintabs-35 > .wonderplugintabs-header-wrap .wonderplugintabs-header-menu { 	box-sizing: border-box; 	display: none; 	text-align: center; 	position: absolute; 	bottom: 0; 	left: 0; 	cursor: pointer; 	width: 100%; 	background-color: #307993; 	padding: 10px; }  #wonderplugintabs-35 > .wonderplugintabs-header-wrap .wonderplugintabs-header-menu-caption { 	display: table-cell; 	vertical-align: middle; }  #wonderplugintabs-35 > .wonderplugintabs-header-wrap .wonderplugintabs-header-menu-text { 	font-family: "Open Sans", Arial, sans-serif; 	font-size: 12px; 	font-weight: 400; 	vertical-align: middle; 	color: #fff; }  #wonderplugintabs-35 > .wonderplugintabs-header-wrap .wonderplugintabs-header-menu-icon { 	font-family: FontAwesome; 	font-size: 14px; 	vertical-align: middle; 	margin: 8px; 	color: #ffffff; }  #wonderplugintabs-35 > .wonderplugintabs-header-wrap .wonderplugintabs-header-menu:hover { 	background-color: #0c1325;	 }  #wonderplugintabs-35 > .wonderplugintabs-header-wrap .wonderplugintabs-header-menu-dropdown { 	box-sizing: border-box; 	display: none; 	position: absolute; 	white-space: nowrap; 	bottom: 0; 	left: 100%;	 }  #wonderplugintabs-35 > .wonderplugintabs-header-wrap .wonderplugintabs-header-menu-dropdown-item { 	padding: 12px 32px 12px 20px;	 	cursor: pointer; 	text-align: left; 	background-color: #307993; }  #wonderplugintabs-35 > .wonderplugintabs-header-wrap .wonderplugintabs-header-menu-dropdown-item:hover { 	background-color: #0c1325;	 }  #wonderplugintabs-35 > .wonderplugintabs-header-wrap .wonderplugintabs-header-icon-fontawesome { 	font-family: FontAwesome; 	font-size: 16px; 	vertical-align: middle; 	margin: 8px; 	color: #ffffff; }  #wonderplugintabs-35 > .wonderplugintabs-header-wrap .wonderplugintabs-header-icon-image { 	margin: 4px; 	vertical-align: middle; }  #wonderplugintabs-35 > .wonderplugintabs-header-wrap .wonderplugintabs-header-title { 	display: inline-block; 	margin: 4px; 	font-family: "Open Sans", Arial, sans-serif; 	font-size: 12px; 	font-weight: 400; 	vertical-align: middle; 	color: #fff; 	white-space: nowrap; }  #wonderplugintabs-35 > .wonderplugintabs-header-wrap-fullwidth { 	float: none; }  #wonderplugintabs-35 > .wonderplugintabs-panel-wrap-fullwidth { 	left: 0; }  #wonderplugintabs-35 > .wonderplugintabs-header-wrap .wonderplugintabs-header-li-fullwidth { 	display: block; 	text-align: left; }  #wonderplugintabs-35 > .wonderplugintabs-panel-wrap { 	box-sizing: border-box; 	position: relative; 	display: block; 	overflow: hidden; 	background-color: #fff;	 }  #wonderplugintabs-35 > .wonderplugintabs-panel-wrap > .wonderplugintabs-panel { 	box-sizing: border-box; 	display: block; 	visibility: hidden; 	position: absolute; 	top: 0; 	left: 0; 	width: 100%; 	text-align: left; 	padding: 24px; }  #wonderplugintabs-35 > .wonderplugintabs-panel-wrap > .wonderplugintabs-panel-active { 	position: relative; }</style><div style="max-width:1300px;margin:0 auto;"><div style="display: block; max-width: 1300px;" class="wonderplugintabs" id="wonderplugintabs-35" data-tabsid="35" data-width="1300" data-height="400" data-skin="verticalleftdarktabs" data-keyaccess="false" data-fullwidthtabs="false" data-accordion="false" data-accordionmultiple="false" data-accordioncloseall="false" data-savestatusincookie="false" data-extendedheight="false" data-responsive="true" data-fullwidth="false" data-applydisplaynonetohiddenpanel="true" data-triggerresize="true" data-triggerresizeonload="true" data-disablewpautop="false" data-hidetitleonsmallscreen="false" data-donotinit="false" data-addinitscript="false" data-fullwidthtabsonsmallscreen="true" data-heightmode="auto" data-minheight="702" data-firstid="0" data-direction="vertical" data-tabposition="left" data-tabiconposition="left" data-horizontaltabalign="left" data-hidetitleonsmallscreenwidth="768" data-transition="" data-responsivemode="arrow" data-tabarrowmode="slide" data-horizontalarrowwidthsameasheight="sameheight" data-horizontalarrowwidth="32" data-arrowprevicon="fa-angle-up" data-arrownexticon="fa-angle-down" data-dropdownmenutext="More" data-dropdownmenuicon="fa-angle-right" data-triggerresizeonloadtimeout="0" data-fullwidthtabsonsmallscreenwidth="600" data-jsfolder="https://nith.ac.in/wp-content/plugins/wonderplugin-tabs/engine/" data-skinsfoldername="skins">
									<div class="wonderplugintabs-header-wrap" style="height: 702px; padding-top: 0px; padding-bottom: 0px;">
										<div class="wonderplugintabs-header-prev fa-angle-up" style="display: none;"></div>
										<div class="wonderplugintabs-header-inner-wrap">
											<ul class="wonderplugintabs-header-ul" style="margin-top: 0px;">
												<li class="wonderplugintabs-header-li wonderplugintabs-header-li-next">
													<div class="wonderplugintabs-header-caption">
														<!-- <span class="wonderplugintabs-header-icon-fontawesome fa fa-users"></span> -->
														<div class="wonderplugintabs-header-title"><a href="s_dashboard.php">Dashboard</a></div>
													</div>
												</li>												
												<li class="wonderplugintabs-header-li wonderplugintabs-header-li-next">
													<div class="wonderplugintabs-header-caption">
														<!-- <span class="wonderplugintabs-header-icon-fontawesome fa fa-users"></span> -->
														<div class="wonderplugintabs-header-title"><a href="update_sinfo.php">Edit Profile</a></div>
													</div>
												</li>
												<li class="wonderplugintabs-header-li wonderplugintabs-header-li-first wonderplugintabs-header-li-active wonderplugintabs-header-li-active-first">
													<div class="wonderplugintabs-header-caption">
														<!-- <span class="wonderplugintabs-header-icon-fontawesome fa fa-user"></span> -->
														<div class="wonderplugintabs-header-title"><a href="#">View Questions</a></div>
													</div>
												</li>
												<li class="wonderplugintabs-header-li">
													<div class="wonderplugintabs-header-caption">
														<!-- <span class="wonderplugintabs-header-icon-fontawesome fa fa-beer"></span> -->
														<div class="wonderplugintabs-header-title"><a href="logout.php">Logout</a></div>
													</div>
												</li>
												
											</ul>
										</div>
										<div class="wonderplugintabs-header-next fa-angle-down" style="display: none;"></div>
									</div>
									<div class="wonderplugintabs-panel-wrap">
										<div class="wonderplugintabs-panel wonderplugintabs-panel-first wonderplugintabs-panel-active" style="display: block; visibility: visible; opacity: 1;">
											<div class="wonderplugintabs-panel-inner">
												<div class="">
													<!-- <p style="font-weight:bold" ;=""> -->
															<?php 
	$sql1 = "SELECT * FROM `mcq_paper` WHERE `id`='$paper_id'";
	$result_1 = mysqli_query($conn,$sql1);
	$name = mysqli_fetch_array($result_1);

?>
<center>
	<h2><b>Paper Name: <?php echo $name['paper_name'];?></b></h2><br>
	<h3><b>Result: </b><i><?php echo $Result;?></i></h3>	
	<?php
echo '<a href="downloads.php?id='.$paper_id.'">'."Click here to download correct answers!!".'</a>';
?>
</center>
<br>
														<!-- </p> -->
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="fusion-clearfix"></div>
						</div>
					</div>
					<div class="fusion-clearfix"></div>
				</div>
			</div>
		</div>
	</div>  <!-- fusion-row -->
</div>  <!-- #main -->
</div>
</body>
</html>