<?php include "mysql_conn.php"; 

if(isset($_GET['id']))
{
    $location=$_GET['id'];

    #download left location feedbacks script
   
    $result = mysqli_query($conn,"select user_id,result from test_ans where paper_id='$location'");
    $filename =   "marks".$location.".xls";;
    header("Content-Type: application/vnd.ms-excel");
    header("Content-Disposition: attachment; filename=\"$filename\"");
    $isPrintHeader = false;
    if (! empty($result)) {
        foreach ($result as $row) {
            if (! $isPrintHeader) {
                echo implode("\t", array_keys($row)) . "\n";
                $isPrintHeader = true;
            }
            echo implode("\t", array_values($row)) . "\n";
        }
    }

    
    exit();
  

    
}

  ?>