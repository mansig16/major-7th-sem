<?php
 $conn = mysqli_connect("localhost","root","root",'module');
    if($conn == null)
    {
        die('error connecting database');
        return;
    }
    // mysql_select_db('online_quiz', $conn);

?>
