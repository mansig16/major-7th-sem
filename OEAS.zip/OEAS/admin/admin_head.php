<link rel="stylesheet" href="../css/style.css" type="text/css" media="screen" />
<link rel="stylesheet" href="../css/bootstrap.css" type="text/css" media="screen" />
<link rel="stylesheet" href="../css/bootstrap-grid.css" type="text/css" media="screen" />
<script type="text/javascript" src="../js/jquery.js"></script>
<script type="text/javascript" src="../js/style.js"></script>
<script type="text/javascript" src="../js/bootstrap.js"></script>
<script type="text/javascript" src="../js/bootstrap.min.js"></script>
<link rel='stylesheet prefetch' href="../font/css/font-awesome.css" type="text/css" media="screen" />
<link rel='stylesheet prefetch' href="../font/css/font-awesome.min.css" type="text/css" media="screen" />