<!DOCTYPE html>
<html class="csstransforms csstransforms3d csstransitions ua-gecko ua-gecko-70 ua-gecko-70-0 ua-firefox ua-firefox-70 ua-firefox-70-0 ua-desktop ua-desktop-linux js js flexbox canvas canvastext webgl no-touch geolocation postmessage no-websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients no-cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers applicationcache svg inlinesvg smil svgclippaths" prefix="og: http://ogp.me/ns# fb: http://ogp.me/ns/fb#" data-useragent="Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:70.0) Gecko/20100101 Firefox/70.0" style="overflow-y: auto;" lang="en-US">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="dns-prefetch" href="//s.w.org">
<link rel="alternate" type="application/rss+xml" title="National Institute of Technology Hamirpur » Feed" href="https://nith.ac.in/?feed=rss2">
<link rel="alternate" type="application/rss+xml" title="National Institute of Technology Hamirpur » Comments Feed" href="https://nith.ac.in/?feed=comments-rss2">
<meta property="og:title" content="Alumni Association">
<meta property="og:type" content="article">
<meta property="og:url" content="https://nith.ac.in/?page_id=12049">
<meta property="og:site_name" content="National Institute of Technology Hamirpur">
<meta property="og:description" content="Alumni">
<meta property="og:image" content="http://nith.ac.in/wp-content/uploads/2018/07/newlogo.png">

<script type="text/javascript">
  window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/2\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/2\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/nith.ac.in\/wp-includes\/js\/wp-emoji-release.min.js?ver=4.6.1"}};
  !function(a,b,c){function d(a){var c,d,e,f,g,h=b.createElement("canvas"),i=h.getContext&&h.getContext("2d"),j=String.fromCharCode;if(!i||!i.fillText)return!1;switch(i.textBaseline="top",i.font="600 32px Arial",a){case"flag":return i.fillText(j(55356,56806,55356,56826),0,0),!(h.toDataURL().length<3e3)&&(i.clearRect(0,0,h.width,h.height),i.fillText(j(55356,57331,65039,8205,55356,57096),0,0),c=h.toDataURL(),i.clearRect(0,0,h.width,h.height),i.fillText(j(55356,57331,55356,57096),0,0),d=h.toDataURL(),c!==d);case"diversity":return i.fillText(j(55356,57221),0,0),e=i.getImageData(16,16,1,1).data,f=e[0]+","+e[1]+","+e[2]+","+e[3],i.fillText(j(55356,57221,55356,57343),0,0),e=i.getImageData(16,16,1,1).data,g=e[0]+","+e[1]+","+e[2]+","+e[3],f!==g;case"simple":return i.fillText(j(55357,56835),0,0),0!==i.getImageData(16,16,1,1).data[0];case"unicode8":return i.fillText(j(55356,57135),0,0),0!==i.getImageData(16,16,1,1).data[0];case"unicode9":return i.fillText(j(55358,56631),0,0),0!==i.getImageData(16,16,1,1).data[0]}return!1}function e(a){var c=b.createElement("script");c.src=a,c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var f,g,h,i;for(i=Array("simple","flag","unicode8","diversity","unicode9"),c.supports={everything:!0,everythingExceptFlag:!0},h=0;h<i.length;h++)c.supports[i[h]]=d(i[h]),c.supports.everything=c.supports.everything&&c.supports[i[h]],"flag"!==i[h]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[i[h]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(g=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",g,!1),a.addEventListener("load",g,!1)):(a.attachEvent("onload",g),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),f=c.source||{},f.concatemoji?e(f.concatemoji):f.wpemoji&&f.twemoji&&(e(f.twemoji),e(f.wpemoji)))}(window,document,window._wpemojiSettings);
</script>
<script src="https://nith.ac.in/wp-includes/js/wp-emoji-release.min.js?ver=4.6.1" type="text/javascript"></script>
<script type="text/javascript">
    var doc = document.documentElement;
    doc.setAttribute('data-useragent', navigator.userAgent);
</script>
        
<link rel="stylesheet" href="https://nith.ac.in/wp-content/themes/avada/css/bootstrap.min.css">
<link rel="stylesheet" href="https://nith.ac.in/wp-content/themes/avada/css/responsive.css">
<link rel="stylesheet" href="https://nith.ac.in/wp-content/themes/avada/css/style.css">
<link rel="stylesheet" id="style2-os-css-css" href="https://nith.ac.in/wp-content/plugins/gallery-images/style/style2-os.css?ver=4.6.1" type="text/css" media="all">
<link rel="stylesheet" id="lightbox-css-css" href="https://nith.ac.in/wp-content/plugins/gallery-images/style/lightbox.css?ver=4.6.1" type="text/css" media="all">
<link rel="stylesheet" id="fontawesome-css-css" href="https://nith.ac.in/wp-content/plugins/gallery-images/style/css/font-awesome.css?ver=4.6.1" type="text/css" media="all">
<link rel="stylesheet" id="cssnews-css" href="https://nith.ac.in/wp-content/plugins/sp-news-and-widget/css/stylenews.css?ver=3.2.7" type="text/css" media="all">
<link rel="stylesheet" id="vsel_style-css" href="https://nith.ac.in/wp-content/plugins/very-simple-event-list/css/vsel-style.css?ver=4.6.1" type="text/css" media="all">
<link rel="stylesheet" id="font-awesome-css" href="https://nith.ac.in/wp-content/plugins/wonderplugin-tabs/font-awesome/css/font-awesome.min.css?ver=4.6.1" type="text/css" media="all">
<link rel="stylesheet" id="wonderplugin-tabs-engine-css-css" href="https://nith.ac.in/wp-content/plugins/wonderplugin-tabs/engine/wonderplugin-tabs-engine.css?ver=4.6.1" type="text/css" media="all">
<link rel="stylesheet" id="avada-stylesheet-css" href="https://nith.ac.in/wp-content/themes/avada/style.css?ver=3.9.3" type="text/css" media="all">
<link rel="stylesheet" id="fontawesome-css" href="https://nith.ac.in/wp-content/themes/avada/assets/fonts/fontawesome/font-awesome.css?ver=3.9.3" type="text/css" media="all">
<link rel="stylesheet" id="avada-iLightbox-css" href="https://nith.ac.in/wp-content/themes/avada/ilightbox.css?ver=3.9.3" type="text/css" media="all">
<link rel="stylesheet" id="avada-animations-css" href="https://nith.ac.in/wp-content/themes/avada/animations.css?ver=3.9.3" type="text/css" media="all">
<script type="text/javascript" src="https://nith.ac.in/wp-includes/js/jquery/jquery.js?ver=1.12.4"></script>
<script type="text/javascript" src="https://nith.ac.in/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1"></script>
<script type="text/javascript" src="https://nith.ac.in/wp-content/plugins/sp-news-and-widget/js/jquery.newstape.js?ver=3.2.7"></script>
<script type="text/javascript" src="https://nith.ac.in/wp-content/plugins/wonderplugin-carousel/engine/wonderplugincarouselskins.js?ver=8.3"></script>
<script type="text/javascript" src="https://nith.ac.in/wp-content/plugins/wonderplugin-carousel/engine/wonderplugincarousel.js?ver=8.3"></script>
<script type="text/javascript" src="https://nith.ac.in/wp-content/plugins/wonderplugin-gallery/engine/wonderplugingallery.js?ver=8.4"></script>
<script type="text/javascript" src="https://nith.ac.in/wp-content/plugins/wonderplugin-tabs/engine/wonderplugin-tabs-engine.js?ver=3.0"></script>
<link rel="stylesheet" href="nith.css">
<link rel="https://api.w.org/" href="https://nith.ac.in/?rest_route=/">
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://nith.ac.in/xmlrpc.php?rsd">
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://nith.ac.in/wp-includes/wlwmanifest.xml"> 
<meta name="generator" content="WordPress 4.6.1">
<link rel="canonical" href="https://nith.ac.in/?page_id=12049">
<link rel="shortlink" href="https://nith.ac.in/?p=12049">
<link rel="alternate" type="application/json+oembed" href="https://nith.ac.in/?rest_route=%2Foembed%2F1.0%2Fembed&amp;url=https%3A%2F%2Fnith.ac.in%2F%3Fpage_id%3D12049">
<link rel="alternate" type="text/xml+oembed" href="https://nith.ac.in/?rest_route=%2Foembed%2F1.0%2Fembed&amp;url=https%3A%2F%2Fnith.ac.in%2F%3Fpage_id%3D12049&amp;format=xml">

<title>Admin Section</title>
</head>

<body class="page page-id-12049 page-template-default fusion-body no-tablet-sticky-header no-mobile-sticky-header no-mobile-slidingbar no-mobile-totop layout-boxed-mode menu-text-align-center mobile-menu-design-classic fusion-image-hovers fusion-show-pagination-text do-animate">


                   <!--  <div class="wonderplugintabs-header-next fa-angle-down" style="display: none;"></div>
                  </div> -->
                  <div class="wonderplugintabs-panel-wrap" style="min-height: 702px; overflow-y: hidden; height: 306px;">
                    <div class="wonderplugintabs-panel wonderplugintabs-panel-first wonderplugintabs-panel-active" style="display: block; visibility: visible; opacity: 1;">
                      <div class="wonderplugintabs-panel-inner">
                        <div class="">
                          <!-- <p style="font-weight:bold" ;=""> -->
                            <center>
<div class="inbox-body">
  <a href="#myModal" data-toggle="modal" title="Compose" class="btn btn-compose">Delete Elective</a>
</div>
<div class="inbox-body">
  <form action="" method="post">
    <div>
      <input type="submit" name="view-el" id="view-el" tabindex="4" class="form-control btn btn-info" value="View Electives">
    </div>
  </form>
</div>
</center>
                            <!-- </p> -->
                        </div>
                      </div>
                    </div>
                  </div>
               
</body>
</html>