-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 08, 2019 at 05:09 PM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `openelectivems`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `uname` varchar(20) NOT NULL,
  `passwd` varchar(50) DEFAULT NULL,
  `email` varchar(28) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`uname`, `passwd`, `email`) VALUES
('Rishabv0402', '1f10c80062d9c6a8fbc8325c1d7e54a9', 'rishabv04@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `cse33`
--

CREATE TABLE `cse33` (
  `rollno` varchar(10) NOT NULL,
  `bracode` varchar(10) DEFAULT NULL,
  `cgpi` varchar(5) DEFAULT NULL,
  `priority` int(2) DEFAULT NULL,
  `selects` int(2) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cse33`
--

INSERT INTO `cse33` (`rollno`, `bracode`, `cgpi`, `priority`, `selects`) VALUES
('16551', 'cse1', '9.18', 2, 0);

-- --------------------------------------------------------

--
-- Table structure for table `dept_login`
--

CREATE TABLE `dept_login` (
  `deptid` varchar(10) NOT NULL,
  `teachername` varchar(20) DEFAULT NULL,
  `pswd` varchar(50) DEFAULT NULL,
  `electiveid` varchar(10) DEFAULT NULL,
  `email` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dept_login`
--

INSERT INTO `dept_login` (`deptid`, `teachername`, `pswd`, `electiveid`, `email`) VALUES
('cse1', 'Rajeev Kumar', 'db7bafab52014759bedbec960d00fabb', 'cse33', 'rajeev@gmail.com'),
('eee1', 'Sushil Chauhan', '41edd4833f5892a500f53f7ae6761aed', 'eee33', 'sushil@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `eee33`
--

CREATE TABLE `eee33` (
  `rollno` varchar(10) NOT NULL,
  `bracode` varchar(10) DEFAULT NULL,
  `cgpi` varchar(5) DEFAULT NULL,
  `priority` int(2) DEFAULT NULL,
  `selects` int(2) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `eee33`
--

INSERT INTO `eee33` (`rollno`, `bracode`, `cgpi`, `priority`, `selects`) VALUES
('16551', 'cse1', '9.18', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `elective`
--

CREATE TABLE `elective` (
  `elecname` varchar(10) NOT NULL,
  `teachernm` varchar(20) NOT NULL,
  `publish` int(1) NOT NULL,
  `seats` int(3) DEFAULT NULL,
  `info` varchar(500) NOT NULL,
  `link` varchar(70) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `elective`
--

INSERT INTO `elective` (`elecname`, `teachernm`, `publish`, `seats`, `info`, `link`) VALUES
('cse33', 'Rajeev Kumar', 1, 20, 'more updates coming soon..', 'nith.ac.in/cse/syllabus.pdf'),
('eee33', 'Sushil Chauhan', 1, 25, 'register fast..', 'nith.ac.in/eee/syllabus.pdf');

-- --------------------------------------------------------

--
-- Table structure for table `student_login`
--

CREATE TABLE `student_login` (
  `rollno` varchar(10) NOT NULL,
  `pswd` varchar(50) DEFAULT NULL,
  `cgpi` varchar(5) DEFAULT NULL,
  `brancode` varchar(10) DEFAULT NULL,
  `email` varchar(30) NOT NULL,
  `allotted` int(1) DEFAULT NULL,
  `pr1` varchar(10) DEFAULT NULL,
  `pr2` varchar(10) DEFAULT NULL,
  `pr3` varchar(10) DEFAULT NULL,
  `pr4` varchar(10) DEFAULT NULL,
  `pr5` varchar(10) DEFAULT NULL,
  `pr6` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_login`
--

INSERT INTO `student_login` (`rollno`, `pswd`, `cgpi`, `brancode`, `email`, `allotted`, `pr1`, `pr2`, `pr3`, `pr4`, `pr5`, `pr6`) VALUES
('16551', '1dbed7583db664d5c6d5a7285002c07d', '9.18', 'cse1', 'mansi@gmail.com', NULL, 'eee33', 'cse33', NULL, NULL, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`uname`);

--
-- Indexes for table `cse33`
--
ALTER TABLE `cse33`
  ADD PRIMARY KEY (`rollno`);

--
-- Indexes for table `dept_login`
--
ALTER TABLE `dept_login`
  ADD PRIMARY KEY (`deptid`);

--
-- Indexes for table `eee33`
--
ALTER TABLE `eee33`
  ADD PRIMARY KEY (`rollno`);

--
-- Indexes for table `elective`
--
ALTER TABLE `elective`
  ADD PRIMARY KEY (`elecname`);

--
-- Indexes for table `student_login`
--
ALTER TABLE `student_login`
  ADD PRIMARY KEY (`rollno`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
