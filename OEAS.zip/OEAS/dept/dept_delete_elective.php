
                            <center>

<div class="jumbotron">
<?php
		// echo "<center>Elective deleted</center>";


		if(isset($_POST['delete-elective']))
{

//catch the details from form here
	

	//session username
	$outname=$_SESSION['login_user'];
	
	//fetch elective id from the current session username
	$abc="SELECT electiveid FROM dept_login WHERE deptid='$outname'";
	$result = mysqli_query($connection, $abc);
	$rowa = mysqli_fetch_array($result);
	$out=$rowa['electiveid'];
	
	
	//update values in electives table
	$sql = "DELETE  FROM elective WHERE elecname = '$out'" ;

		if (mysqli_query($connection, $sql)) 
		{
    		// echo "<center>Elective deleted updated</center><br>";

    		//publishing elective by creating a new registration table for elective
  			 $creat="DROP TABLE $out";

    		if (mysqli_query($connection, $creat))
    		{
    			echo "<center>Elective successfully deleted</center><br>";
    			//adding a refresh button 
    			$ss="Delete from dept_login where electiveid='$out'";
    			$result1=mysqli_query($connection, $ss);
    			header("refresh:5;url=dept_profile.php");
    			// print("<center><a href=$url >Click here</a></center>");
    		}
    		else
    		{
    			echo "Error: " . $creat . "<br>" . mysqli_error($connection);
    		}


		} 
		
		else 
		{
    		echo "Error: " . $sql . "<br>" . mysqli_error($connection);
		}

}

?>
</div>
</center>
                     