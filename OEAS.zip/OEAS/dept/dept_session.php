<?php
   include('../dbconnect.php');
   // session_start();
   if(!isset($_SESSION)) { session_start(); }
   //checking user for sessions
   $user_check = $_SESSION['login_user'];
   //checking in database username
   $ses_sql = mysqli_query($connection,"SELECT deptid from dept_login where deptid = '$user_check' ");
   
   $row = mysqli_fetch_array($ses_sql,MYSQLI_ASSOC);
   $login_session = $row['deptid'];
   
   if(!isset($_SESSION['login_user'])|| $login_session=='')
   {
      header("location:index.php");
   }
?>